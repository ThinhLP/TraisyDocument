function LectureDiscussionHandler(variables, url) {
    //for discussion of lecture
    var replyTooltip = new PopupTooltip('.reply-menu', 0);

    var feedbackTooltip = new PopupTooltip('.feedback-menu', 0);

    //rotate arrow javascript
    function rotateArrow($arrow, collapsed){
        var iconChevronDown = 'fa-chevron-down';
        var iconChevronUp = 'fa-chevron-up';
        var rotateActive = 'rotate-active';
        var rotateActiveReverse = 'rotate-reverse';
        if (collapsed && !$arrow.hasClass(rotateActive) && $arrow.hasClass(iconChevronUp)) {
            $arrow.addClass(rotateActiveReverse);
        } else if (collapsed && !$arrow.hasClass(rotateActive) && $arrow.hasClass(iconChevronDown)) {
            $arrow.addClass(rotateActive);
        } else if (collapsed && $arrow.hasClass(rotateActive) && $arrow.hasClass(iconChevronDown)) {
            $arrow.removeClass(rotateActive);
        } else if (!collapsed && $arrow.hasClass(iconChevronDown)) {
            $arrow.addClass(rotateActive);
        } else {
            $arrow.removeClass(rotateActiveReverse);
        }
    }

    //collapse javascript
    var expandDisscusion = '.expand-discussion';

    var disscussionCollapse = new Collapse(expandDisscusion, 300, true);
    var arrowHandler = function ($target, collapsed) {
        var $arrow = $target.closest(expandDisscusion).find('i');
        rotateArrow($arrow, collapsed);
    };
    disscussionCollapse.onBeforeToggle(function (e, collapsed) {
        var $target = $(e.target);
        arrowHandler($target, collapsed);
    });
    //

    $('body').on('click', '.reply-btn', function () {
        var parent = $(this).closest('.feedback-panel');
        var id = parent.attr('value');
        parent.find('.reply' + id).show();
    });

    $('#createFeedbackModal').on('shown.bs.modal', function (event) {
        $('#validateContent').hide();
        var lectureId = variables.lectureId;

        $('.create-feedback-btn').attr('value', lectureId);
    });

    $('.create-feedback-btn').on('click', function () {
        var lectureId = $(this).attr('value');
        var content = $('#txtContentFeedback').val();
        if(content.length == 0){
            $('#validateContent').show();
            $('#validateContent').text("Nội dung không được trống")
        } else{
            var data = {
                'content': content,
                'lectureId': lectureId
            };
            var onSuccess = function (data) {
                Utils.showSnackbar('Thêm thảo luận thành công');
                $('#createFeedbackModal').modal('hide');
                $('#feedback-empty').remove();
                $('#feedback-no-empty').append(addDiscussionElm(data));
            };

            var onFail = function () {
                Utils.notify('Lỗi', 'Không thể thêm đề xuất');
            };
            Utils.callJsonAjax(url.createDiscussionUrl, 'POST', data, onSuccess, onFail);
        }

    });

    $('#removeFeedbackModal').on('shown.bs.modal', function (event) {
        var $triggerButton = $(event.relatedTarget);
        var discussionId = $triggerButton.attr('value');

        $('#removeFeedback').on('click', function () {
            data = {
                "discussionId": discussionId
            };
            var onSuccessRemove = function () {
                $('#removeFeedbackModal').modal('hide');
                Utils.showSnackbar("Xoá thảo luận thành công");
                $('#feedback' + discussionId).remove();
            };

            var onFailRemove = function () {
            };
            Utils.callJsonAjax(url.removeDiscussionUrl, 'POST', data, onSuccessRemove, onFailRemove);
        });
    });

    $('body').on('click', '.sendReply', function () {
        var lectureId = variables.lectureId;
        var parentId = $(this).attr('value');
        var content = $('#replyContent' + parentId).val();
        if (content.length > 0) {
            var data = {
                'content': content,
                'lectureId':lectureId,
                'parentId': parentId
            };

            var onSuccess = function (data) {
                Utils.showSnackbar('Đã gửi trả lời');
                $('.reply' + parentId).css('display', 'none');
                $('#contentReply' + parentId).append(addReplyElm(data));
            };

            var onFail = function () {
                Utils.notify('Lỗi', 'Không thể thêm trả lời');
            };
            Utils.callJsonAjax(url.createDiscussionUrl, 'POST', data, onSuccess, onFail);
        };

    });
    $('#removeReplyModal').on('shown.bs.modal', function (event) {
        var $triggerButton = $(event.relatedTarget);
        var discussionId = $triggerButton.attr('value');

        $('#removeReply').on('click', function () {
            data = {
                "discussionId": discussionId
            };
            var onSuccessRemove = function () {
                $('#removeReplyModal').modal('hide');
                Utils.showSnackbar("Xoá trả lời thành công");
                $('#deleteReply' + discussionId).remove();
            };
            var onFailRemove = function () {
            };
            Utils.callJsonAjax(url.removeDiscussionUrl, 'POST', data, onSuccessRemove, onFailRemove);
        });
    });

    $('body').on('click', '.editReply', function () {
        var discussionId = $(this).attr('value');
        $('.edit' + discussionId).show();
        $('#deleteReply' + discussionId).hide();
        $('.reply-option' + discussionId).hide();

        $('.save-reply').on('click', function () {
            var content = $('#txtReplyContent' + discussionId).val();
            if (content.length > 0) {
                var data = {
                    "discussionId": discussionId,
                    "content": content
                };

                var onSuccessRemove = function () {
                    Utils.showSnackbar("Chỉnh sửa trả lời thành công");
                    $("#content" + discussionId).text(content);
                    $('#deleteReply' + discussionId).show();
                    $('.edit' + discussionId).hide();

                };
                var onFailRemove = function () {
                    Utils.notify('Lỗi', 'Không thể chỉnh sửa trả lời');
                };
                Utils.callJsonAjax(url.updateDiscussionUrl, 'POST', data, onSuccessRemove, onFailRemove);
            }
        });
        $('.cancel-save-reply').on('click', function () {
            $('#deleteReply' + discussionId).show();
            $('.edit' + discussionId).hide();
        });
    });

    $('body').on('click','.editDiscussion',function () {
        var discussionId = $(this).attr('value');
        $('.txtDiscussionContent' + discussionId).show();
        $('.actionDiscussionContent' + discussionId).show();
        $('.contentFeedback' + discussionId).hide();
        $('.feedback-choice' + discussionId).hide();

        $('.save-discussion').on('click', function () {
            var content = $('.discussionContent' + discussionId).val();
            if (content.length > 0) {
                var data = {
                    "discussionId": discussionId,
                    "content": content
                };

                var onSuccessUpdate = function () {
                    Utils.showSnackbar("Chỉnh sửa thảo luận thành công");
                    $(".contentFeedback" + discussionId).text(content);
                    $('.contentFeedback' + discussionId).show();
                    $('.txtDiscussionContent' + discussionId).hide();
                    $('.actionDiscussionContent' + discussionId).hide();

                };
                var onFailUpdate = function () {
                    Utils.notify('Lỗi', 'Không thể chỉnh sửa thảo luận');
                };
                Utils.callJsonAjax(url.updateDiscussionUrl, 'POST', data, onSuccessUpdate, onFailUpdate);
            }
        });
        $('.cancel-save-discussion').on('click', function () {
            $('.contentFeedback' + discussionId).show();
            $('.txtDiscussionContent' + discussionId).hide();
            $('.actionDiscussionContent' + discussionId).hide();
        });
    });

    var addReplyElm = function (discussion) {
        return '<div class="feedback-panel feedback-reply " id="deleteReply' + discussion.id + '">' +
            '                                        <a class="float-left">' +
            '                                            <div class="avatar ">' +
            '                                                <img src="/user/' + discussion.User.id + '/avatar ">' +
            '                                            </div>' +
            '                                        </a>' +
            '                                        <div class="feedback-body">' +
            '                                            <ul class="feedback-option reply-option' + discussion.id + '" style="display: none">' +
            '                                                <li  class="editReply "  value="' + discussion.id + '">Chỉnh sửa</li>' +
            '                                                <li  data-toggle="modal" data-target="#removeReplyModal" value="' + discussion.id + '">Xoá trả lời</li>' +
            '                                            </ul>' +
            '                                            <h4 class="feedback-heading"> ' + discussion.User.fullname + ' <small>· 1 giây trước </small>' +
            '                                            <i class="fa fa-ellipsis-v feedback-more-option reply-menu" aria-hidden="true" target=".reply-option' + discussion.id + '" collapsed="true"></i>' +
            '                                            </h4>' +
            '                                            <p id="content'+discussion.id+'">' + discussion.content + '</p>' +
            '                                        </div>' +
            '                                    </div>' +
            '<div class="feedback-panel feedback-reply edit' + discussion.id + '" id="deleteReply' + discussion.id + '" style="display: none;" >' +
            '                                        <a class="float-left">' +
            '                                            <div class="avatar ">' +
            '                                                <img src="/user/' + discussion.User.id + '/avatar  " />' +
            '                                            </div>' +
            '                                        </a>' +
            '                                        <div class="feedback-body">' +
            '                                            <ul class="feedback-option reply-option' + discussion.id + '" style="display: none">' +
            '                                                <li  value="' + discussion.id + '">Chỉnh sửa</li>' +
            '                                                <li data-toggle="modal" data-target="#removeReplyModal" value="' + discussion.id + '">Xoá trả lời</li>' +
            '                                            </ul>' +
            '                                            <h4 class="feedback-heading">' + discussion.User.fullname + ' <small>· 1 giây trước</small>' +
            '                                            <i class="fa fa-ellipsis-v feedback-more-option reply-menu" aria-hidden="true" target=".reply-option' + discussion.id + '" collapsed="true"></i>' +
            '                                            </h4>' +
            '                                            <div class="editor">' +
            '                                                <textarea name="name" class="form-textarea" id="txtReplyContent' + discussion.id + '">' + discussion.content + '</textarea>' +
            '                                            </div>' +
            '                                            <div class="feedback-footer feedback-edit-reply">\n' +
            '                                                <button class="button primary-button save-reply" value="' + discussion.id + '">Lưu</button>' +
            '                                                <button class="button danger-outline-button cancel-save-reply">Huỷ</button>' +
            '                                            </div>\n' +
            '                                        </div>\n' +
            '                                    </div>';
    };

    var addDiscussionElm = function (discussion) {
        return '                <div class="feedback-panel feedback-main-topic " value="' + discussion.id + '" id="feedback' + discussion.id + '">' +
            '                    <a class="float-left ">' +
            '                        <div class="avatar ">' +
            '                            <img src="/user/' + discussion.User.id + '/avatar " />' +
            '                        </div>' +
            '                    </a>' +
            '                    <div class="feedback-body" id="feedback-body"'+discussion.id+'">' +
            '                               <ul class="feedback-option feedback-choice' + discussion.id + '" style="display: none">' +
            '                                    <li class="editDiscussion"  value="'+discussion.id+'" >Sửa thảo luận</li>' +
            '                                    <li value="' + discussion.id + '" data-toggle="modal" data-target="#removeFeedbackModal"" >Xoá thảo luận</li>' +
            '                                </ul>' +
            '                        <h4 class="feedback-heading ">' + discussion.User.fullname + '<small>· 1 giây trước </small>' +
            '                        <i class="fa fa-ellipsis-v feedback-more-option feedback-menu" aria-hidden="true" target=".feedback-choice' + discussion.id + '" collapsed="true"></i>' +
            '                        </h4>' +
            '                        <p class="contentFeedback'+discussion.id+'">' + discussion.content + ' </p>' +
            '                        <div class="editor txtDiscussionContent'+discussion.id+'" style="display: none" >' +
            '                                    <textarea name="name" class="form-textarea discussionContent'+discussion.id+'" >'+discussion.content+'</textarea>' +
            '                        </div>' +
            '                        <div class="feedback-footer feedback-edit-reply actionDiscussionContent'+discussion.id+'" style="display: none">' +
            '                                     <button class="button primary-button save-discussion">Lưu</button>' +
            '                                    <button class="button danger-outline-button cancel-save-discussion">Huỷ</button>\n' +
            '                        </div>' +
            '                        <div class="feedback-footer ">' +
            '                            <button class="reply-btn"><i class="fa fa-reply "></i> Trả lời</button>' +
            '                        </div>' +
            '                       <div id="contentReply' + discussion.id + '">' +
            '                             <div class="feedback-panel feedback-reply reply' + discussion.id + '" style="display: none">' +
            '                                    <a class="float-left ">' +
            '                                        <div class="avatar ">' +
            '                                            <img src="/user/' + variables.userId +'/avatar" />' +
        '                                        </div>' +
        '                                    </a>' +
        '                                    <div class="feedback-body ">' +
        '                                        <textarea class="form-control-transparent reply-feedback" placeholder="Viết thảo luận cho ' + discussion.User.fullname + '" id="replyContent' + discussion.id + '"></textarea>' +
        '                                        <div class="feedback-footer ">' +
        '                                            <button class="sendReply" value="' + discussion.id + '"><i class="fa fa-reply "></i>' +
        '                                                    &nbsp;Gửi trả lời</button>' +
        '                                        </div>' +
        '                                    </div>' +
        '                                </div>' +
        '                           </div>' +
        '                     </div>' +
        '                </div>';
    };


    //end discussion of lecture
    return {};
}