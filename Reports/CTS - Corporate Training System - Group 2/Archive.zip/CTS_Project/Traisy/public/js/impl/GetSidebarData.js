function GetSidebarData(dataType) {

    var getPlanNavItem = function(plan) {
        return '<li class="course-item"><a href="/quan-ly-ke-hoach/' + plan.titleUrl +'"><span class="nav-item-name">' + plan.title +'</span></a></li>';
    };

    if (dataType == 'PLAN') {
        var getTopPlanUrl = "/plan/getTopPlans?top=5";

        var onSuccess = function(data) {
            if (data.length > 0) {
                $('.minor-navigator .nav-title').html('<a href="/quan-ly-ke-hoach">Danh sách kế hoạch</a>');
                for (var i = 0; i < data.length; i++) {
                    $('.minor-navigator .nav-items').append(getPlanNavItem(data[i]));
                }
            } else {
                $('.minor-navigator').hide();
            }
        };

        Utils.callJsonAjax(getTopPlanUrl, 'GET', undefined, onSuccess);
    }
    if (dataType == 'COURSE') {
        // var getTopPlanUrl = "/plan/getTopPlans?top=5";
        //
        // var onSuccess = function(data) {
        //     console.log(data);
        // };
        //
        // Utils.callJsonAjax(getTopPlanUrl, 'GET', undefined, onSuccess);
    }

    var getReviewingCoursesUrl = "/course/get-reviewing-courses";
    var getReviewingCourses = function() {
        var onSuccess = function(data) {
            if (data.count && data.count > 0) {
                $('.dot-notification').show();
                $('.number-course-review').text(data.count);
            }
        };

        Utils.callJsonAjax(getReviewingCoursesUrl, 'GET', undefined, onSuccess);
    };

    return {
        getReviewingCourses: getReviewingCourses
    }

}