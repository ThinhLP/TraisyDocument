$(document).ready(function(){
  $('#slides').presentation();
});