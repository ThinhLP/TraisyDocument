package models;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Table(name = "learner_process")
public class LearnerProcess implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "status")
    public int status;

    @Basic
    @Column(name = "last_learning_date")
    public Timestamp lastLearningDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    public User User;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_lecture_id")
    public CourseLecture CourseLecture;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id")
    public Course Course;

}
