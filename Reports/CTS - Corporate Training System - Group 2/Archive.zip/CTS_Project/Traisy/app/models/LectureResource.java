package models;

public class LectureResource {
}
