package models;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "plan")
public class Plan implements Serializable, Comparable<Plan> {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "title")
    public String title;

    @Basic
    @Column(name = "start_date")
    public Timestamp startDate;

    @Basic
    @Column(name = "end_date")
    public Timestamp endDate;

    @Basic
    @Column(name = "description")
    public String description;

    @Basic
    @Column(name = "plan_image")
    public byte[] planImage;

    @Basic
    @Column(name = "title_url")
    public String titleUrl;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    public User User;

    @OneToMany(mappedBy = "Plan")
    public List<Program> Programs;

    @Basic
    @Column(name = "status")
    public int status;

    @OneToMany(mappedBy = "Plan")
    public List<Course> Courses;

    @OneToMany(mappedBy = "Plan")
    public List<PlanParticipant> PlanParticipants;

    @Override
    public int compareTo(Plan o) {
        Timestamp end1 = this.endDate, end2 = o.endDate;
        long currentTime = new Date().getTime();
        if (end1 == null) {
            end1 = new Timestamp(currentTime);
        }
        if (end2 == null) {
            end2 = new Timestamp(currentTime);
        }
        int outOfDate1 = end1.getTime() < currentTime ? -1 : 1;
        int outOfDate2 = end2.getTime() < currentTime ? -1 : 1;
        return outOfDate2 - outOfDate1;
    }
}
