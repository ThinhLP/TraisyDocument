package models;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "brand")
public class Brand  implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public int id;

    @Basic
    @Column(name = "name")
    public String name;

    @Basic
    @Column(name = "logo")
    public byte[] logo;

    @Basic
    @Column(name = "description")
    public String description;

    @Basic
    @Column(name = "status")
    public int status;

    @OneToMany(mappedBy = "Brand")
    public List<User> Users;

}
