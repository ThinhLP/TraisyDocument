package models;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "question")
public class Question implements Serializable, Comparable<Question> {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "content")
    public String content;

    @Basic
    @Column(name = "type")
    public int type;

    @Basic
    @Column(name = "explaination")
    public String explaination;

    @Basic
    @Column(name = "`order`")
    public int order;

    @ManyToOne
    @JoinColumn(name = "quiz_id")
    public Quiz Quiz;

    @OneToMany(mappedBy = "Question", cascade = CascadeType.ALL)
    public List<Answer> Answers;

    @OneToMany(mappedBy = "Question", cascade = CascadeType.ALL)
    public List<LearnerQuizDetail> LearnerQuizDetails;

    @Override
    public int compareTo(Question o) {
        return this.order - o.order;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Question) {
            return this.id == ((Question) obj).id;
        }
        return false;
    }
}
