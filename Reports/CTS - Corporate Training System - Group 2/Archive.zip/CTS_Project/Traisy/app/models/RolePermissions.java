package models;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "role_permissions")
public class RolePermissions implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public int id;

    @Basic
    @Column(name = "permission")
    public String permission;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "role_id")
    public Role Role;

}
