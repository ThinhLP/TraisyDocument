package models;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "course_lecture", schema = "traisydb", catalog = "")
public class CourseLecture implements Serializable, Comparable<CourseLecture> {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "title")
    public String title;

    @Basic
    @Column(name = "title_url")
    public String titleUrl;

    @Basic
    @Column(name = "`order`")
    public int order;

    @Basic
    @Column(name = "status")
    public int status;

    @Basic
    @Column(name = "type")
    public int type;

    @ManyToOne()
    @JoinColumn(name = "course_section_id")
    public CourseSection CourseSection;

    @ManyToOne()
    @JoinColumn(name = "course_id")
    public Course Course;

    @Basic
    @Column(name = "lecture_file")
    public String lectureFile;

    @Basic
    @Column(name = "duration")
    public Integer duration = 0;

    @Basic
    @Column(name = "note")
    public String note;

    @OneToOne
    @JoinColumn(name = "quiz_id")
    public Quiz Quiz;

    @Override
    public int compareTo(CourseLecture o) {
        return this.order - o.order;
    }

}
