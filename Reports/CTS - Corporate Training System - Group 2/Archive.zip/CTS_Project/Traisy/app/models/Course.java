package models;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

@Entity
@Table(name = "course")
public class Course implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "title")
    public String title;

    @Basic
    @Column(name = "title_url")
    public String titleUrl;

    @Basic
    @Column(name = "description")
    public String description;

    @Basic
    @Column(name = "duration")
    public Integer duration;

    @Basic
    @Column(name = "created_date")
    public Timestamp createdDate;

    @Basic
    @Column(name = "updated_date")
    public Timestamp updatedDate;

    @Basic
    @Column(name = "status")
    public int status;

    @Basic
    @Column(name = "intro_image")
    public byte[] introImage;

    @Column(name="intro_video")
    public String introVideo;

    @ManyToOne()
    @JoinColumn(name = "plan_id")
    public Plan Plan;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "program_id")
    public Program Program;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    public User User;

    @OneToMany(mappedBy="Course")
    public List<CourseSection> CourseSections;

    @OneToMany(mappedBy="Course")
    public List<CourseLecture> CourseLectures;

    @OneToMany(mappedBy="Course")
    public List<CourseEnroll> CourseEnrolls;

    @ManyToMany(mappedBy="Courses")
    public List<Skill> Skills;
}
