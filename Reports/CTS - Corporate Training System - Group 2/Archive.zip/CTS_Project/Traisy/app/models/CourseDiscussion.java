package models;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "course_discussion")
public class CourseDiscussion implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "content")
    public String content;

    @Basic
    @Column(name = "status")
    public int status;

    @Basic
    @Column(name = "created_date")
    public Timestamp createdDate;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    public User User;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_lecture_id")
    public CourseLecture CourseLecture;


    @OneToMany(mappedBy = "parentId")
    public List<CourseDiscussion> courseDiscussionList;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    public CourseDiscussion parentId;
}
