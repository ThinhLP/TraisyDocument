package models;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "role")
public class Role implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id")
    public int id;

    @Basic
    @Column(name = "role_name")
    public String roleName;

    @OneToMany(mappedBy = "Role")
    public List<User> Users;
}
