package models;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "learner_quiz")
public class LearnerQuiz implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "score")
    public double score;

    @Basic
    @Column(name = "date")
    public Timestamp date;

    @Basic
    @Column(name = "result")
    public int result;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    public User User;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "quiz_id")
    public Quiz Quiz;

    @OneToMany(mappedBy = "LearnerQuiz", cascade = CascadeType.ALL)
    public List<LearnerQuizDetail> LearnerQuizDetails;

}
