package models;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "learner_quiz_detail")
public class LearnerQuizDetail implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @ManyToOne()
    @JoinColumn(name = "learner_quiz_id")
    public LearnerQuiz LearnerQuiz;

    @ManyToOne()
    @JoinColumn(name = "question_id")
    public Question Question;

    @ManyToOne()
    @JoinColumn(name = "answer_id")
    public Answer Answer;

    @Column(name = "answer_content")
    public String answerContent;

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof LearnerQuizDetail) {
            return this.id == ((LearnerQuizDetail) obj).id;
        }
        return false;
    }
}
