package models;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "course_feedback_reply")
public class CourseFeedbackReply implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    public long id;

    @Column(name="created_date")
    public Timestamp created_date;

    @Column(name="content")
    public String content;

    @ManyToOne
    @JoinColumn(name="course_feedback_id")
    public CourseFeedback CourseFeedback;

    @ManyToOne
    @JoinColumn(name="user_id")
    public User User;

    @Column(name="status")
    public int status = 1;

    public CourseFeedbackReply() {

    }

}
