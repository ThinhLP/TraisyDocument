package models;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "course_section")
public class CourseSection implements Serializable, Comparable<CourseSection> {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "title")
    public String title;

    @Basic
    @Column(name = "`order`")
    public int order;

    @ManyToOne()
    @JoinColumn(name = "course_id")
    public Course Course;

    @OneToMany(mappedBy="CourseSection")
    public List<CourseLecture> CourseLectures;

    @Override
    public int compareTo(CourseSection o) {
        return this.order - o.order;
    }
}
