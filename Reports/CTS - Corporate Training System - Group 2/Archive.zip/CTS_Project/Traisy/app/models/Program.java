package models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "program")
public class Program implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "title")
    public String title;

    @Basic
    @Column(name = "description")
    public String description;

    @Basic
    @Column(name = "start_date")
    public Timestamp startDate;

    @Basic
    @Column(name = "end_date")
    public Timestamp endDate;

    @Basic
    @Column(name = "status")
    public int status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "plan_id")
    public Plan Plan;

    @OneToMany(mappedBy = "Program")
    public List<Course> Courses;

    public Program() {
    }


    public Program(String title, String description, Timestamp startDate, Timestamp endDate, models.Plan plan, List<Course> courses) {
        this.title = title;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        Plan = plan;
        Courses = courses;
    }

    public Program(String title, String description, Timestamp startDate, Timestamp endDate) {
        this.title = title;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
    }


}
