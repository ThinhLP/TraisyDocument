package models;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "quiz")
public class Quiz implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "duration")
    public Integer duration;

    @Basic
    @Column(name = "no_of_questions")
    public Integer noOfQuestions;

    @Basic
    @Column(name = "min_score")
    public Double minScore;

    @OneToMany(mappedBy = "Quiz", cascade = CascadeType.ALL)
    public List<LearnerQuiz> LearnerQuizs;

    @OneToMany(mappedBy = "Quiz", cascade = CascadeType.ALL)
    public List<Question> Questions;
}
