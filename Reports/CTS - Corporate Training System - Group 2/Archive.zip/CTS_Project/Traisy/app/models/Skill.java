package models;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "skill")
public class Skill implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public int id;

    @Basic
    @Column(name = "title")
    public String title;

    @Basic
    @Column(name = "description")
    public String description;

    @ManyToMany
    @JoinTable(
            name="course_skill"
            , joinColumns={
            @JoinColumn(name="skill_id")
    }
            , inverseJoinColumns={
            @JoinColumn(name="course_id")
    }
    )
    public List<Course> Courses;
}
