package models;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "user")
public class User implements Serializable, Comparable<User> {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "username")
    public String username;

    @Basic
    @Column(name = "password")
    public String password;

    @Basic
    @Column(name = "fullname")
    public String fullname;

    @Basic
    @Column(name = "avatar")
    public byte[] avatar;

    @Basic
    @Column(name = "title")
    public String title;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "brand_id")
    public Brand Brand;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "role_id")
    public Role Role;

    @Basic
    @Column(name = "salt")
    public String salt;

    @Basic
    @Column(name = "status")
    public int status;


    @Override
    public int compareTo(User o) {
        return this.Role.id - o.Role.id;
    }
}
