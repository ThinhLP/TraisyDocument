package models;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "answer")
public class Answer implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Basic
    @Column(name = "content")
    public String content;

    @Basic
    @Column(name = "is_correct")
    public int isCorrect;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="question_id")
    public Question Question;

    @OneToMany(mappedBy = "Answer", cascade = CascadeType.ALL)
    public List<LearnerQuizDetail> LearnerQuizDetail;

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Answer) {
            return this.id == ((Answer) obj).id;
        }
        return false;
    }
}
