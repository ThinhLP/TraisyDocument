package models;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "course_feedback")
public class CourseFeedback implements Serializable{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    public long id;

    @Column(name="created_date")
    public Timestamp createdDate;

    @Column(name = "content")
    public String content;

    @Column(name="status")
    public int status;

    @Column(name="title")
    public String title;

    @ManyToOne
    @JoinColumn(name="course_id")
    public Course Course;

    @ManyToOne
    @JoinColumn(name="user_id")
    public User User;

    @OneToMany(mappedBy="CourseFeedback")
    public List<CourseFeedbackReply> CourseFeedbackReplies;

    @OneToMany(mappedBy = "parentId")
    public List<CourseFeedback> feedbackReplies;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    public CourseFeedback parentId;

    public CourseFeedback() {
    }
}
