package services;

import com.google.inject.ImplementedBy;
import models.Role;
import services.impl.CourseSectionServiceImpl;

@ImplementedBy(CourseSectionServiceImpl.class)
public interface RoleService {
    Role findRoleById(int id);
}
