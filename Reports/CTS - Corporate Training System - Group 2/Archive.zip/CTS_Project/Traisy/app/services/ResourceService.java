package services;

import com.google.inject.ImplementedBy;
import services.impl.ResourceServiceImpl;

import java.io.File;

@ImplementedBy(ResourceServiceImpl.class)
public interface ResourceService {
    File findResourceFile(String fileName);
}
