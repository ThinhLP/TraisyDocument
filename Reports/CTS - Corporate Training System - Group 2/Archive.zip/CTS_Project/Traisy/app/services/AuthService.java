package services;

import com.google.inject.ImplementedBy;
import models.User;
import services.impl.AuthServiceImpl;

@ImplementedBy(AuthServiceImpl.class)
public interface AuthService {

    boolean isAlreadyLogin();

    boolean isSystemAdmin(User user);

    boolean isAdmin(User user);

    boolean isManager(User user);

    boolean isAuthor(User user);

    boolean isLearner(User user);

    boolean isAdminOrManager(User user);

    boolean isAuthorOrLearner(User user);




}
