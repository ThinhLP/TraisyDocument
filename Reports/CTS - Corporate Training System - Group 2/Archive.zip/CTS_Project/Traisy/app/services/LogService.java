package services;

import play.Logger;
import play.mvc.Http;

public class LogService {

    /**
     * The constant logger.
    * This log keeps all the info regarding user's assess to the site
    * And store in the log file named access.log
    * The name 'access' is define in the logback.xml file
    * */
    public static final Logger.ALogger logger = Logger.of("access");

    /**
     * Gets client info.
     *
     * @param requestHeader the request header
     * @return the client info
     */
    public static String getClientInfo(Http.RequestHeader requestHeader) {
        return String.format("uri: %s | remote address: %s | host: %s | path: %s", requestHeader.uri(),
                requestHeader.remoteAddress(), requestHeader.host(), requestHeader.path());
    }
}
