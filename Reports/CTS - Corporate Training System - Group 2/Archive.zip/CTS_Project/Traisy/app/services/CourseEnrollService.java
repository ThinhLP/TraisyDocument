package services;

import com.google.inject.ImplementedBy;
import models.*;
import services.impl.CourseEnrollServiceImpl;
import services.impl.CourseSectionServiceImpl;

import java.util.List;

@ImplementedBy(CourseEnrollServiceImpl.class)
public interface CourseEnrollService {

    List<User> findUsersEnrollInCourse(long courseId);

    CourseEnroll getUserEnroll(long courseId, long userId);

    void updateLearnerLearningProgress(User user, Course course, CourseLecture lecture);

    void updateCourseEnroll(User user, Course course);

}
