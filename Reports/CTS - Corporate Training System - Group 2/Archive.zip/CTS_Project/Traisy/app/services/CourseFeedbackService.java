package services;

import com.google.inject.ImplementedBy;
import fronts.CourseFeedbackData;
import models.CourseDiscussion;
import models.CourseFeedback;
import services.impl.CourseFeedbackServiceImpl;
import services.impl.DiscussionServiceImpl;

import java.sql.Timestamp;
import java.util.List;

@ImplementedBy(CourseFeedbackServiceImpl.class)
public interface CourseFeedbackService {

    List<CourseFeedback> getAllFeedbackByCourse(String courseTitle);

    CourseFeedbackData addFeedback(String title, String content, Timestamp createDate,long parentId, int status, long userId, long courseId);

    boolean updateFeedback(long id, String title, String content, Timestamp createDate, int status);

    boolean removeFeedback(long id);

    CourseFeedbackData convertToData(CourseFeedback courseFeedback);

}
