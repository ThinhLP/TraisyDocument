package services;

import com.google.inject.ImplementedBy;
import services.impl.LearnerProcessServiceImpl;
import models.LearnerProcess;

import java.util.List;

@ImplementedBy(LearnerProcessServiceImpl.class)
public interface LearnerProcessService {
    List<LearnerProcess> getFinishProcessOfUserAndCourse(long userId, long courseId, int status);

    boolean updateLearnerProcess(long userId, long courseId, long lectureId);
}
