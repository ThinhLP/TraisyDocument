package services;

import com.google.inject.ImplementedBy;
import models.Brand;
import models.User;
import play.mvc.Http;
import services.impl.BrandServiceImpl;
import services.impl.UserServiceImpl;
import java.io.File;
import java.util.List;


@ImplementedBy(BrandServiceImpl.class)
public interface BrandService {

    Brand createSimpleBrand(String title);

    void updateBrandImage(int id, File file);

    Brand findBrandById(int id);

    List<Brand> findAllBrand();

    boolean removeBrand(int id);

    boolean updateBrand(int id, String name, String description);

}
