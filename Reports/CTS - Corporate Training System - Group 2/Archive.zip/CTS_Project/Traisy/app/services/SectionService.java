package services;

import com.google.inject.ImplementedBy;
import fronts.CourseSectionData;
import models.Course;
import models.CourseSection;
import services.impl.SectionServiceImpl;

import java.util.List;

@ImplementedBy(SectionServiceImpl.class)
public interface SectionService {

    CourseSection findSectionById(long id);
    CourseSectionData createSection(Course course, String title);
    boolean updateSection(long sectionId, String title);
    boolean removeSection(long sectionId);
    CourseSectionData convertToSectionData(CourseSection section);
    List<CourseSectionData> convertToListSectionData(List<CourseSection> sections);
    List<CourseSection> getAllSectionWithPublishLecture(long courseId);
}
