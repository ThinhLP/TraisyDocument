package services;

import com.google.inject.ImplementedBy;
import fronts.CourseSectionData;
import models.Course;
import models.CourseSection;
import services.impl.CourseSectionServiceImpl;

import java.util.List;

/**
 * create by hung
 */
@ImplementedBy(CourseSectionServiceImpl.class)
public interface CouseSectionService {
    //    CourseSectionData createCourseSection(String )
    CourseSection findSectionById(long id);

    CourseSection createCourseSection(String title, long courseId);

    List<CourseSection> getAllSectionByCourseId(long courseId);

    boolean updateCourseSection(long sectionId, int order);

    boolean removeCourseSection(long id);

    void reorderCourseSection(List<CourseSection> courseSections);

}
