package services;

import com.google.inject.ImplementedBy;
import fronts.CourseDiscussionData;
import models.CourseDiscussion;
import services.impl.DiscussionServiceImpl;

import java.sql.Timestamp;
import java.util.List;

@ImplementedBy(DiscussionServiceImpl.class)
public interface DiscussionService {

    List<CourseDiscussionData> getAllDiscussion(long courseLectureId);

    List<CourseDiscussionData> getAllDisscussionByCourse(String courseTitle);
    List<CourseDiscussion> getAllDiscussionOfLectureId(long courseLectureId);

    CourseDiscussionData addDiscussion(String content, Timestamp createDate, long parentId, long userId, int status, long courseLectureId);

    boolean updateDiscussion(long id, String content, Timestamp createDate);

    boolean removeDiscussion(long id);

}
