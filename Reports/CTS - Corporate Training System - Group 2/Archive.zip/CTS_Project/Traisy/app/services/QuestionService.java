package services;

import com.google.inject.ImplementedBy;
import fronts.QuestionData;
import models.CourseSection;
import models.Question;
import models.Quiz;
import services.impl.CourseSectionServiceImpl;
import services.impl.QuestionServiceImpl;

import java.util.List;
import java.util.Map;

/**
 * create by hung
 */
@ImplementedBy(QuestionServiceImpl.class)
public interface QuestionService {

    List<Question> getAllQuestionByQuizId(long quizId);

    List<Question> getAllQuestion();

    Question findQuestion(long id);

    QuestionData createQuestion(Quiz quiz, QuestionData questionData);

    boolean updateQuestion(Question question, String content, String explaination);

    boolean removeQuestion(Question question);

}
