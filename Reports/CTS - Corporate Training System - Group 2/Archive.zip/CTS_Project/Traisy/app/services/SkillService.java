package services;

import com.google.inject.ImplementedBy;
import fronts.SkillData;
import models.Brand;
import models.Skill;
import services.impl.BrandServiceImpl;
import services.impl.SkillServiceImpl;

import java.io.File;
import java.util.List;


@ImplementedBy(SkillServiceImpl.class)
public interface SkillService {

    Skill findSkillById(int id);

    List<Skill> findAllSkill();

    boolean removeSkill(int id);

    boolean updateSkill(int id, String title, String description);

    Skill createSkill(String title, String description);

    Skill addSkillToCourse(long courseId, int skillId);

    Skill removeSkillFromCourse(long courseId, int skillId);

    boolean addSkillsToCourse(long courseId, List<Skill> skillList);

    SkillData convertToSkillData(Skill skill);

    List<SkillData> convertToListSkillData(List<Skill> skills);
}
