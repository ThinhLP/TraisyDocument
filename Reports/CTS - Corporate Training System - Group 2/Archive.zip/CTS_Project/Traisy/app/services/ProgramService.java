package services;

import com.google.inject.ImplementedBy;
import fronts.ProgramData;
import models.Plan;
import models.Program;
import models.User;
import services.impl.ProgramServiceImpl;

import java.util.List;

@ImplementedBy(ProgramServiceImpl.class)
public interface ProgramService {
    ProgramData createProgram(String title, String description, String startDate, String endDate, long planId);

    boolean updateProgram(long id, String title, long startDate, long endDate);

    List<ProgramData> listAllProgramByPlanId(long planId);

    boolean removeProgram(long id);

    ProgramData createSimpleProgram(Plan plan, String title, long startDate, long endDate);

    ProgramData convertToProgramData(Program program);

    List<ProgramData> convertToListProgramData(List<Program> programs, long currentUserId);

}
