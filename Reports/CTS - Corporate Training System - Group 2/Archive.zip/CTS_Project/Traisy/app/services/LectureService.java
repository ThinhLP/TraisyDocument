package services;

import com.google.inject.ImplementedBy;
import fronts.CourseLectureData;
import models.Course;
import models.CourseLecture;
import models.User;
import play.mvc.Http;
import services.impl.LectureServiceImpl;

import javax.persistence.EntityManager;
import java.util.List;

@ImplementedBy(LectureServiceImpl.class)
public interface LectureService {
    CourseLectureData createSimpleLecture(long sectionId, String lectureTitle);

    CourseLecture findLectureById(long lectureId);

    CourseLecture findLectureByTitleUrl(String titleUrl);

    CourseLecture findLectureByTitleUrl(String titleUrl, EntityManager em);

    boolean updateLectureFile(long lectureId, String lectureFile);

    List<CourseLecture> getAllLectureByCourseId(long courseId);

    CourseLectureData updateLecture(long lectureId, String lectureTitle, int status);

    boolean updateLectureType(long lectureId, int type);

    boolean deleteAllLecturesOfSection(long sectionId);

    boolean deleteLecture(long lectureId);

    boolean updateLectureStatus(long id, int status);

    CourseLecture getLectureByTitleUrl(String titleUrl);

    CourseLecture uploadLectureVideo(long lectureId, Http.MultipartFormData.FilePart filePart);

    CourseLecture uploadLectureText(long lectureId, Http.MultipartFormData.FilePart filePart);

    CourseLecture uploadLectureSlideshow(long lectureId, Http.MultipartFormData.FilePart filePart);

    byte[] getLectureTextContent(long lectureId);

    byte[] getLectureTextContent(CourseLecture lecture);

    List<byte[]> getLectureSlideshow(long lectureId);

    List<byte[]> getLectureSlideshow(CourseLecture lecture);

    boolean isCourseOwner(long lectureId, User user);

    CourseLecture getFirstPublicLecture(long courseId);

    CourseLecture getLastLearningLecture(long userId, long courseId);

    CourseLecture getPreviousLecture(Course course, CourseLecture currentLecture);

    CourseLecture getNextLecture(Course course, CourseLecture currentLecture);

    List<CourseLectureData> convertToListLectureData(List<CourseLecture> courseLectures);

}
