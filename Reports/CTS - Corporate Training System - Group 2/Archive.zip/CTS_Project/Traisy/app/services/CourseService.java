package services;

import com.google.inject.ImplementedBy;
import fronts.CourseData;
import fronts.SimpleCourseData;
import fronts.SimplePlanData;
import fronts.learning.LearningCourseData;
import fronts.order.CourseOrder;
import models.Course;
import models.Plan;
import models.User;
import play.mvc.Http;
import services.impl.CourseServiceImpl;

import java.io.File;
import java.util.List;

@ImplementedBy(CourseServiceImpl.class)
public interface CourseService {

    Course findCourseById(long id);

    Course findCourseByTitleUrl(String titleUrl);

    List<CourseData> listAllCourse();

    List<CourseData> listAllCourseByPlanId(long planId);

    List<CourseData> listAllCourseByUserId(long userId);

    List<CourseData> listAllCourseByProgramId(long programId);

    CourseData createSimpleCourse(User user, Plan plan, long programId, String title);

    boolean updateCourseIntro(Course course, String title, String description);

    boolean uploadCourseImage(File file, Course course);

    CourseData convertToCourseData(Course course);

    List<CourseData> convertToCourseDataList(List<Course> courses, long currentUserId);

    List<CourseData> convertToCourseDataList(List<Course> courses);

    void resetCourseSecLecOrders(CourseOrder courseOrder);

    boolean updateCourseStatus(Course course, int status);
                               
    Course uploadIntroVideo(long courseId, Http.MultipartFormData.FilePart videoFile);

    double getCourseLearnerProcess(User user, Course course);

    LearningCourseData createLearningCourseData(Course course, User user);

    int getNoOfReviewingCourses(int brandId);

    List<SimplePlanData> getReviewingCourses(int brandId);
    List<SimplePlanData> getTeachingCourses(long userId);



}
