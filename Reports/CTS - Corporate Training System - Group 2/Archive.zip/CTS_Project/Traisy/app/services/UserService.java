package services;

import com.google.inject.ImplementedBy;
import fronts.UserData;
import models.User;
import play.mvc.Http;
import services.impl.UserServiceImpl;

import java.io.File;
import java.util.List;

@ImplementedBy(UserServiceImpl.class)
public interface UserService {

    boolean login(String username, String password, Http.RequestHeader requestHeader);

    void logout();

    User getCurrentUser();

    boolean isLockedUser(String username);

    User findUser(long id);

    User findUser(String username);

    boolean updateAccount(User currentUser, String newPassword, String newFullname, String newTitle, int roleId, int status);

    boolean updateAccountForLearner(long id,String currentPassword, String newPassword, String newFullname, String newTitle);

    boolean createAccount(String username, String password, String fullname, String title, int brandId, int roleId, int status);

    List<User> listAllUserByBrandId(int brandId);

    boolean removeAllUserOfBrand(int brandId);

    UserData convertToUserData(User user);

    List<UserData> findUsersEnrollInCourse(long courseId);

    void updateUserImage(long id, File file);

}
