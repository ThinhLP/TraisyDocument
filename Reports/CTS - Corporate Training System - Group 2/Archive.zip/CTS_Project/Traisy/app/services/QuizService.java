package services;

import com.google.inject.ImplementedBy;
import fronts.QuestionData;
import fronts.quiz.LearnerQuizResult;
import fronts.quiz.QuizSubmission;
import models.*;
import services.impl.QuizServiceImpl;

import javax.persistence.EntityManager;
import java.util.List;

@ImplementedBy(QuizServiceImpl.class)
public interface QuizService {

    Quiz findQuizById(long quizId);

    CourseLecture findLectureByQuizId(long quizId);

    boolean updateQuiz(CourseLecture lecture, int duration, double score);

    void descreaseNoOfQuestion(Quiz quiz);

    boolean evaluateSubmission(CourseLecture lecture, User user, QuizSubmission submission);

    LearnerQuiz getLastLearnerQuiz(long userId, long quizId);

    LearnerQuiz getLastLearnerQuiz(long userId, long quizId, EntityManager em);

    List<LearnerQuizResult> convertToLearnerLearnerQuizResult(Quiz quiz, List<LearnerQuizDetail> learnerQuizDetails);


}
