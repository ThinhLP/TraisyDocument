package services.impl;

import commons.TSConst;
import commons.Utils;
import controllers.Application;
import daos.BrandDao;
import daos.RoleDao;
import daos.UserDao;
import models.Brand;
import models.Role;
import models.User;
import org.apache.shiro.authc.*;
import org.apache.shiro.crypto.RandomNumberGenerator;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.apache.shiro.subject.Subject;
import play.db.jpa.JPAApi;
import play.mvc.Http;
import services.BrandService;
import services.LogService;
import services.UserService;

import javax.inject.Inject;
import java.io.File;
import java.util.List;


public class BrandServiceImpl implements BrandService {

    @Inject
    private JPAApi jpaApi;
    @Inject
    private BrandDao brandDao;
    @Inject
    UserDao userDao;

    @Override
    public Brand createSimpleBrand(String title) {
        Brand brand = new Brand();
        brand.name = title;
        return brandDao.createBrand(brand, jpaApi.em());
    }

    @Override
    public void updateBrandImage(int id, File file) {
        byte[] picData = Utils.getBytesFromFile(file);
        Brand brand = brandDao.findBrandById(id, jpaApi.em());
        brand.logo = picData;
        brandDao.updateBrand(brand, jpaApi.em());
    }
  
    @Override
    public Brand findBrandById(int id) {
        return brandDao.findBrandById(id, jpaApi.em());
    }
  
    @Override
    public List<Brand> findAllBrand() {
        return brandDao.getAllBrand(jpaApi.em());
    }

    @Override
    public boolean removeBrand(int id) {
        return brandDao.removeBrand(id, jpaApi.em());
    }

    @Override
    public boolean updateBrand(int id, String name, String description) {
        Brand brand = brandDao.findBrandById(id, jpaApi.em());
        brand.description = description;
        brand.name = name;
        boolean result = brandDao.updateBrand(brand, jpaApi.em());
        return result;
    }
}
