package services.impl;

import com.fasterxml.jackson.databind.node.ObjectNode;
import commons.TSConst;
import commons.Utils;

import daos.*;
import fronts.CourseData;
import fronts.SimpleCourseData;
import fronts.SimplePlanData;
import fronts.learning.LearningCourseData;
import fronts.learning.LearningLectureData;
import fronts.learning.LearningSectionData;
import fronts.order.CourseOrder;
import fronts.order.LectureOrder;
import fronts.order.SectionOrder;
import models.*;
import play.db.jpa.JPA;
import play.db.jpa.JPAApi;
import play.mvc.Http;
import services.*;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.util.*;

public class CourseServiceImpl implements CourseService {

    @Inject private JPAApi jpaApi;
    @Inject private CourseDao courseDao;
    @Inject private PlanDao planDao;
    @Inject private ProgramDao programDao;
    @Inject private UserService userService;
    @Inject private CourseSectionDao courseSectionDao;
    @Inject private CourseLectureDao courseLectureDao;
    @Inject private LectureService lectureService;
    @Inject private LearnerProcessDao learnerProcessDao;
    @Inject private UploadService uploadService;
    @Inject SectionService sectionService;
    @Inject SkillService skillService;

    /**
     * find course according to course id
     *
     * @param id
     * @return
     */
    @Override
    public Course findCourseById(long id) {
        return courseDao.findCourseById(id, jpaApi.em());
    }

    @Override
    public Course findCourseByTitleUrl(String titleUrl) {
        return courseDao.findCourseByTitleUrl(titleUrl, jpaApi.em());
    }

    /**
     * find all course
     *
     * @return
     */
    @Override
    public List<CourseData> listAllCourse() {
        List<CourseData> courseDataList = new ArrayList<>();

        List<Course> courses = courseDao.getAllCourse(jpaApi.em());

        for (Course course :
                courses) {
            CourseData temp = new CourseData();
            temp.id = course.id;
            temp.title = course.title;
            temp.titleUrl = course.titleUrl;
            temp.description = course.description;
            temp.duration = course.duration;
            temp.createdDate = course.createdDate;
            temp.updatedDate = course.updatedDate;
            temp.status = course.status;
            temp.introImage = course.introImage;
            courseDataList.add(temp);
        }

        return courseDataList;
    }


    /**
     * find course according to plan
     *
     * @param planId
     * @return
     */
    @Override
    public List<CourseData> listAllCourseByPlanId(long planId) {
        List<CourseData> courseDataList = new ArrayList<>();

        List<Course> courses = courseDao.getAllCourseByPlanId(planId, jpaApi.em());

        for (Course course :
                courses) {
            CourseData temp = new CourseData();
            temp.id = course.id;
            temp.title = course.title;
            temp.titleUrl = course.titleUrl;
            temp.description = course.description;
            temp.duration = course.duration;
            temp.createdDate = course.createdDate;
            temp.updatedDate = course.updatedDate;
            temp.status = course.status;
            temp.introImage = course.introImage;
            courseDataList.add(temp);
        }

        return courseDataList;
    }

    /**
     * find all course by user
     *
     * @param userId
     * @return
     */
    @Override
    public List<CourseData> listAllCourseByUserId(long userId) {
        List<CourseData> courseDataList = new ArrayList<>();

        List<Course> courses = courseDao.getAllCourseByUserId(userId, jpaApi.em());

        for (Course course :
                courses) {
            CourseData temp = new CourseData();
            temp.id = course.id;
            temp.title = course.title;
            temp.titleUrl = course.titleUrl;
            temp.description = course.description;
            temp.duration = course.duration;
            temp.createdDate = course.createdDate;
            temp.updatedDate = course.updatedDate;
            temp.status = course.status;
            temp.introImage = course.introImage;
            courseDataList.add(temp);
        }

        return courseDataList;
    }

    /**
     * find all course according to program
     *
     * @param programId
     * @return
     */
    @Override
    public List<CourseData> listAllCourseByProgramId(long programId) {
        List<CourseData> courseDataList = new ArrayList<>();

        List<Course> courses = courseDao.getAllCourseByUserId(programId, jpaApi.em());

        for (Course course :
                courses) {
            CourseData temp = new CourseData();
            temp.id = course.id;
            temp.title = course.title;
            temp.titleUrl = course.titleUrl;
            temp.description = course.description;
            temp.duration = course.duration;
            temp.createdDate = course.createdDate;
            temp.updatedDate = course.updatedDate;
            temp.status = course.status;
            temp.introImage = course.introImage;
            courseDataList.add(temp);
        }

        return courseDataList;
    }


    /**
     * Create course title url
     */
    private String createCourseTitleUrl(String courseTitle, int number) {
        String resultURL;

        resultURL = Utils.removeAccents(courseTitle);
        if (number > 1) {
            resultURL += "-" + number;
        }

        // check if the url has exist
        Course course = courseDao.findCourseByTitleUrl(resultURL, jpaApi.em());
        if (course != null) {
            return createCourseTitleUrl(courseTitle, ++number);
        }

        return resultURL;
    }

    /* Convert to Course Data*/
    public CourseData convertToCourseData(Course course) {
        CourseData data = new CourseData();
        data.id = course.id;
        data.title = course.title;
        data.titleUrl = course.titleUrl;
        data.status = course.status;
        data.createdDate = course.createdDate;
        if (course.description != null){
            data.description = course.description;
        }
        if (course.Skills != null){
            data.Skills = skillService.convertToListSkillData(course.Skills);
        }
        if (course.User.id != 0) {
            data.User = userService.convertToUserData(course.User);
        }
        if (course.CourseSections != null){
            data.CourseSections = sectionService.convertToListSectionData(course.CourseSections);
        }
        // Add more details
        return data;
    }

    /**
     * Convert listCourse to listCourseData, with process of course
     *
     * @param courses
     * @param currentUserId
     * @return
     */
    @Override
    public List<CourseData> convertToCourseDataList(List<Course> courses, long currentUserId) {
        List<CourseData> result = new ArrayList<>();
        for (Course course : courses) {
            CourseData temp = convertToCourseData(course);
            if (course.Program != null){
                temp.Program = course.Program;
            }
            int finishLecture = 0;
            temp.CourseLectures = lectureService.getAllLectureByCourseId(course.id);
            List<LearnerProcess> listLectureOfUserAndCourse = learnerProcessDao.getFinishProcessOfUserAndCourse(
                    currentUserId, course.id, 1, jpaApi.em());
            if (listLectureOfUserAndCourse == null || listLectureOfUserAndCourse.isEmpty()) {
                temp.process = null;
            } else {
                for (LearnerProcess process : listLectureOfUserAndCourse) {
                    for (CourseLecture tempCourseLecture : temp.CourseLectures) {
                        if (process.CourseLecture.id == tempCourseLecture.id && process.status == 1) {
                            finishLecture++;
                        }
                    }
                }
                if (!temp.CourseLectures.isEmpty() && finishLecture != 0) {
                    double process = ((double) finishLecture / (double) temp.CourseLectures.size()) * 100;
                    temp.process = (int) process + "";
                } else {
                    temp.process = "0";
                }
            }
            result.add(temp);
        }
        return result;
    }

    /**
     * Convert listCourse to listCourseData
     *
     * @param courses
     * @return
     */
    @Override
    public List<CourseData> convertToCourseDataList(List<Course> courses) {
        List<CourseData> result = new ArrayList<>();
        for (Course course :
                courses) {
            CourseData temp = convertToCourseData(course);
            temp.CourseLectures = lectureService.getAllLectureByCourseId(course.id);
            result.add(temp);
        }
        return result;
    }


    @Override
    public CourseData createSimpleCourse(User user, Plan plan, long programId, String title) {
        EntityManager em = jpaApi.em();
        Course course = new Course();
        course.title = title;
        course.titleUrl = createCourseTitleUrl(title, 1);
        course.createdDate = new Timestamp(new Date().getTime());
        course.updatedDate = new Timestamp(new Date().getTime());
        course.status = TSConst.COURSE_CONFIG.STATUS.PRIVATE;
        course.Plan = plan;
        course.User = user;

        if (programId > 0) {
            Program program = programDao.findProgramById(programId, em);
            if (program != null) {
                course.Program = program;
            } else {
                return null;
            }
        }

        boolean isCreated = courseDao.createCourse(course, em);
        if (isCreated) {
            return convertToCourseData(course);
        } else {
            return null;
        }

    }

    @Override
    public boolean updateCourseIntro(Course course, String title, String description) {
        EntityManager em = jpaApi.em();
        course.title = title;
        course.description = description;
        return courseDao.updateCourse(course, em);
    }

    @Override
    public boolean uploadCourseImage(File file, Course course) {
        EntityManager em = jpaApi.em();
        byte[] picData = Utils.getBytesFromFile(file);
        try {
            courseDao.updateCourseImage(course, picData, em);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public void resetCourseSecLecOrders(CourseOrder courseOrder) {
        EntityManager em = jpaApi.em();

        for (SectionOrder orderSection : courseOrder.sections) {
            CourseSection section = courseSectionDao.findSection(orderSection.secId, em);
            if (section.order != orderSection.order) {
                section.order = orderSection.order;
                em.merge(section);
            }

            for (LectureOrder orderLecture : orderSection.lectures) {
                CourseLecture lecture = courseLectureDao.findLectureById(orderLecture.lecId, em);
                if (lecture.CourseSection.id == orderSection.secId) {
                    if (lecture.order != orderLecture.order) {
                        lecture.order = orderLecture.order;
                        em.merge(lecture);
                    }
                } else {
                    lecture.CourseSection = section;
                    em.merge(lecture);
                }
            }
        }
    }

    @Override
    public boolean updateCourseStatus(Course course, int status) {
        if (course == null) {
            return false;
        }
        course.status = status;
        return courseDao.updateCourse(course, jpaApi.em());
    }

    /* Upload course intro */
    @Override
    public Course uploadIntroVideo(long courseId, Http.MultipartFormData.FilePart videoFile) {
        EntityManager em = jpaApi.em();
        Course course = courseDao.findCourseById(courseId, em);

        if (course == null) {
            return null;
        }

        Path result = uploadService.uploadIntroVideo(course, videoFile);
        if (result != null) {
            course.introVideo = result.toFile().getName();
            course.duration = 0;
            return em.merge(course);
        }

        return null;
    }

    @Override
    public double getCourseLearnerProcess(User user, Course course) {
        EntityManager em = jpaApi.em();
        int noOfPublicLectures = 0;
        for (CourseLecture lecture: course.CourseLectures) {
            if (lecture.status == TSConst.COURSE_CONFIG.STATUS.PUBLIC) {
                noOfPublicLectures++;
            }
        }
        if (noOfPublicLectures == 0) {
            return 0.0;
        }
        int noOfLectureCompleted = learnerProcessDao.getCompleteLearnerProcessOfUser(user.id, course.id, em).size();
        return noOfLectureCompleted * 100.0 / noOfPublicLectures;
    }

    private void createLearningLecturesData(Course course, LearningSectionData sectionData, List<CourseLecture> lectures, User user) {
        List<LearningLectureData> result = new ArrayList<>();
        int noOfCompletedLecture = 0;
        for (CourseLecture lecture: lectures) {
            if (lecture.status == TSConst.COURSE_CONFIG.STATUS.PUBLIC) {
                LearningLectureData lectureData = new LearningLectureData();
                lectureData.id = lecture.id;
                lectureData.title = lecture.title;
                lectureData.titleUrl = lecture.titleUrl;
                lectureData.type = lecture.type;
                LearnerProcess process = learnerProcessDao.getLearnerProcessInLecture(user.id, course.id, lecture.id, jpaApi.em());
                if (process != null && process.status == TSConst.LECTURE_CONFIG.LEARNING_STATUS.COMPLETED.value) {
                    lectureData.isCompleted = true;
                    noOfCompletedLecture++;
                }
                result.add(lectureData);
            }
        }
        sectionData.lectures = result;
        sectionData.noOfCompletedLectures = noOfCompletedLecture;
    }

    private List<LearningSectionData> createLearningSectionsData(Course course, User user) {
        List<LearningSectionData> result = new ArrayList<>();
        for (CourseSection section: course.CourseSections) {
            LearningSectionData sectionData = new LearningSectionData();
            sectionData.id = section.id;
            sectionData.title = section.title;
            sectionData.order = section.order;
            createLearningLecturesData(course, sectionData, section.CourseLectures, user);
            result.add(sectionData);
        }
        return result;

    }

    @Override
    public LearningCourseData createLearningCourseData(Course course, User user) {
        LearningCourseData courseData = new LearningCourseData();
        courseData.id = course.id;
        courseData.title = course.title;
        courseData.titleUrl = course.titleUrl;
        courseData.sections = createLearningSectionsData(course, user);
        int totalLectures = 0;
        int totalCompleted = 0;
        for (LearningSectionData sectionData: courseData.sections) {
            totalCompleted += sectionData.noOfCompletedLectures;
            totalLectures += sectionData.lectures.size();
        }
        courseData.learningProcess = totalCompleted * 100.0/totalLectures;

        return courseData;
    }

    private SimpleCourseData convertToSimpleCourseData(Course course) {
        SimpleCourseData temp = new SimpleCourseData();

        temp.id = course.id;
        temp.title = course.title;
        temp.titleUrl = course.titleUrl;
        temp.description = course.description;
        temp.status = course.status;
        temp.createdDate = course.createdDate;
        temp.updatedDate = course.updatedDate;
        temp.duration = course.duration;
        temp.author = course.User.fullname;

        return temp;
    }

    private List<SimplePlanData> convertToSimplePlanList(List<Course> courses) {
        List<SimplePlanData> result = new ArrayList<>();
        for (Course course: courses) {
            SimplePlanData tmp = new SimplePlanData();
            Plan plan = course.Plan;
            if (plan.status == TSConst.COMMON_STATUS.PUBLIC) {
                tmp.id = plan.id;

                SimpleCourseData courseData = convertToSimpleCourseData(course);

                int pos = result.indexOf(tmp);
                if (pos >= 0) {
                    result.get(pos).courses.add(courseData);
                } else {
                    tmp.title = plan.title;
                    tmp.titleUrl = plan.titleUrl;
                    tmp.courses = new ArrayList<>();
                    tmp.courses.add(courseData);
                    result.add(tmp);
                }
            }
        }

        return result;
    }


    @Override
    public int getNoOfReviewingCourses(int brandId) {
        EntityManager em = jpaApi.em();
        return courseDao.getNoOfReviewingCourses(brandId, em);
    }

    @Override
    public List<SimplePlanData> getReviewingCourses(int brandId) {
        EntityManager em = jpaApi.em();

        List<Course> courses = courseDao.getReviewingCourses(brandId, em);

        return convertToSimplePlanList(courses);
    }

    @Override
    public List<SimplePlanData> getTeachingCourses(long userId) {
        EntityManager em = jpaApi.em();
        List<Course> courses = courseDao.getAllCourseByUserId(userId, em);
        return convertToSimplePlanList(courses);
    }

}
