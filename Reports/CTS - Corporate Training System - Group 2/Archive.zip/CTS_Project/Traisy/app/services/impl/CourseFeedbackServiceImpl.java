package services.impl;

import commons.Utils;
import daos.*;
import fronts.CourseFeedbackData;
import models.*;
import play.db.jpa.JPAApi;
import services.CourseFeedbackService;
import services.DiscussionService;
import services.UserService;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class CourseFeedbackServiceImpl implements CourseFeedbackService {

    @Inject private CourseFeedbackDao courseFeedbackDao;
    @Inject private UserDao userDao;
    @Inject private UserService userService;
    @Inject private CourseDao courseDao;
    @Inject private JPAApi jpaApi;
    @Inject private CourseFeedbackReplyDao replyDao;


    @Override
    public List<CourseFeedback> getAllFeedbackByCourse(String courseTitle) {
        Course course = courseDao.findCourseByTitleUrl(courseTitle,jpaApi.em());
        return courseFeedbackDao.getAllFeedbackByCourse(course.id, jpaApi.em());
    }

    @Override
    public CourseFeedbackData addFeedback(String title, String content, Timestamp createDate, long parentId, int status, long userId, long courseId) {
        CourseFeedback newFeedback = new CourseFeedback();
        if (title == null ){
            title = "";
        }
        if (content == null){
            content = "";
        }
        newFeedback.title = title;
        newFeedback.content = content;
        newFeedback.createdDate = createDate;
        status = 0; // feedback not yet approve
        newFeedback.status = status;
        newFeedback.User = userDao.findUserById(userId, jpaApi.em());
        newFeedback.parentId = courseFeedbackDao.findFeedbackById(parentId,jpaApi.em());
        newFeedback.Course = courseDao.findCourseById(courseId, jpaApi.em());
        try {
            CourseFeedback result= courseFeedbackDao.createFeedback(newFeedback,jpaApi.em());
            return convertToData(result);
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public boolean updateFeedback(long id, String title, String content, Timestamp createDate, int status) {
        CourseFeedback feedback = courseFeedbackDao.findFeedbackById(id, jpaApi.em());
        if (title!= null && title.length() > 0){
            feedback.title = title;
        }
        if (content!= null && content.length() > 0){
            feedback.content = content;
        }
        if (createDate!=null){
            feedback.createdDate = createDate;
        }
        feedback.status = status;
        return courseFeedbackDao.updateFeedback(feedback, jpaApi.em());

    }

    @Override
    public boolean removeFeedback(long id) {
        CourseFeedback feedback = courseFeedbackDao.findFeedbackById(id, jpaApi.em());
        if (feedback.feedbackReplies != null){
            courseFeedbackDao.removeListFeedback(feedback.feedbackReplies, jpaApi.em());
        }
        courseFeedbackDao.removeFeedback(feedback.id,jpaApi.em());
        return true;
    }

    @Override
    public CourseFeedbackData convertToData(CourseFeedback courseFeedback){
        CourseFeedbackData result = new CourseFeedbackData();
        result.title = courseFeedback.title;
        result.content = courseFeedback.content;
        result.createdDate = courseFeedback.createdDate;
        result.User = userService.convertToUserData(courseFeedback.User);
        result.id = courseFeedback.id;
        return result;
    }
}
