package services.impl;

import commons.Utils;
import daos.CourseDao;
import daos.CourseDiscussionDao;
import daos.CourseLectureDao;
import daos.UserDao;
import fronts.CourseDiscussionData;
import models.Course;
import models.CourseDiscussion;
import models.CourseLecture;
import play.db.jpa.JPAApi;
import services.DiscussionService;
import services.UserService;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class DiscussionServiceImpl implements DiscussionService {

    @Inject private CourseDiscussionDao courseDiscussionDao;
    @Inject private CourseDao courseDao;
    @Inject private JPAApi jpaApi;
    @Inject private UserDao userDao;
    @Inject private UserService userService;
    @Inject private CourseLectureDao courseLectureDao;
    @Override
    public List<CourseDiscussionData> getAllDiscussion(long courseLectureId) {
        List<CourseDiscussionData> courseDiscussionDataList = new ArrayList<>();
        List<CourseDiscussion> courseDiscussionList = courseDiscussionDao.getAllDiscussion(courseLectureId, jpaApi.em());
        for (CourseDiscussion discussion : courseDiscussionList) {
            CourseDiscussionData data = new CourseDiscussionData();
            data.id = discussion.id;
            data.content = discussion.content;
            data.createdDate = discussion.createdDate;
            data.status = discussion.status;
            if (discussion.CourseLecture!=null){
                data.CourseLecture = discussion.CourseLecture;
            }
            if (discussion.User!= null){
                data.User = userService.convertToUserData(discussion.User);
            }
            courseDiscussionDataList.add(data);
        }
        return courseDiscussionDataList;
    }

    @Override
    public List<CourseDiscussionData> getAllDisscussionByCourse(String courseTitle) {
        EntityManager em = jpaApi.em();
        Course course = courseDao.findCourseByTitleUrl(courseTitle, em);
        List<CourseDiscussionData> result = new ArrayList<>();
        if (course.CourseLectures != null && !course.CourseLectures.isEmpty()){
            for(CourseLecture courseLecture : course.CourseLectures){
                List<CourseDiscussionData> courseDiscussions = getAllDiscussion(courseLecture.id);
                for (CourseDiscussionData temp :
                        courseDiscussions) {
                    result.add(temp);
                }
            }
        }
        return result;
    }

    @Override
    public List<CourseDiscussion> getAllDiscussionOfLectureId(long courseLectureId) {
        List<CourseDiscussion> courseDiscussionList = courseDiscussionDao.getAllDiscussion(courseLectureId, jpaApi.em());
        return  courseDiscussionList;
    }

    @Override
    public CourseDiscussionData addDiscussion(String content, Timestamp createDate, long parentId, long userId, int status, long courseLectureId) {
        CourseDiscussion courseDiscussion = new CourseDiscussion();
        if (content == null){
            content = "";
        }
        courseDiscussion.content = content;
        courseDiscussion.createdDate = createDate;
        status = 1;
        courseDiscussion.status = status;
        courseDiscussion.parentId = courseDiscussionDao.findDiscussionById(parentId, jpaApi.em());
        courseDiscussion.User = userDao.findUserById(userId, jpaApi.em());
        courseDiscussion.CourseLecture = courseLectureDao.findLectureById(courseLectureId, jpaApi.em());
        try {
            CourseDiscussion result= courseDiscussionDao.createDiscussion(courseDiscussion, jpaApi.em());
            return convertToData(result);
        }catch (Exception e){
            return null;
        }
    }


    public CourseDiscussionData convertToData(CourseDiscussion courseDiscussion){
        CourseDiscussionData data = new CourseDiscussionData();
        data.id = courseDiscussion.id;
        data.content = courseDiscussion.content;
        data.createdDate = courseDiscussion.createdDate;
        if (courseDiscussion.User!=null){
            data.User = userService.convertToUserData(courseDiscussion.User);
        }
        return data;
    }
    @Override
    public boolean updateDiscussion(long id, String content, Timestamp createDate) {
        CourseDiscussion discussion = courseDiscussionDao.findDiscussionById(id, jpaApi.em());
        discussion.content = content;
        discussion.createdDate = createDate;
        return courseDiscussionDao.updateDiscussion(discussion,jpaApi.em());
    }

    @Override
    public boolean removeDiscussion(long id) {
        CourseDiscussion discussion = courseDiscussionDao.findDiscussionById(id, jpaApi.em());
        try {
            if (discussion.courseDiscussionList != null){
                for (CourseDiscussion discussionTemp : discussion.courseDiscussionList){
                    courseDiscussionDao.removeDiscussion(discussionTemp.id, jpaApi.em());
                }
            }
            return courseDiscussionDao.removeDiscussion(discussion.id,jpaApi.em());
        } catch (Exception e){
            return false;
        }

    }
}
