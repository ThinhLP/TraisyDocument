package services.impl;

import commons.TSConst;
import commons.Utils;
import models.Course;
import models.CourseLecture;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import play.mvc.Http;
import services.LogService;
import services.UploadService;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class UploadServiceImpl implements UploadService {
    @Override
    public Path uploadIntroVideo(Course course, Http.MultipartFormData.FilePart videoFile) {
        String path = TSConst.UPLOAD_CONFIG.INTRO_VIDEO_ROOT_PATH + "/" + course.id;

        String fileName = "intro-" + course.id + ".mp4";

        return uploadFile(videoFile, path, fileName, TSConst.UPLOAD_CONFIG.VIDEO.MAX_INTRO_VIDEO_SIZE);
    }

    @Override
    public Path uploadLectureVideo(CourseLecture lecture, Http.MultipartFormData.FilePart videoFile) {
        String path = TSConst.UPLOAD_CONFIG.VIDEO_ROOT_PATH + "/" + lecture.Course.id + "/" + lecture.id;

        String fileName = Utils.normalizeFileName(videoFile.getFilename());

        return uploadFile(videoFile, path, fileName, TSConst.UPLOAD_CONFIG.VIDEO.MAX_VIDEO_LECTURE_SIZE);
    }

    @Override
    public Path uploadLectureText(CourseLecture lecture, Http.MultipartFormData.FilePart textFile) {
        String path = TSConst.UPLOAD_CONFIG.VIDEO_ROOT_PATH + "/" + lecture.Course.id + "/" + lecture.id;

        String fileName = textFile.getFilename();

        return uploadFile(textFile, path, fileName, TSConst.UPLOAD_CONFIG.TEXT.MAX_TEXT_SIZE);
    }

//    @Override
//    public Path uploadLectureSlideshow(CourseLecture lecture, Http.MultipartFormData.FilePart slideShowFile) {
//        String path = TSConst.UPLOAD_CONFIG.VIDEO_ROOT_PATH + "/" + lecture.Course.id + "/" + lecture.id;
//
//        String fileName = slideShowFile.getFilename();
//
//        return uploadFile(slideShowFile, path, fileName, TSConst.UPLOAD_CONFIG.TEXT.MAX_TEXT_SIZE);
//    }

    @Override
    public String uploadLectureSlideshow(CourseLecture lecture, Http.MultipartFormData.FilePart slideShowFile) {
        File file = (File) slideShowFile.getFile();

        if (file.length() > TSConst.UPLOAD_CONFIG.SLIDE_SHOW.MAX_SLIDE_SHOW_SIZE) {
            return null;
        }

        String path = TSConst.UPLOAD_CONFIG.VIDEO_ROOT_PATH + "/" + lecture.Course.id + "/" + lecture.id;
        File pathDirs = new File(path);
        pathDirs.mkdirs();

        removeOldFiles(path);

        boolean isUploaded = Utils.convertPPTtoImage(file, path, slideShowFile.getFilename());
        if (isUploaded) {
            return path;
        }
        return null;
    }

    public Path uploadFile(Http.MultipartFormData.FilePart inputFile, String directory, String fileName, long maxSize) {
        File file = (File) inputFile.getFile();
        if (file.length() > maxSize) {
            return null;
        }

        // Create folder
        File pathDirs = new File(directory);
        pathDirs.mkdirs();

        File targetFile = new File(directory + "/" + fileName);

        // Remove old files
        removeOldFiles(directory);

        try {
            return Files.move(file.toPath(), targetFile.toPath());
        } catch (IOException ex) {
            LogService.logger.error("Can not upload file: " + file.getName());
            return null;
        }
    }

    private void removeOldFiles(String directory) {
        File targetDir = new File(directory);

        if (targetDir.exists()) {
            File[] files = targetDir.listFiles();
            for (File file : files) {
                try {
                    Files.delete(file.toPath());
                    System.out.println("Delete the file: " + file.getName());
                } catch (Exception e) {
                    LogService.logger.error("Cannot delete file: " + file.getName());
                }
            }
        }
    }

}
