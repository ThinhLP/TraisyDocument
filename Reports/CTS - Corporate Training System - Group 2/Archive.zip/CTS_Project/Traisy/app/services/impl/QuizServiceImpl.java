package services.impl;

import javax.inject.Inject;
import commons.TSConst;
import commons.Utils;
import daos.*;
import fronts.quiz.LearnerQuizAnswerResult;
import fronts.quiz.LearnerQuizResult;
import fronts.quiz.QuestionSubmission;
import fronts.quiz.QuizSubmission;
import models.*;
import play.db.jpa.JPAApi;
import services.QuizService;

import javax.persistence.EntityManager;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class QuizServiceImpl implements QuizService {

    @Inject private JPAApi jpaApi;
    @Inject private QuizDao quizDao;
    @Inject private QuestionDao questionDao;
    @Inject private AnswerDao answerDao;
    @Inject private CourseLectureDao courseLectureDao;
    @Inject private LearnerProcessDao learnerProcessDao;
    @Inject private LearnerQuizDao learnerQuizDao;
    @Inject private LearnerQuizDetailDao learnerQuizDetailDao;


    @Override
    public Quiz findQuizById(long quizId) {
        return quizDao.findQuizById(quizId, jpaApi.em());
    }

    @Override
    public CourseLecture findLectureByQuizId(long quizId) {
        return courseLectureDao.findLectureByQuizId(quizId, jpaApi.em());
    }

    @Override
    public boolean updateQuiz(CourseLecture lecture, int duration, double minScore) {
        EntityManager em = jpaApi.em();

        if (lecture == null) {
            return false;
        }

        Quiz quiz = lecture.Quiz;

        if (quiz == null) {
            return false;
        }

        boolean hasChanged = false;

        if (quiz.duration != duration && duration != 0) {
            quiz.duration = duration;
            hasChanged = true;
        }
        if (quiz.minScore != minScore) {
            quiz.minScore = minScore;
            hasChanged = true;
        }
        if (hasChanged) {
            quizDao.updateQuiz(quiz, em);
        }
        return true;
    }

    @Override
    public void descreaseNoOfQuestion(Quiz quiz) {
        quiz.noOfQuestions--;
        quizDao.updateQuiz(quiz, jpaApi.em());
    }

    private boolean isCorrectEssayAnswer(String content, Question question) {
        if (question.Answers == null || question.Answers.isEmpty()) {
            return false;
        }
        return content.toLowerCase().equals(question.Answers.get(0).content.toLowerCase());
    }

    private boolean isCorrectAnswers(List<Long> userAnswers, Question question) {
        if (question.Answers == null || question.Answers.isEmpty() || userAnswers.isEmpty()) {
            return false;
        }
        int numOfUserCorrect = 0;
        int numOfAnsCorrect = 0;
        for (Answer answer: question.Answers) {
            if (answer.isCorrect == 1) {
                numOfAnsCorrect++;
                for (Long userAnswerId : userAnswers) {
                    if (answer.id == userAnswerId) {
                        numOfUserCorrect++;
                        break;
                    }
                }
            }
        }
        return (numOfAnsCorrect > 0) && (numOfAnsCorrect == numOfUserCorrect);
    }

//    public static int countNoOfValidQuestions(Quiz quiz) {
//        int result = 0;
//        for (Question question: quiz.Questions) {
//            if (question.Answers != null && !question.Answers.isEmpty()) {
//                result++;
//            }
//        }
//        return result;
//    }

    private void createLearnerQuizDetails(List<LearnerQuizDetail> quizDetails, Question question, QuestionSubmission submissionDetail, EntityManager em) {

        if (question == null || question.Answers == null) {
            return;
        }

        if (question.type == TSConst.QUIZ_CONFIG.QUESTION_TYPE.ESSAY.value) {
            LearnerQuizDetail detail = new LearnerQuizDetail();
            detail.Question = question;
            detail.answerContent = submissionDetail.answerContent;
            detail.Answer = question.Answers.get(0);
            quizDetails.add(detail);
            return;
        }

        for (Long answer: submissionDetail.answers) {
            LearnerQuizDetail detail = new LearnerQuizDetail();
            detail.Question = question;
            detail.Answer = answerDao.findAnswerById(answer, em);
            quizDetails.add(detail);
        }

    }

    @Override
    public boolean evaluateSubmission(CourseLecture lecture, User user, QuizSubmission submission) {
        if (lecture == null) {
            return false;
        }
        List<QuestionSubmission> questionSubmissions = submission.questionSubmissions;
        int noOfCorrects = 0;
        List<LearnerQuizDetail> learnerQuizDetails = new ArrayList<>();

        EntityManager em = jpaApi.em();

        for (QuestionSubmission detail: questionSubmissions) {
            Question question = questionDao.findQuestionById(detail.questionId, em);
            if (question.type == TSConst.QUIZ_CONFIG.QUESTION_TYPE.ESSAY.value) {
                detail.answerContent = detail.answerContent.trim();
                if (isCorrectEssayAnswer(detail.answerContent, question)) {
                    noOfCorrects++;
                }
            } else {
                if (isCorrectAnswers(detail.answers, question)) {
                    noOfCorrects++;
                }
            }
            createLearnerQuizDetails(learnerQuizDetails, question, detail, em);
        }

        // Record new learner test
        LearnerQuiz newRecord = new LearnerQuiz();
        newRecord.Quiz = lecture.Quiz;
        newRecord.User = user;
        newRecord.date = new Timestamp(new Date().getTime());

        int noOfQuestions = lecture.Quiz.noOfQuestions;
        double score = 0.0;
        if (noOfQuestions > 0) {
            score = Math.round(noOfCorrects * 1000.0 / noOfQuestions) /100.0;
        }
        newRecord.score = score;
        newRecord.result = score >= lecture.Quiz.minScore ? TSConst.QUIZ_CONFIG.QUIZ_RESULT.PASS.value : TSConst.QUIZ_CONFIG.QUIZ_RESULT.FAIL.value;

        learnerQuizDao.create(newRecord, em);

        for (LearnerQuizDetail learnerQuizDetail: learnerQuizDetails) {
            learnerQuizDetail.LearnerQuiz = newRecord;
            learnerQuizDetailDao.create(learnerQuizDetail, em);
        }

        if (newRecord.result == TSConst.QUIZ_CONFIG.QUIZ_RESULT.PASS.value) {
            learnerProcessDao.updateLearningProcess(lecture.Course.id, lecture.id, user.id, em);
        }

        return true;
    }

    @Override
    public LearnerQuiz getLastLearnerQuiz(long userId, long quizId) {
        return learnerQuizDao.getLastLearnerQuiz(userId, quizId, jpaApi.em());
    }

    @Override
    public LearnerQuiz getLastLearnerQuiz(long userId, long quizId, EntityManager em) {
        return learnerQuizDao.getLastLearnerQuiz(userId, quizId, em);
    }

    private  List<LearnerQuizAnswerResult> initQuizAnswerResultList(Question question) {
        List<LearnerQuizAnswerResult> answerResultList = new ArrayList<>();

        for (Answer answer: question.Answers) {
            LearnerQuizAnswerResult quizAnswerResult = new LearnerQuizAnswerResult();
            quizAnswerResult.answerId = answer.id;
            quizAnswerResult.isCorrect = answer.isCorrect == 1;
            quizAnswerResult.isSelected = false;
            quizAnswerResult.answerContent = answer.content;
            answerResultList.add(quizAnswerResult);
        }
        return answerResultList;
    }

    private void updateUserChoice(List<LearnerQuizAnswerResult> learnerQuizAnswerResults, LearnerQuizDetail detail) {
        for (LearnerQuizAnswerResult quizAnswerResult: learnerQuizAnswerResults) {
            if (quizAnswerResult.answerId == detail.Answer.id) {
                quizAnswerResult.userAnswerContent = detail.answerContent;
                quizAnswerResult.isSelected = true;
                return;
            }
        }
    }

    private LearnerQuizResult createLearnerQuizResult(Question question) {
        LearnerQuizResult quizResult = new LearnerQuizResult();
        quizResult.questionId = question.id;
        quizResult.questionContent = question.content;
        quizResult.explaination = question.explaination;
        quizResult.answerResults = initQuizAnswerResultList(question);
        quizResult.quesType = question.type;
        if (question.type == TSConst.QUIZ_CONFIG.QUESTION_TYPE.MULTIPLE_CHOICE.value) {
            if (Utils.getNumOfCorrectAnswers(question.Answers) == 1) {
                quizResult.quesType = TSConst.QUIZ_CONFIG.QUESTION_TYPE.SINGLE_CHOICE.value;
            }
        }
        quizResult.order = question.order;
        return quizResult;
    }

    @Override
    public List<LearnerQuizResult> convertToLearnerLearnerQuizResult(Quiz quiz, List<LearnerQuizDetail> learnerQuizDetails) {

        List<LearnerQuizResult> result = new ArrayList<>();

        for (LearnerQuizDetail detail: learnerQuizDetails) {
                LearnerQuizResult tmp = new LearnerQuizResult();
                Question question = detail.Question;
                tmp.questionId = question.id;
                int pos = result.indexOf(tmp);

                if (pos >= 0) {
                    updateUserChoice(result.get(pos).answerResults, detail);
                } else {
//                    tmp.questionContent = question.content;
//                    tmp.explaination = question.explaination;
//                    tmp.answerResults = initQuizAnswerResultList(question);
//                    tmp.quesType = question.type;
//                    if (question.type == TSConst.QUIZ_CONFIG.QUESTION_TYPE.MULTIPLE_CHOICE.value) {
//                        if (Utils.getNumOfCorrectAnswers(question.Answers) == 1) {
//                            tmp.quesType = TSConst.QUIZ_CONFIG.QUESTION_TYPE.SINGLE_CHOICE.value;
//                        }
//                    }
                    tmp = createLearnerQuizResult(question);
                    updateUserChoice(tmp.answerResults, detail);
                    result.add(tmp);
                }
        }

        for (Question question: quiz.Questions) {
            boolean isEmptyAnswerData = true;
            for (LearnerQuizResult questionResult: result) {
                if (questionResult.questionId == question.id) {
                    isEmptyAnswerData = false;
                    break;
                }
            }
            if (isEmptyAnswerData) {
                LearnerQuizResult tmp = createLearnerQuizResult(question);
                result.add(tmp);
            }
        }


        for (LearnerQuizResult quizResult: result) {
            List<LearnerQuizAnswerResult> answerResults = quizResult.answerResults;
            if (quizResult.quesType == TSConst.QUIZ_CONFIG.QUESTION_TYPE.ESSAY.value) {
                quizResult.isCorrect = answerResults.get(0).answerContent.equalsIgnoreCase(answerResults.get(0).userAnswerContent);
            } else {
                quizResult.isCorrect = true;
                for (LearnerQuizAnswerResult answerResult: quizResult.answerResults) {
                    if ((answerResult.isCorrect && !answerResult.isSelected)
                            || (answerResult.isSelected && !answerResult.isCorrect)){
                        quizResult.isCorrect = false;
                    }
                }
            }
        }

        Collections.sort(result);

        return result;
    }
}
