package services.impl;

import commons.TSConst;
import controllers.Application;
import daos.*;
import fronts.SkillData;
import models.*;
import org.apache.shiro.authc.*;
import org.apache.shiro.crypto.RandomNumberGenerator;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.apache.shiro.subject.Subject;
import play.db.jpa.JPAApi;
import play.mvc.Http;
import services.LogService;
import services.SkillService;
import services.UserService;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;


public class SkillServiceImpl implements SkillService {

    @Inject
    private UserDao userDao;
    @Inject
    private SkillDao skillDao;
    @Inject
    private CourseDao courseDao;
    @Inject
    private JPAApi jpaApi;


    @Override
    public Skill findSkillById(int id) {
        return skillDao.findSkillById(id,jpaApi.em());
    }

    @Override
    public List<Skill> findAllSkill() {
        return skillDao.getAllSkill(jpaApi.em());
    }

    @Override
    public boolean removeSkill(int id) {
        Skill skill = findSkillById(id);
        if (skill.Courses.size() != 0){
//            for (Course course :
//                    skill.Courses) {
//                course.Skills
//            }
            return false;
        }
        return skillDao.removeSkill(id, jpaApi.em());
    }

    @Override
    public boolean updateSkill(int id, String title, String description) {
        Skill skill = findSkillById(id);
        skill.title = title;
        skill.description = description;
        return skillDao.updateSkill(skill, jpaApi.em());
    }

    @Override
    public Skill createSkill(String title, String description) {
        Skill skill = new Skill();
        skill.title = title;
        skill.description = description;
        return skillDao.createSkill(skill,jpaApi.em());
    }

    @Override
    public Skill addSkillToCourse(long courseId, int skillId) {
        EntityManager em = jpaApi.em();
        Course course = courseDao.findCourseById(courseId, em);
        Skill skill = skillDao.findSkillById(skillId, em);
        if (course != null && skill != null) {
            course.Skills.add(skill);
            skill.Courses.add(course);
//            jpaApi.em().merge(course);
            courseDao.updateCourse(course, em);
            jpaApi.em().merge(skill);
            return skill;
        }
        return null;
    }

    @Override
    public Skill removeSkillFromCourse(long courseId, int skillId) {
        EntityManager em = jpaApi.em();

        Course course = courseDao.findCourseById(courseId, em);
        Skill skill = skillDao.findSkillById(skillId, em);
        if (course != null && skill != null) {
            course.Skills.remove(skill);
            skill.Courses.remove(course);
            courseDao.updateCourse(course, em);
            jpaApi.em().merge(skill);
            return skill;
        }
        return null;
    }

    @Override
    public boolean addSkillsToCourse(long courseId, List<Skill> skillList) {
        Course course = courseDao.findCourseById(courseId, jpaApi.em());
        for (Skill skill :
                skillList) {
            Skill temp = skillDao.findSkillById(skill.id, jpaApi.em());
            course.Skills.add(temp);
            temp.Courses.add((course));
            jpaApi.em().merge(course);
            jpaApi.em().merge(temp);
        }
        return true;
    }

    @Override
    public SkillData convertToSkillData(Skill skill) {
        SkillData skillData = new SkillData();
        skillData.id = skill.id;
        skillData.title = skill.title;
        return skillData;
    }

    @Override
    public List<SkillData> convertToListSkillData(List<Skill> skills) {
        List<SkillData> result = new ArrayList<>();
        for (Skill skill : skills){
            result.add(convertToSkillData(skill));
        }
        return result;
    }
}
