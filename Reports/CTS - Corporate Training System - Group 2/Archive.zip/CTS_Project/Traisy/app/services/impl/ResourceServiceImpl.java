package services.impl;

import services.ResourceService;

import java.io.File;

public class ResourceServiceImpl implements ResourceService {
    @Override
    public File findResourceFile(String fileName) {
        // Sample
        File file = new File("C:/resources/" + fileName);
        return file;
    }
}
