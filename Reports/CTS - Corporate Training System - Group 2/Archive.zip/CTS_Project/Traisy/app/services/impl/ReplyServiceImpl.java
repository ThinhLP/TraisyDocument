package services.impl;

import daos.CourseFeedbackDao;
import daos.CourseFeedbackReplyDao;
import daos.UserDao;
import fronts.CourseFeedbackReplyData;
import models.CourseFeedbackReply;
import play.db.jpa.JPAApi;
import services.CourseFeedbackService;
import services.ReplyService;
import services.UserService;

import javax.inject.Inject;
import java.sql.Timestamp;
import java.util.List;

public class ReplyServiceImpl implements ReplyService {

    @Inject private CourseFeedbackDao courseFeedbackDao;
    @Inject private UserDao userDao;
    @Inject private UserService userService;
    @Inject private CourseFeedbackService courseFeedbackService;
    @Inject private JPAApi jpaApi;
    @Inject private CourseFeedbackReplyDao replyDao;


    public CourseFeedbackReplyData convertToData(CourseFeedbackReply reply){
        CourseFeedbackReplyData result = new CourseFeedbackReplyData();
        result.id = reply.id;
        result.content = reply.content;
        result.created_date = reply.created_date;
        result.status = reply.status;
        result.User = userService.convertToUserData(reply.User);
        if (reply.CourseFeedback!=null){
            result.CourseFeedback = courseFeedbackService.convertToData(reply.CourseFeedback);
        }
        return result;
    }
    @Override
    public CourseFeedbackReplyData addReply(String content, Timestamp createDate, int status, long userId, long feedbackId) {
        CourseFeedbackReply newReply = new CourseFeedbackReply();
        if (content == null){
            content = "";
        }
        newReply.content = content;
        newReply.created_date = createDate;
        status = 1;
        newReply.status = status;
        newReply.User = userDao.findUserById(userId, jpaApi.em());
        newReply.CourseFeedback = courseFeedbackDao.findFeedbackById(feedbackId,jpaApi.em());

        try {
            CourseFeedbackReply result= replyDao.createReply(newReply,jpaApi.em());
            return convertToData(result);
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public boolean removeReply(long id) {
        return replyDao.removeReply(id, jpaApi.em());
    }

    @Override
    public boolean updateReply(long id, String content, Timestamp createDate) {
        CourseFeedbackReply reply = replyDao.findFeedbackReplyById(id, jpaApi.em());
        if (content!=null && content.length()>0){
            reply.content = content;
        }
        reply.created_date = createDate;
        return replyDao.updateReply(reply,jpaApi.em());
    }
}
