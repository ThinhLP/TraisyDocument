package services.impl;

import commons.Utils;
import daos.AnswerDao;
import daos.BrandDao;
import daos.QuestionDao;
import daos.UserDao;
import models.Answer;
import models.Brand;
import models.Question;
import play.db.jpa.JPAApi;
import services.AnswerService;
import services.BrandService;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.io.File;
import java.util.List;


public class AnswerServiceImpl implements AnswerService {

    @Inject
    private JPAApi jpaApi;
    @Inject
    private BrandDao brandDao;
    @Inject
    QuestionDao questionDao;
    @Inject
    AnswerDao answerDao;

    @Override
    public boolean removeAnswer(Question question, long id) {
        EntityManager em = jpaApi.em();

        Answer answer = answerDao.findAnswerById(id, em);
        if (answer == null) {
            return false;
        }

        question.Answers.remove(answer);
        if (questionDao.updateQuestion(question, em)) {
            return answerDao.removeAnswer(id, em);
        }
        return false;
    }

    @Override
    public Answer createAnswer(String content, int correct, long questionId) {
        Answer answer = new Answer();
        answer.content = content;
        answer.isCorrect = correct;
        answer.Question = new Question();
        answer.Question = questionDao.findQuestionById(questionId, jpaApi.em());
        return answerDao.createAnswer(answer, jpaApi.em());
    }

    @Override
    public boolean updateAnswer(long answerId,int correct, String content) {
        Answer updateAnswer = answerDao.findAnswerById(answerId, jpaApi.em());
        updateAnswer.isCorrect = correct;
        updateAnswer.content = content;
        return answerDao.updateAnswer(updateAnswer, jpaApi.em());
    }

    @Override
    public List<Answer> getAllAnswerByQuestionId(long questionId) {
        return answerDao.getAllAnswerByQuestionId(questionId, jpaApi.em());
    }
}
