package services.impl;

import commons.TSConst;
import commons.Utils;
import daos.*;
import fronts.AnswerData;
import fronts.QuestionData;
import models.*;
import play.db.jpa.JPAApi;
import services.QuestionService;
import services.SkillService;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class QuestionServiceImpl implements QuestionService {

    @Inject
    private AnswerDao answerDao;
    @Inject
    private QuestionDao questionDao;
    @Inject
    private QuizDao quizDao;
    @Inject
    private CourseDao courseDao;
    @Inject
    private JPAApi jpaApi;

//    @Override
//    public Question createQuestion(String content, int type, String explaination, long quizId) {
//
//        //get the maximum order of question
//        int orderId = 0;
//        List<Question> questions = questionDao.getAllQuestionsByQuizId(quizId, jpaApi.em());
//        for (Question questionTemp : questions) {
//            if (questionTemp.order > orderId){
//                orderId = questionTemp.order;
//            }
//        }
////        List<CourseLecture> lecturesOfQuestion = lectureDao.getLectureById(lectureId);
//        Question questionCreate = new Question();
//        questionCreate.content = content;
//        questionCreate.type = type;
//        questionCreate.explaination = explaination;
//        //reference lecture must be implemented when lecture dao available
//        //lecture dao not available now
////        questionCreate.referenceLecture = lecturesOfQuestion;
//        questionCreate.order = orderId;
//        questionCreate.Quiz.id = quizId;
//        return questionDao.createQuestion(questionCreate, jpaApi.em());
//    }

    @Override
    public List<Question> getAllQuestionByQuizId(long quizId) {
        List<Question> result = questionDao.getAllQuestionsByQuizId(quizId, jpaApi.em());
        return result;
    }

    @Override
    public List<Question> getAllQuestion() {
        return questionDao.getAllQuestions(jpaApi.em());
    }

    @Override
    public Question findQuestion(long id) {
        return questionDao.findQuestionById(id,jpaApi.em());
    }

//    @Override
//    public boolean updateQuestion(long id, String content, int type, String explanation) {
//        Question questionUpdate = new Question();
//        questionUpdate.id  = id;
//        questionUpdate.content = content;
//        questionUpdate.type = type;
//        questionUpdate.explaination = explanation;
//        return questionDao.updateQuestion(questionUpdate, jpaApi.em());
//    }
//
//    @Override
//    public boolean removeQuestion(long id) {
//        Question questionRemove = questionDao.findQuestionById(id,jpaApi.em());
//
//        //delete every answer related to question
//        if (questionRemove.Answers != null){
//            for (Answer answer :
//                    questionRemove.Answers) {
//                answerDao.removeAnswer(answer.id,jpaApi.em());
//            }
//            questionDao.removeQuestion(id,jpaApi.em());
//            return true;
//        } else{
//            return false;
//        }
//    }
//
//    @Override
//    public void reorderQuestion(List<Question> questions) {
//        for (Question question: questions) {
//            String sql = "UPDATE `question` SET `order`='"+ question.order +"' WHERE `id`='"+question.id+"'";
//            javax.persistence.Query query = jpaApi.em().createNativeQuery(sql);
//            query.executeUpdate();
//        }
//    }


    private boolean isValidQuestionData(QuestionData questionData) {
        if (questionData.content == null || questionData.content.length() < TSConst.FIELD_VALIDATION.MIN_QUESTION_LENGTH || questionData.content.length() > TSConst.FIELD_VALIDATION.MAX_QUESTION_LENGTH) {
            return false;
        }
        if (!TSConst.QUIZ_CONFIG.QUESTION_TYPE.isValidType(questionData.type)) {
            return false;
        }
        // TODO: valid more info

        return true;
    }

    private List<Answer> convertAnswerDataToAnswer(Question question, List<AnswerData> answerDataList, EntityManager em) {
        List<Answer> answers = new ArrayList<>();

        for (AnswerData answerData: answerDataList) {
            Answer answer = new Answer();
            answer.content = answerData.content;
            answer.isCorrect = answerData.isCorrect;
            answer.Question = question;
            answerDao.createAnswer(answer, em);

            if (answer != null) {
                answers.add(answer);
            }
        }
        return answers;
    }

    public AnswerData convertAnswerData(Answer answer) {
        AnswerData data = new AnswerData();
        data.id = answer.id;
        data.content = answer.content;
        data.isCorrect = answer.isCorrect;
        return data;
    }

    public QuestionData convertQuestionData(Question question) {
        QuestionData data = new QuestionData();
        data.id = question.id;
        data.content = question.content;
        data.explaination = question.explaination;
        data.order = question.order;
        data.type = question.type;
        if (question.Answers != null) {
            for (Answer answer: question.Answers) {
                data.Answers.add(convertAnswerData(answer));
            }
        }
        return data;
    }

    @Override
    public QuestionData createQuestion(Quiz quiz, QuestionData questionData) {
        if (!isValidQuestionData(questionData)) {
            return null;
        }
        EntityManager em = jpaApi.em();
        Question question = new Question();
        question.content = questionData.content;
        question.explaination = questionData.explaination;
        question.type = questionData.type;
        question.order = quizDao.getNewQuestionOrder(quiz.id, em);
        question.Quiz = quiz;

        if (questionDao.createQuestion(question, em) != null) {
            question.Answers = convertAnswerDataToAnswer(question, questionData.Answers, em);
            quiz.noOfQuestions = (quiz.noOfQuestions == null) ? 1 : quiz.noOfQuestions + 1;
            quizDao.updateQuiz(quiz, em);
            return convertQuestionData(question);
        }

        return null;
    }

    @Override
    public boolean updateQuestion(Question question, String content, String explaination) {
        if (question == null) {
            return false;
        }

        boolean hasChanged = false;

        if (content != null && !content.isEmpty()) {
            question.content = content;
            hasChanged = true;
        }

        if (explaination != null) {
            question.explaination = explaination;
            hasChanged = true;
        }
        if (hasChanged) {
            questionDao.updateQuestion(question, jpaApi.em());
        }
        return true;
    }

    @Override
    public boolean removeQuestion(Question question) {
        if (question == null) {
            return false;
        }
        EntityManager em = jpaApi.em();
        // Remove all learner detail that have question
        Utils.removeAllElements(question.LearnerQuizDetails, em);
        // Remove all answers of question
        Utils.removeAllElements(question.Answers, em);
        // Remove question
        em.remove(question);
        return true;
    }
//
//    @Override
//    public void updateQuestionOrder(Map<Long, Integer> orders) {
//        EntityManager em = jpaApi.em();
//        for (Long id: orders.keySet()) {
//            Question question = questionDao.findQuestionById(id, em);
//            int newOrder = orders.get(id);
//            if (question.order != newOrder) {
//                question.order = newOrder;
//                questionDao.updateQuestion(question, em);
//            }
//        }
//    }
}
