package services.impl;

import com.google.inject.Inject;
import commons.TSConst;
import commons.Utils;
import daos.*;
import fronts.CourseLectureData;
import models.*;
import org.jcodec.containers.mp4.MP4Util;
import org.jcodec.containers.mp4.boxes.MovieBox;
import play.db.jpa.JPAApi;
import play.mvc.Http;
import services.*;

import javax.persistence.EntityManager;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.util.*;

public class LectureServiceImpl implements LectureService {

    @Inject private CourseSectionDao courseSectionDao;
    @Inject private CourseLectureDao courseLectureDao;
    @Inject private CourseDao courseDao;
    @Inject private CourseService courseService;
    @Inject private SectionService sectionService;
    @Inject private LearnerProcessDao learnerProcessDao;
    @Inject private JPAApi jpaApi;
    @Inject private UploadService uploadService;
    @Inject private CourseDiscussionDao courseDiscussionDao;
    @Inject private AuthService authService;

    private String createLectureTitleUrl(String lectureTitle, int number) {
        String resultURL;

        resultURL = Utils.removeAccents(lectureTitle);
        if (number > 1) {
            resultURL += "-" + number;
        }

        // check if the url has exist
        CourseLecture lecture = courseLectureDao.findLectureByTitleUrl(resultURL, jpaApi.em());
        if (lecture != null) {
            return createLectureTitleUrl(resultURL, ++number);
        }

        return resultURL;
    }

    public CourseLectureData convertToLectureData(CourseLecture lecture) {
        CourseLectureData data = new CourseLectureData();
        data.id = lecture.id;
        data.title = lecture.title;
        data.order = lecture.order;
        data.titleUrl = lecture.titleUrl;
        data.duration = lecture.duration;
        data.status = lecture.status;
        data.type = lecture.type;
        data.note = lecture.note;
        data.Course = courseService.convertToCourseData(lecture.Course);
        data.CourseSection = sectionService.convertToSectionData(lecture.CourseSection);
        return data;
    }

    @Override
    public CourseLectureData createSimpleLecture(long sectionId, String lectureTitle) {
        EntityManager em = jpaApi.em();
        CourseSection section = courseSectionDao.findSection(sectionId, em);
        if (section == null) {
            return null;
        }
        CourseLecture lecture = new CourseLecture();
        lecture.title = lectureTitle;
        lecture.titleUrl = createLectureTitleUrl(lectureTitle, 0);

//        Course course = courseService.findCourseById(section.Course.id);
//
//        if (course == null) {
//            return null;
//        }

        lecture.CourseSection = section;
        lecture.Course = section.Course;

        courseDao.updateCourse(section.Course, em);

        lecture.status = TSConst.COURSE_CONFIG.STATUS.PRIVATE;
        lecture.type = TSConst.LECTURE_CONFIG.LECTURE_TYPE.VIDEO.value;
        lecture.order = courseLectureDao.getMaxLectureOrderInSection(section.id, em) + 1;

        CourseLecture newLec = courseLectureDao.createLecture(lecture, em);
        if (newLec != null) {
            return convertToLectureData(newLec);
        }
        return null;

    }

    @Override
    public CourseLecture findLectureById(long lectureId) {
        return courseLectureDao.findLectureById(lectureId, jpaApi.em());
    }

    @Override
    public CourseLecture findLectureByTitleUrl(String titleUrl) {
        return courseLectureDao.findLectureByTitleUrl(titleUrl, jpaApi.em());
    }

    @Override
    public CourseLecture findLectureByTitleUrl(String titleUrl, EntityManager em) {
        return courseLectureDao.findLectureByTitleUrl(titleUrl, jpaApi.em());
    }

    @Override
    public boolean updateLectureFile(long lectureId, String lectureFile) {
        CourseLecture updateLecture = courseLectureDao.findLectureById(lectureId, jpaApi.em());
        updateLecture.lectureFile = lectureFile;
        return courseLectureDao.updateLecture(updateLecture,jpaApi.em()) != null;
    }

    @Override
    public List<CourseLecture> getAllLectureByCourseId(long courseId) {
        return courseLectureDao.getAllPublishLectureInCourse(courseId,jpaApi.em());
    }
  
    @Override
    public CourseLectureData updateLecture(long lectureId, String lectureTitle, int status) {
        EntityManager em = jpaApi.em();
        CourseLecture lecture = courseLectureDao.findLectureById(lectureId, em);
        if (lecture == null) {
            return null;
        }
        boolean hasChanged = false;
        if (!lectureTitle.isEmpty()) {
            lecture.title = lectureTitle;
            hasChanged = true;
        }
        if (status != -1) {
            lecture.status = status;
            hasChanged = true;
        }
        if (hasChanged) {
            courseDao.updateCourse(lecture.Course, em);

            CourseLecture lec = em.merge(lecture);
            if (lec != null) {
                return convertToLectureData(lec);
            }
            return null;
        }
        return convertToLectureData(lecture);
    }

    @Override
    public boolean updateLectureType(long lectureId, int type) {
        EntityManager em = jpaApi.em();
        CourseLecture lecture = courseLectureDao.findLectureById(lectureId, em);
        if (lecture == null) {
            return false;
        }
        try {
            lecture.type = type;
            lecture.lectureFile = "";
            lecture.Course.duration = lecture.Course.duration == null ? 0 : lecture.Course.duration -  lecture.duration;
            lecture.duration = 0;

            if (type == TSConst.LECTURE_CONFIG.LECTURE_TYPE.QUIZ.value && lecture.Quiz == null) {
                lecture.Quiz = new Quiz();
                lecture.Quiz.duration = 0;
                lecture.Quiz.minScore = 0.0;
                lecture.Quiz.noOfQuestions = 0;
                em.persist(lecture.Quiz);
            }

            courseDao.updateCourse(lecture.Course, em);
            em.merge(lecture);
        } catch (Exception ex) {
            LogService.logger.error("Error: ", ex);
            return false;
        }

        return true;
    }

    @Override
    public boolean deleteAllLecturesOfSection(long sectionId) {
        EntityManager em = jpaApi.em();
        List<CourseLecture> listAllLectureOfSection = courseLectureDao.getAllLecturesInSection(sectionId, em);
        for (CourseLecture courseLecture :
                listAllLectureOfSection) {
            List<LearnerProcess> learnerProcesses = learnerProcessDao.getAllProcessOfOfLecture(courseLecture.id, em);
            List<CourseDiscussion> discussions = courseDiscussionDao.getAllDiscussion(courseLecture.id, em);
            if (discussions!= null && !discussions.isEmpty()){
                courseDiscussionDao.deleteListDiscussion(discussions, em);
            }
            if (learnerProcesses!= null && !learnerProcesses.isEmpty()){
                learnerProcessDao.deleteListProcess(learnerProcesses, em);
            }

            courseLectureDao.removeLecture(courseLecture,em);
        }
        return true;
    }

    @Override
    public boolean deleteLecture(long lectureId) {
        EntityManager em = jpaApi.em();
        CourseLecture lecture = courseLectureDao.findLectureById(lectureId, em);
        List<LearnerProcess> learnerProcesses = learnerProcessDao.getAllProcessOfOfLecture(lecture.id, em);
        List<CourseDiscussion> discussions = courseDiscussionDao.getAllDiscussion(lecture.id, em);
        if (discussions!= null && !discussions.isEmpty()){
            courseDiscussionDao.deleteListDiscussion(discussions, em);
        }
        if (learnerProcesses!= null && !learnerProcesses.isEmpty()){
            learnerProcessDao.deleteListProcess(learnerProcesses, em);
        }

        try {
            courseDao.updateCourse(lecture.Course, em);
            courseLectureDao.removeLecture(lecture, em);
            return true;
        } catch (Exception e){
            return false;
        }
    }

    @Override
    public boolean updateLectureStatus(long id, int status) {
        CourseLecture courseLecture = courseLectureDao.findLectureById(id,jpaApi.em());
        courseLecture.status = status;
        try {
            courseLectureDao.updateLecture(courseLecture, jpaApi.em());
            return true;
        } catch (Exception e){
            return false;
        }
    }
  
    public CourseLecture getLectureByTitleUrl(String titleUrl) {
        return courseLectureDao.findLectureByTitleUrl(titleUrl, jpaApi.em());
    }

    @Override
    public CourseLecture uploadLectureVideo(long lectureId, Http.MultipartFormData.FilePart filePart) {
        EntityManager em = jpaApi.em();
        CourseLecture lecture = courseLectureDao.findLectureById(lectureId, em);

        if (lecture == null || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.VIDEO.value) {
            return null;
        }

        Path result = uploadService.uploadLectureVideo(lecture, filePart);
        if (result != null) {
            lecture.lectureFile = result.toFile().getName();
            try {
                MovieBox movieBox = MP4Util.createRefMovieFromFile(result.toFile());
                lecture.duration = new Long(movieBox.getDuration() / movieBox.getTimescale()).intValue();
            } catch (IOException ex) {
                lecture.duration = 0;
            }
            lecture.Course.duration = lecture.Course.duration != null ? lecture.Course.duration + lecture.duration : lecture.duration;
            //em.merge(lecture.Course);
            courseDao.updateCourse(lecture.Course, em);
            return em.merge(lecture);
        }

        return null;
    }

    @Override
    public CourseLecture uploadLectureText(long lectureId, Http.MultipartFormData.FilePart filePart) {
        EntityManager em = jpaApi.em();
        CourseLecture lecture = courseLectureDao.findLectureById(lectureId, em);

        if (lecture == null || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.TEXT.value) {
            return null;
        }

        Path result = uploadService.uploadLectureText(lecture, filePart);
        if (result != null) {
            lecture.lectureFile = result.toFile().getName();
            lecture.duration = 0;
            courseDao.updateCourse(lecture.Course, em);

            return em.merge(lecture);
        }

        return null;
    }

//    @Override
//    public CourseLecture uploadLectureSlideshow(long lectureId, Http.MultipartFormData.FilePart filePart) {
//        EntityManager em = jpaApi.em();
//        CourseLecture lecture = courseLectureDao.findLectureById(lectureId, em);
//
//        if (lecture == null  || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.POWERPOINT.value) {
//            return null;
//        }
//        //TODO: check lecture type
//
//        Path result = uploadService.uploadLectureSlideshow(lecture, filePart);
//        if (result != null) {
//            lecture.lectureFile = result.toFile().getName();
//            lecture.duration = 0;
//            return em.merge(lecture);
//        }
//        return null;
//    }

    @Override
    public CourseLecture uploadLectureSlideshow(long lectureId, Http.MultipartFormData.FilePart filePart) {
        EntityManager em = jpaApi.em();
        CourseLecture lecture = courseLectureDao.findLectureById(lectureId, em);

        if (lecture == null  || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.POWERPOINT.value) {
            return null;
        }

        String result = uploadService.uploadLectureSlideshow(lecture, filePart);
        if (result != null) {
            lecture.lectureFile = "";
            lecture.duration = 0;
            courseDao.updateCourse(lecture.Course, em);

            return em.merge(lecture);
        }
        return null;
    }

    public static boolean isValidTextFile(File file) {
        if (!file.isFile())
            return false;
        String fileName = file.getName();
        int lastPos = fileName.lastIndexOf(".");
        if (lastPos < 0)
            return false;
        String extension = fileName.substring(lastPos + 1);
        if (!extension.equalsIgnoreCase("txt")) {
            return false;
        }
        return true;
    }

    public File getLectureTextFile(CourseLecture lecture) {
        String path = TSConst.UPLOAD_CONFIG.VIDEO_ROOT_PATH + "/" + lecture.Course.id + "/" + lecture.id + "/" + lecture.lectureFile;
        File file = new File(path);
        if (!isValidTextFile(file)) {
            return null;
        }
        return file;
    }

    @Override
    public byte[] getLectureTextContent(long lectureId) {
        EntityManager em = jpaApi.em();
        CourseLecture lecture = courseLectureDao.findLectureById(lectureId, em);

        if (lecture == null /*|| lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.TEXT.value */) {
            return null;
        }
        return getLectureTextContent(lecture);
    }

    @Override
    public byte[] getLectureTextContent(CourseLecture lecture) {
        if (lecture == null || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.TEXT.value) {
            return null;
        }
        File file = getLectureTextFile(lecture);
        if (file == null) {
            return null;
        }
        return Utils.getBytesFromFile(file);
    }


    public File getLectureFile(CourseLecture lecture) {
        String path = TSConst.UPLOAD_CONFIG.VIDEO_ROOT_PATH + "/" + lecture.Course.id + "/" + lecture.id + "/" + lecture.lectureFile;
       // path = path.replace("/", "\\");
        File file = new File(path);
        if (!file.isFile())
            return null;
        return file;
    }

    @Override
    public List<byte[]> getLectureSlideshow(long lectureId) {
        EntityManager em = jpaApi.em();
        CourseLecture lecture = courseLectureDao.findLectureById(lectureId, em);
        if (lecture == null || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.POWERPOINT.value) {
            return null;
        }
        return getLectureSlideshow(lecture);
    }

    @Override
    public List<byte[]> getLectureSlideshow(CourseLecture lecture) {

        if (lecture == null  || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.POWERPOINT.value) {
            return null;
        }
        String path = TSConst.UPLOAD_CONFIG.VIDEO_ROOT_PATH + "/" + lecture.Course.id + "/" + lecture.id;

        File directory = new File(path);
        if (!directory.isDirectory()) {
            return null;
        }
        List<File> files = Arrays.asList(directory.listFiles());
        Collections.sort(files, new Comparator<File>() {
            @Override
            public int compare(File f1, File f2) {
                return f1.getName().compareTo(f2.getName());
            }
        });

        List<byte[]> result = new ArrayList<>();
        for (File image: files) {
            result.add(Utils.getBytesFromFile(image));
        }

        return result;
    }

    @Override
    public boolean isCourseOwner(long lectureId, User user) {
        EntityManager em = jpaApi.em();
        if (authService.isAdminOrManager(user)) { // TODO: Admin or manager must be in brand
            return true;
        }
        return courseLectureDao.isCourseOwner(lectureId, user.id, em);
    }

    @Override
    public CourseLecture getFirstPublicLecture(long courseId) {
        return courseLectureDao.getFirstPublicLecture(courseId, jpaApi.em());
    }

    @Override
    public CourseLecture getLastLearningLecture(long userId, long courseId) {
        EntityManager em = jpaApi.em();
        CourseLecture courseLecture = learnerProcessDao.getLastLearningLecture(userId, courseId, em);
        if (courseLecture == null) {
            return getFirstPublicLecture(courseId);
        }
        return courseLecture;
    }

    @Override
    public CourseLecture getPreviousLecture(Course course, CourseLecture currentLecture) {
        return courseLectureDao.getPreviousLecture(course, currentLecture, jpaApi.em());
    }

    @Override
    public CourseLecture getNextLecture(Course course, CourseLecture currentLecture) {
        return courseLectureDao.getNextLecture(course, currentLecture, jpaApi.em());
    }

    @Override
    public List<CourseLectureData> convertToListLectureData(List<CourseLecture> courseLectures) {
        List<CourseLectureData> result = new ArrayList<>();
        CourseLectureData data = new CourseLectureData();
        for (CourseLecture lecture :
                courseLectures) {
            data = new CourseLectureData();
            data.id = lecture.id;
            data.title = lecture.title;
            data.order = lecture.order;
            data.titleUrl = lecture.titleUrl;
            data.duration = lecture.duration;
            data.status = lecture.status;
            data.type = lecture.type;
            data.note = lecture.note;
            result.add(data);
        }
        return result;
    }


}
