package services.impl;

import com.google.inject.Inject;
import daos.CourseDao;
import daos.CourseSectionDao;
import daos.LearnerProcessDao;
import models.Course;
import models.CourseSection;
import models.LearnerProcess;
import play.db.jpa.JPAApi;
import security.authorization.Authorization;
import services.CouseSectionService;
import services.LectureService;

import javax.management.Query;
import javax.persistence.EntityManager;
import java.util.List;

/**
 * Create by Hung
 */
public class CourseSectionServiceImpl implements CouseSectionService {

    @Inject
    private CourseSectionDao sectionDao;
    @Inject
    private JPAApi jpaApi;
    @Inject
    private CourseDao courseDao;
    @Inject private LearnerProcessDao learnerProcessDao;
    @Inject private LectureService lectureService;

    @Override
    public CourseSection findSectionById(long id) {
        return jpaApi.em().find(CourseSection.class, id);
    }

    @Override
    public CourseSection createCourseSection(String title, long courseId) {
        CourseSection section = new CourseSection();
        section.title = title;
        //get maximum order of section
        int maximumOrder = 0;
        List<CourseSection> listSectionByCourseId = getAllSectionByCourseId(courseId);
        for (CourseSection sectionTemp : listSectionByCourseId) {
            if (sectionTemp.order > maximumOrder) {
                maximumOrder = sectionTemp.order;
            }
        }
        maximumOrder += 1;
        section.order = maximumOrder;
        EntityManager em = jpaApi.em();
        Course course = courseDao.findCourseById(courseId, em);
        if (course == null) {
            return null;
        }
        section.Course = course;

        courseDao.updateCourse(section.Course, em);

        return sectionDao.createSection(section, em);
    }

    @Override
    public List<CourseSection> getAllSectionByCourseId(long courseId) {
        return sectionDao.getAllSectionByCourseId(courseId, jpaApi.em());
    }

    @Override
    public boolean updateCourseSection(long sectionId, int order) {
        CourseSection section = findSectionById(sectionId);
        if (section != null) {
            section.order = order;
            courseDao.updateCourse(section.Course, jpaApi.em());
            jpaApi.em().merge(section);
        }
        return false;
    }

    @Override
    public boolean removeCourseSection(long id) {
        CourseSection section = findSectionById(id);
        if (section.CourseLectures != null && !section.CourseLectures.isEmpty()){
            lectureService.deleteAllLecturesOfSection(id);
        }
        return sectionDao.removeSection(id, jpaApi.em());
    }

    /**
     * @param courseSections new order of course section
     * @return
     */
    @Override
    public void reorderCourseSection(List<CourseSection> courseSections) {
        for (CourseSection section : courseSections) {
            String sql = "UPDATE `course_section` SET `order`='"+ section.order +"' WHERE `id`='"+section.id+"'";
            javax.persistence.Query query = jpaApi.em().createNativeQuery(sql);
            query.executeUpdate();
        }
    }


}
