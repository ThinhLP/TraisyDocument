package services.impl;

import commons.Utils;
import daos.*;
import fronts.RoleData;
import fronts.UserData;
import models.*;
import org.apache.shiro.codec.Base64;
import play.db.jpa.JPAApi;
import commons.TSConst;
import controllers.Application;
import org.apache.shiro.authc.*;
import org.apache.shiro.crypto.RandomNumberGenerator;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.apache.shiro.subject.Subject;
import play.mvc.Http;
import services.LectureService;
import services.LogService;
import services.UserService;

import javax.inject.Inject;
import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class UserServiceImpl implements UserService {

    @Inject
    private UserDao userDao;
    @Inject
    private BrandDao brandDao;
    @Inject
    private RoleDao roleDao;
    @Inject
    private JPAApi jpaApi;
    @Inject private CourseEnrollDao courseEnrollDao;
    @Inject private LectureService lectureService;
    @Inject private LearnerProcessDao learnerProcessDao;

    @Override
    public User findUser(long id) {
        User user = userDao.findUserById(id, jpaApi.em());
        return user;
    }

    @Override
    public User findUser(String username) {
        User user = userDao.findUserByUsername(username, jpaApi.em());
        return user;
    }

    @Override
    public boolean updateAccount(User currentUser, String newPassword, String newFullname, String newTitle, int roleId, int status) {
        Role role = roleDao.findRoleById(roleId, jpaApi.em());
        if (newPassword.length() == 0){
            currentUser.fullname = newFullname;
            currentUser.title = newTitle;
            currentUser.status = status;
            currentUser.Role = role;
            try {
                jpaApi.em().merge(currentUser);
                return true;
            } catch (Exception e){
                return false;
            }
        }else {
            generatePassword(currentUser, newPassword);
            currentUser.fullname = newFullname;
            currentUser.status = status;
            currentUser.Role = role;
            currentUser.title = newTitle;
            try {
                jpaApi.em().merge(currentUser);
                return true;
            } catch (Exception e){
                return false;
            }
        }

    }

    /**
     * Check login
     */

    @Override
    public boolean login(String username, String password, Http.RequestHeader requestHeader) {
        Subject currentUser = new Subject.Builder().sessionId(Application.getSessionKey()).buildSubject();
        UsernamePasswordToken token = new UsernamePasswordToken(username, password);
        token.setRememberMe(false);

        try {
            currentUser.login(token);

            LogService.logger.info("User [" + currentUser.getPrincipal().toString()
                    + "] logged in successfully.");

            // Save the current session key
            Application.setSessionKey(currentUser.getSession().getId().toString());
            currentUser.getSession().setAttribute(TSConst.USER_SESSION.USERNAME, username);

            return true;
        } catch (UnknownAccountException uae) {
            String err = String.format("There is no user with username of %s: | client info: %s ",
                    token.getPrincipal(), LogService.getClientInfo(requestHeader));
            LogService.logger.error(err, uae);
        } catch (IncorrectCredentialsException ice) {
            String err = String.format("Password for account %s was incorrect: | client info: %s ",
                    token.getPrincipal(), LogService.getClientInfo(requestHeader));
            LogService.logger.error(err, ice);
        } catch (LockedAccountException lae) {
            String err = String.format("The account for username %s is locked: | client info: %s ",
                    token.getPrincipal(), LogService.getClientInfo(requestHeader));
            LogService.logger.error(err, lae);
        } catch (AuthenticationException e) {
            String err = String.format("Invalid username password");
            LogService.logger.error(err);
        }

        return false;
    }

    /**
     * Log out
     */
    public void logout() {
        Subject currentUser = new Subject.Builder().sessionId(Application.getSessionKey()).buildSubject();
        String sessKey = currentUser.getSession().getId().toString();
        Application.setSessionKey(sessKey);
        currentUser.logout();
        Application.removeSessionKey();
    }

    /**
     * Check user is locked or not
     */
    @Override
    public boolean isLockedUser(String username) {
        return userDao.getUserByUsernameAndStatus(username, TSConst.USER_CONFIG.STATUS.LOCKED, jpaApi.em()) != null;
    }

    /**
     * Get current user
     */
    public User getCurrentUser() {
        Subject currentUser = new Subject.Builder().sessionId(Application.getSessionKey()).buildSubject();
        if (currentUser.isAuthenticated()) {
            String username = (String) currentUser.getSession().getAttribute(TSConst.USER_SESSION.USERNAME);
            return userDao.findUserByUsername(username, jpaApi.em());
        }
        return null;
    }

    /**
     * Generate password
     */
    private void generatePassword(User user, String plainTextPassword) {
        RandomNumberGenerator rng = new SecureRandomNumberGenerator();
        Object salt = rng.nextBytes();
        String hashedPasswordBase64 = new Sha256Hash(plainTextPassword, salt, 1024).toBase64();
        user.password = hashedPasswordBase64;
        user.salt = salt.toString();
    }

    /**
     * Update user's account
     */
    @Override
    public boolean updateAccountForLearner(long id,String currentPassword, String newPassword, String newFullname, String newTitle) {
        User currentUser = userDao.findUserById(id, jpaApi.em());
        if (currentUser == null){
            return false;
        }

        String oldPassword = new Sha256Hash(currentPassword,Base64.decode(currentUser.salt), 1024).toBase64();
        boolean check = currentUser.password.equals(oldPassword);

        if (currentPassword.length()== 0){
            currentUser.fullname = newFullname;
            currentUser.title = newTitle;
            try {
                jpaApi.em().merge(currentUser);
                return true;
            } catch (Exception e){
                return false;
            }
        } else if(check){
            generatePassword(currentUser, newPassword);
            currentUser.fullname = newFullname;
            currentUser.title = newTitle;
            try {
                jpaApi.em().merge(currentUser);
                return true;
            } catch (Exception e){
                return false;
            }
        }
        return false;
    }

    @Override
    public boolean createAccount(String username, String password, String fullname, String title, int brandId, int roleId, int status) {
        Brand brand = brandDao.findBrandById(brandId, jpaApi.em());
        Role role = roleDao.findRoleById(roleId, jpaApi.em());
        if (brand != null) {
            User user = new User();
            user.username = username;
            user.password = password;
            user.fullname = fullname;
            user.status = status;
            user.title = title;
            generatePassword(user, password);
            user.Brand = brand;
            user.Role = role;
            userDao.createUser(user, jpaApi.em());
            return true;
        }

        return false;
    }

    @Override
    public List<User> listAllUserByBrandId(int brandId) {

        List<User> users = userDao.getAllUserByBrandId(brandId, jpaApi.em());
        return users;
    }

    @Override
    public boolean removeAllUserOfBrand(int brandId) {
        return userDao.removeAllUserByBrandId(brandId, jpaApi.em());
    }

    @Override
    public UserData convertToUserData(User user) {
        UserData userData = new UserData();
        userData.id = user.id;
        userData.username = user.username;
        userData.fullname = user.fullname;
        userData.title = user.title;
        userData.brandName = user.Brand.name;
        userData.roleId = user.Role.id;
        return userData;
    }

    @Override
    public List<UserData> findUsersEnrollInCourse(long courseId) {
        List<User> listUserEnroll = courseEnrollDao.findUsersEnrollInCourse(courseId,jpaApi.em());
        List<UserData> result = new ArrayList<>();

        for (User user: listUserEnroll) {
            UserData dataUser = convertToUserData(user);
            List<CourseLecture> courseLectures = lectureService.getAllLectureByCourseId(courseId);
            List<LearnerProcess> finishLecture = learnerProcessDao.getFinishProcessOfUserAndCourse(user.id, courseId, 1, jpaApi.em());
            if (!courseLectures.isEmpty() && !finishLecture.isEmpty()) {
                double process = ((double) finishLecture.size() / (double) courseLectures.size()) * 100;
                dataUser.process = process;
            } else {
                dataUser.process = 0;
            }
            result.add(dataUser);
        }
        return result;
    }

    @Override
    public void updateUserImage(long id, File file) {
        byte[] picData = Utils.getBytesFromFile(file);
        User user = userDao.findUserById(id, jpaApi.em());
        user.avatar = picData;
        jpaApi.em().merge(user);
    }
}
