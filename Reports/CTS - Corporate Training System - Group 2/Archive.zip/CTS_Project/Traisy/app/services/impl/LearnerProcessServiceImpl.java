package services.impl;

import daos.LearnerProcessDao;
import models.LearnerProcess;
import play.db.jpa.JPAApi;
import services.LearnerProcessService;

import javax.inject.Inject;
import java.util.List;

public class LearnerProcessServiceImpl implements LearnerProcessService {
    @Inject
    private JPAApi jpaApi;
    @Inject
    LearnerProcessDao learnerProcessDao;

    @Override
    public List<LearnerProcess> getFinishProcessOfUserAndCourse(long userId, long courseId, int status) {
        List<LearnerProcess> result = learnerProcessDao.getFinishProcessOfUserAndCourse(userId,courseId,status,jpaApi.em());
        return result;
    }

    @Override
    public boolean updateLearnerProcess(long userId, long courseId, long lectureId) {
        return learnerProcessDao.updateLearningProcess(courseId, lectureId, userId, jpaApi.em());
    }
}
