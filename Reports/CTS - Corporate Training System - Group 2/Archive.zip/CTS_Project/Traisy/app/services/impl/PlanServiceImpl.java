package services.impl;

import commons.TSConst;
import commons.Utils;
import daos.*;
import fronts.CourseData;
import fronts.PlanData;
import fronts.UserData;
import fronts.UserPlanData;
import fronts.report.*;
import models.*;
import play.db.jpa.JPAApi;
import services.CourseService;
import services.LectureService;
import services.PlanService;
import services.ProgramService;

import javax.inject.Inject;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import java.io.File;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PlanServiceImpl implements PlanService {

    @Inject
    private PlanDao planDao;
    @Inject
    private UserDao userDao;
    @Inject
    private CourseDao courseDao;
    @Inject
    private CourseService courseService;
    @Inject
    private PlanParticipantDao planParticipantDao;
    @Inject
    private JPAApi jpaApi;
    @Inject
    private ProgramService programService;
    @Inject
    private LearnerProcessDao learnerProcessDao;

    @Override
    public Plan findPlanById(long id) {
        return planDao.findPlanById(id, jpaApi.em());
    }

    @Override
    public List<Plan> listAllPlansByBrandId(int brandId) {
        List<Plan> planList = planDao.getAllPlans(brandId, jpaApi.em());
        return planList;
    }

    @Override
    public List<PlanData> getPlansByBrandId(int brandId, int pageNo, int size) {
        List<Plan> planList = planDao.getPlans(brandId, pageNo, size, jpaApi.em());
        List<PlanData> result = new ArrayList<>();
        for (Plan plan : planList) {
            result.add(convertToPlanData(plan));
        }
        return result;
    }

    @Override
    public List<Plan> listAllPlanByUserId(long userId) {
        List<Plan> plans = planParticipantDao.getAllPlansOfUser(userId, jpaApi.em());
        return plans;
    }

    @Override
    public List<PlanData> listAllPlanByTitle(String title) {
        List<PlanData> planDataList = new ArrayList<>();

        List<Plan> plans = planDao.getAllPlanByTitle(title, jpaApi.em());
        for (Plan p : plans) {
            PlanData temp = new PlanData();
            temp.id = p.id;
            temp.title = p.title;
            temp.description = p.description;
            temp.startDate = p.startDate;
            temp.endDate = p.endDate;
            planDataList.add(temp);
        }
        return planDataList;
    }

    @Override
    public PlanData createPlan(String title, String startDate, String endDate, String description) {
        Plan plan = new Plan();
        PlanData result = new PlanData();
        if (title != null) {
            plan.title = title;
            plan.description = description;
            if (startDate != null) {
                Timestamp start = Utils.convertStringToTimestamp(startDate);
                result.startDate = start;
                plan.startDate = start;
            }
            if (endDate != null) {
                Timestamp end = Utils.convertStringToTimestamp(endDate);
                result.endDate = end;
                plan.endDate = end;
            }
            planDao.createPlan(plan, jpaApi.em());
        } else {
            System.out.println("Title must not be null");
        }
        return result;
    }

    @Override
    public PlanData convertToPlanData(Plan plan) {
        PlanData planData = new PlanData();
        planData.id = plan.id;
        planData.planImage = plan.planImage;
        planData.description = plan.description;
        planData.title = plan.title;
        planData.titleUrl = plan.titleUrl;
        planData.startDate = plan.startDate;
        planData.endDate = plan.endDate;
        planData.status = plan.status;
        planData.hasAnotherProgram = false;
        return planData;
    }

    @Override
    public boolean updatePlanBasicInfo(Plan plan, String title, String description, long startDate, long endDate) {
        EntityManager em = jpaApi.em();
        if (plan != null) {
            return planDao.updatePlanInfo(plan, title, description, new Timestamp(startDate), new Timestamp(endDate), em);
        }
        return false;
    }

    @Override
    public boolean removePlan(long id, User user) {
        EntityManager em = jpaApi.em();
        Plan plan = planDao.findPlanById(id, em);
        if (plan == null) {
            return false;
        }

        if (user.Role.id != TSConst.USER_ROLE.SYSTEM_ADMIN.value && plan.User.Brand.id != user.Brand.id) {
            return false;
        }

        plan.status = TSConst.COMMON_STATUS.DELETED;

        return planDao.updatePlan(plan, em);
    }

    @Override
    public Plan findPlanByTitleUrl(String titleUrl) {
        return planDao.findPlanByTitleUrl(titleUrl, jpaApi.em());
    }


    private String createPlanTitleUrl(String planTitle, int number) {
        String resultURL;

        resultURL = Utils.removeAccents(planTitle);
        if (number > 1) {
            resultURL += "-" + number;
        }

        // check if the url has exist
        Plan plan = planDao.findPlanByTitleUrl(resultURL, jpaApi.em());
        if (plan != null) {
            return createPlanTitleUrl(planTitle, ++number);
        }

        return resultURL;
    }

    @Override
    public Plan createSimplePlan(String title, User user) {
        EntityManager em = jpaApi.em();
        Plan plan = new Plan();
        plan.title = title;
        plan.titleUrl = createPlanTitleUrl(title, 1);
        plan.status = TSConst.COMMON_STATUS.PUBLIC;
        plan.User = user;
        try {
            em.persist(plan);
            return plan;
        } catch (Exception ex) {
            return null;
        }
    }

    @Override
    public void updatePlanImage(File file, String planTitle) {
        EntityManager em = jpaApi.em();
        byte[] picData = Utils.getBytesFromFile(file);
        Plan plan = planDao.findPlanByTitleUrl(planTitle, em);
        plan.planImage = picData;
        em.merge(plan);
    }

    @Override
    public void addUserToPlan(Plan plan, long userId) {
        EntityManager em = jpaApi.em();
        User user = userDao.findUserById(userId, em);
        if (user == null || planParticipantDao.isParticipated(plan.id, user.id, em)) {
            return;
        }

        planParticipantDao.addUserToPlan(plan, user, em);
    }

    @Override
    public List<UserData> getUsersOfPlan(Plan plan, int role, int pageNo, int size) {
        EntityManager em = jpaApi.em();
        List<User> userList = planParticipantDao.getUserParticipants(plan, role, pageNo, size, em);
        return userDao.convertToUserData(userList);
    }
    @Override
    public List<UserData> getAllUsersOfPlan(Plan plan, int role) {
        EntityManager em = jpaApi.em();
        List<User> userList = planParticipantDao.getAllUserParticipants(plan, role, em);
        return userDao.convertToUserData(userList);
    }

    @Override
    public double getUserPlanProcess(Plan plan, User user) {
        int noOfCompletedCourse = 0;
        int noOfPublicCourse = 0;
        for (Course course : plan.Courses) {
            if (course.status == TSConst.COURSE_CONFIG.STATUS.PUBLIC) {
                noOfPublicCourse++;
                double process = courseService.getCourseLearnerProcess(user, course);
                if (process == 100.0) {
                    noOfCompletedCourse++;
                }
            }
        }
        return (noOfPublicCourse == 0) ? 0 : noOfCompletedCourse * 100 / noOfPublicCourse;
    }

    private LearnerPlanReportDetail convertToLearnerPlanReportDetail(User user, Plan plan, Timestamp participateDate) {
        LearnerPlanReportDetail userData = new LearnerPlanReportDetail();
        userData.id = user.id;
        userData.username = user.username;
        userData.fullname = user.fullname;
        userData.title = user.title;
        userData.roleId = user.Role.id;
        userData.participatePlanDate = participateDate;
        userData.planProcess = getUserPlanProcess(plan, user);
        return userData;
    }


    private LearnerPlanReportDetail convertToLearnerPlanReportDetail(PlanParticipant planParticipant) {
        LearnerPlanReportDetail userData = new LearnerPlanReportDetail();
        userData.id = planParticipant.User.id;
        userData.username = planParticipant.User.username;
        userData.fullname = planParticipant.User.fullname;
        userData.title = planParticipant.User.title;
        userData.roleId = planParticipant.User.Role.id;
        userData.participatePlanDate = planParticipant.participateDate;

        return userData;
    }

    private List<LearnerPlanReportDetail> convertToLearnerPlanReportDetailList(List<Object[]> data) {
        List<LearnerPlanReportDetail> result = new ArrayList<>();
        for (Object[] obj : data) {
            User user = (User) obj[0];
            Timestamp participateDate = (Timestamp) obj[1];
            Plan plan = (Plan) obj[2];
            result.add(convertToLearnerPlanReportDetail(user, plan, participateDate));
        }

        return result;
    }


    @Override
    public List<LearnerPlanReportDetail> getLearnerPlanParticipants(Plan plan, int pageNo, int size) {
        EntityManager em = jpaApi.em();
        return convertToLearnerPlanReportDetailList(planParticipantDao.getUserParticipantsWithDate(plan, TSConst.USER_ROLE.LEARNER.value, pageNo, size, em));
    }

    @Override
    public List<LearnerPlanReportDetail> searchLearnerPlanParticipants(Plan plan, String name, int pageNo, int size) {
        EntityManager em = jpaApi.em();
        return convertToLearnerPlanReportDetailList(planParticipantDao.searchUserParticipants(plan, TSConst.USER_ROLE.LEARNER.value, name, pageNo, size, em));
    }

    @Override
    public List<LearnerPlanReportDetail> getAllLearnerPlanParticipants(Plan plan) {
        EntityManager em = jpaApi.em();
        return convertToLearnerPlanReportDetailList(planParticipantDao.getAllUserParticipantsWithDate(plan, TSConst.USER_ROLE.LEARNER.value, em));
    }
    @Override
    public List<UserData> getPlanAvailableUsers(Plan plan, Brand brand, int role, int pageNo, int size) {
        EntityManager em = jpaApi.em();
        List<User> userList = userDao.getPlanAvailableUsers(plan, brand, role, pageNo, size, em);
        return userDao.convertToUserData(userList);
    }

    @Override
    public List<PlanData> getAllPlanOfUserWithProcessOfCourse(long userId) {
        List<PlanData> result = new ArrayList<>();
        List<Plan> allPlanOfUser = listAllPlanByUserId(userId);
        for (Plan tempPlan :
                allPlanOfUser) {
            PlanData data = convertToPlanData(tempPlan);
            if (tempPlan.Programs != null && !tempPlan.Programs.isEmpty()) {
                data.Programs = programService.convertToListProgramData(tempPlan.Programs, userId);
            }
            List<CourseData> courseDataList = courseService.convertToCourseDataList(tempPlan.Courses, userId);
            if (tempPlan.User.id != 0) {
                data.User = tempPlan.User;
            }
            data.Courses = courseDataList;
            result.add(data);
        }
        return result;
    }

    @Override
    public PlanData convertToFullPlanData(Plan plan, long userId) {
        PlanData data = convertToPlanData(plan);
        if (plan.Programs != null && !plan.Programs.isEmpty()) {
            data.Programs = programService.convertToListProgramData(plan.Programs, userId);
        }
        List<CourseData> courseDataList = courseService.convertToCourseDataList(plan.Courses, userId);
        if (plan.User.id != 0) {
            data.User = plan.User;
        }
        data.Courses = courseDataList;
        for (CourseData tempData : data.Courses) {
            if (tempData.Program == null) {
                data.hasAnotherProgram = true;
                break;
            }
        }
        return data;
    }

    @Override
    public List<Plan> getAllParticipantPlan(long userId) {
        List<Plan> allPlanOfUser = listAllPlanByUserId(userId);
        return allPlanOfUser;
    }


    @Override
    public boolean removeUserFromPlan(Plan plan, User user) {
        EntityManager em = jpaApi.em();
        return planParticipantDao.removeUserFromPlan(plan.id, user.id, em);
    }

    @Override
    public boolean hasParticipated(Plan plan, User user) {
        return planParticipantDao.findPlanParticipant(plan.id, user.id, jpaApi.em()) != null;
    }

    public LearnerCourseReportDetail getLearnerCourseReportDetail(Course course, User user) {
        LearnerCourseReportDetail courseReportDetail = new LearnerCourseReportDetail();
        courseReportDetail.id = course.id;
        courseReportDetail.author = course.User.fullname;
        courseReportDetail.title = course.title;
        courseReportDetail.titleUrl = course.titleUrl;
        courseReportDetail.courseProcess = courseService.getCourseLearnerProcess(user, course);
        return courseReportDetail;
    }

    public LearnerProgramReportDetail getLearnerProgramReportDetail(Program program, User user) {
        LearnerProgramReportDetail programReportDetail = new LearnerProgramReportDetail();
        programReportDetail.id = program.id;
        programReportDetail.title = program.title;
        programReportDetail.startDate = program.startDate;
        programReportDetail.endDate = program.endDate;
        programReportDetail.courses = new ArrayList<>();

        int noOfCompletedCourses = 0;
        int totalCourses = 0;
        for (Course course : program.Courses) {
            if (course.status == TSConst.COURSE_CONFIG.STATUS.PUBLIC) {
                totalCourses++;
                LearnerCourseReportDetail learnerCourseReportDetail = getLearnerCourseReportDetail(course, user);
                if (learnerCourseReportDetail.courseProcess == 100.0) {
                    noOfCompletedCourses++;
                }
                programReportDetail.courses.add(learnerCourseReportDetail);
            }
        }

        programReportDetail.programProcess = totalCourses == 0 ? 0 : 100.0 * noOfCompletedCourses / totalCourses;

        return programReportDetail;
    }

    @Override
    public LearnerPlanReportDetail getLearnerReportDetail(Plan plan, User user) {
        EntityManager em = jpaApi.em();

        PlanParticipant planParticipant = planParticipantDao.findPlanParticipant(plan.id, user.id, em);
        LearnerPlanReportDetail planReportDetail = convertToLearnerPlanReportDetail(planParticipant);
        planReportDetail.programs = new ArrayList<>();


        for (Program program : plan.Programs) {
            LearnerProgramReportDetail programReportDetail = getLearnerProgramReportDetail(program, user);
            if (!programReportDetail.courses.isEmpty()) {
                planReportDetail.programs.add(programReportDetail);
            }
        }

        List<Course> otherCourses = new ArrayList<>();
        for (Course course : plan.Courses) {
            if (course.Program == null) {
                otherCourses.add(course);
            }
        }

        if (!otherCourses.isEmpty()) {
            Program otherProgram = new Program();
            otherProgram.id = 0;
            otherProgram.title = "Khóa học khác";
            otherProgram.Courses = otherCourses;
            LearnerProgramReportDetail programReportDetail = getLearnerProgramReportDetail(otherProgram, user);
            if (!programReportDetail.courses.isEmpty()) {
                planReportDetail.programs.add(programReportDetail);
            }
        }

        planReportDetail.planProcess = getUserPlanProcess(plan, user);
        planReportDetail.lastLearningDate = learnerProcessDao.getLastLearningDate(user.id, em);

        return planReportDetail;
    }

    private PlanReport convertToPlanReport(Plan plan, EntityManager em) {
        PlanReport report = new PlanReport();
        report.id = plan.id;
        report.title = plan.title;
        report.titleUrl = plan.titleUrl;
        report.totalCompleted = 0;
        if (plan.endDate == null) {
            report.isOutOfDated = false;
        } else {
            report.isOutOfDated = new Date().getTime() - plan.endDate.getTime() < 0;
        }
        List<User> learnerParticipants = planParticipantDao.getAllUserParticipants(plan, TSConst.USER_ROLE.LEARNER.value, em);
        for (User user: learnerParticipants) {
            double process = getUserPlanProcess(plan, user);
            if (process == 100.0) {
                report.totalCompleted++;
            }
        }
        List<User> authorParticipants = planParticipantDao.getAllUserParticipants(plan, TSConst.USER_ROLE.AUTHOR.value, em);

        report.totalLearners = learnerParticipants.size();
        report.totalAuthors = authorParticipants.size();

        return report;
    }

    @Override
    public List<PlanReport> getPlanReportList(int brandId) {
        List<PlanReport> result = new ArrayList<>();
        EntityManager em = jpaApi.em();
        List<Plan> plans = planDao.getAllPlans(brandId, em);
        for (Plan plan: plans) {
            result.add(convertToPlanReport(plan, em));
        }
        return result;
    }


    private AuthorPlanReportDetail convertToSimpleAuthorPlanReport(User user, Timestamp participateDate) {
        AuthorPlanReportDetail userData = new AuthorPlanReportDetail();

        userData.id = user.id;
        userData.username = user.username;
        userData.fullname = user.fullname;
        userData.title = user.title;
        userData.roleId = user.Role.id;
        userData.participatePlanDate = participateDate;

        return userData;
    }

    public AuthorCourseReportDetail getAuthorCourseReportDetail(Course course) {
        AuthorCourseReportDetail courseReportDetail = new AuthorCourseReportDetail();
        courseReportDetail.id = course.id;
        courseReportDetail.title = course.title;
        courseReportDetail.titleUrl = course.titleUrl;
        courseReportDetail.createdDate = course.createdDate;
        courseReportDetail.status = course.status;
        return courseReportDetail;
    }

    private AuthorProgramReportDetail getAuthorProgramReportDetail(Program program, User user, EntityManager em) {
        AuthorProgramReportDetail programReportDetail = new AuthorProgramReportDetail();
        programReportDetail.id = program.id;
        programReportDetail.title = program.title;
        programReportDetail.startDate = program.startDate;
        programReportDetail.endDate = program.endDate;

        programReportDetail.courses = new ArrayList<>();

        programReportDetail.noOfPublic = 0;
        programReportDetail.noOfPrivate = 0;
        programReportDetail.noOfReviewing = 0;

        List<Course> userCourses = courseDao.getAllCourseByUserIdAndProgramId(program.id, user.id, em);
        for (Course course: userCourses) {
            if (course.status == TSConst.COURSE_CONFIG.STATUS.PRIVATE) {
                programReportDetail.noOfPrivate++;
            } else if (course.status == TSConst.COURSE_CONFIG.STATUS.PUBLIC) {
                programReportDetail.noOfPublic++;
            } else {
                programReportDetail.noOfReviewing++;
            }
            programReportDetail.courses.add(getAuthorCourseReportDetail(course));
        }
        return programReportDetail;


    }

    private List<AuthorPlanReportDetail> convertToSimpleAuthorPlanReportlList(List<Object[]> data, EntityManager em) {
        List<AuthorPlanReportDetail> result = new ArrayList<>();
        for (Object[] obj : data) {
            User user = (User) obj[0];
            Timestamp participateDate = (Timestamp) obj[1];
            Plan plan = (Plan) obj[2];
            AuthorPlanReportDetail planReport = convertToSimpleAuthorPlanReport(user, participateDate);
            planReport.lastCourseUpdated = courseDao.getLastUpdateCourse(plan.id, user.id, em);
            planReport.totalCourses = courseDao.getAllCourseByUserIdAndPlanId(plan.id, user.id, em).size();
            result.add(planReport);
        }

        return result;
    }

    @Override
    public List<AuthorPlanReportDetail> getAuthorPlanParticipants(Plan plan, int pageNo, int size) {
        EntityManager em = jpaApi.em();
        return convertToSimpleAuthorPlanReportlList(planParticipantDao.getUserParticipantsWithDate(plan, TSConst.USER_ROLE.AUTHOR.value, pageNo, size, em), em);
    }

    @Override
    public List<AuthorPlanReportDetail> getAllAuthorPlanParticipants(Plan plan) {
        EntityManager em = jpaApi.em();
        return convertToSimpleAuthorPlanReportlList(planParticipantDao.getAllUserParticipantsWithDate(plan, TSConst.USER_ROLE.AUTHOR.value, em), em);
    }

    @Override
    public AuthorPlanReportDetail getAuthorReportDetail(Plan plan, User user) {
        EntityManager em = jpaApi.em();

        PlanParticipant planParticipant = planParticipantDao.findPlanParticipant(plan.id, user.id, em);

        AuthorPlanReportDetail planReport = convertToSimpleAuthorPlanReport(user, planParticipant.participateDate);

        planReport.programs = new ArrayList<>();

        for (Program program : plan.Programs) {
            AuthorProgramReportDetail programReportDetail = getAuthorProgramReportDetail(program, user, em);
//            if (!programReportDetail.courses.isEmpty()) {
                planReport.programs.add(programReportDetail);
//            }
        }

        List<Course> otherCourses = new ArrayList<>();
        for (Course course : plan.Courses) {
            if (course.Program == null) {
                otherCourses.add(course);
            }
        }

        if (!otherCourses.isEmpty()) {
            Program otherProgram = new Program();
            otherProgram.id = 0;
            otherProgram.title = "Khóa học khác";
            otherProgram.Courses = otherCourses;

            AuthorProgramReportDetail programReportDetail = getAuthorProgramReportDetail(otherProgram, user, em);
//            if (!programReportDetail.courses.isEmpty()) {
                planReport.programs.add(programReportDetail);
//            }
        }

        planReport.lastCourseUpdated = courseDao.getLastUpdateCourse(plan.id, user.id, em);
        planReport.totalCourses = courseDao.getAllCourseByUserIdAndPlanId(plan.id, user.id, em).size();

        return planReport;
    }
}
