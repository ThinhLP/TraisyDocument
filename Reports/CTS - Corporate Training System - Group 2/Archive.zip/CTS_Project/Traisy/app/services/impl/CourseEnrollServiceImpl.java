package services.impl;

import commons.TSConst;
import daos.CourseEnrollDao;
import daos.LearnerProcessDao;
import daos.RoleDao;
import daos.UserDao;
import models.*;
import play.db.jpa.JPAApi;
import services.CourseEnrollService;
import services.RoleService;
import services.UserService;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class CourseEnrollServiceImpl implements CourseEnrollService {

    @Inject private UserDao userDao;
    @Inject private CourseEnrollDao courseEnrollDao;
    @Inject private LearnerProcessDao learnerProcessDao;
    @Inject private JPAApi jpaApi;


    @Override
    public List<User> findUsersEnrollInCourse(long courseId) {
        List<User> result = courseEnrollDao.findUsersEnrollInCourse(courseId,jpaApi.em());
        return result;
    }

    @Override
    public CourseEnroll getUserEnroll(long courseId, long userId) {
        return courseEnrollDao.getUserCourseEnroll(courseId, userId, jpaApi.em());
    }

    @Override
    public void updateLearnerLearningProgress(User user, Course course, CourseLecture lecture) {
        EntityManager em = jpaApi.em();
        LearnerProcess process = learnerProcessDao.getLearnerProcessInLecture(user.id, course.id, lecture.id, em);
        if (process == null) {
            process = new LearnerProcess();
            process.Course = course;
            process.CourseLecture = lecture;
            process.User = user;
            process.status = TSConst.LECTURE_CONFIG.LEARNING_STATUS.NOT_COMPLETED.value;
            process.lastLearningDate = new Timestamp(new Date().getTime());
            learnerProcessDao.create(process, em);
        } else {
            process.lastLearningDate = new Timestamp(new Date().getTime());
            learnerProcessDao.update(process, em);
        }
    }

    @Override
    public void updateCourseEnroll(User user, Course course) {
        EntityManager em = jpaApi.em();
        boolean hasEnrolled = courseEnrollDao.getUserCourseEnroll(course.id, user.id, em) != null;
        if (!hasEnrolled) {
            CourseEnroll enroll = new CourseEnroll();
            enroll.Course = course;
            enroll.User = user;
            enroll.enrollDate = new Timestamp(new Date().getTime());
            courseEnrollDao.create(enroll,em);
        }
    }
}
