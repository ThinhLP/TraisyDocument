package services.impl;

import daos.RoleDao;
import daos.UserDao;
import models.Role;
import play.db.jpa.JPAApi;
import services.RoleService;

import javax.inject.Inject;

public class RoleServiceImpl implements RoleService {

    @Inject private UserDao userDao;
    @Inject private RoleDao roleDao;
    @Inject private JPAApi jpaApi;


    @Override
    public Role findRoleById(int id) {
        return roleDao.findRoleById(id, jpaApi.em());
    }
}
