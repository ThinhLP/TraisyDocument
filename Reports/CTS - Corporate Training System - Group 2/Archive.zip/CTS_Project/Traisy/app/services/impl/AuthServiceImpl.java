package services.impl;

import commons.TSConst;
import controllers.Application;
import models.User;
import org.apache.shiro.subject.Subject;
import services.AuthService;

public class AuthServiceImpl implements AuthService {

    public boolean isAlreadyLogin() {
        Subject currentUser = new Subject.Builder().sessionId(Application.getSessionKey()).buildSubject();
        return currentUser.isAuthenticated();
    }

    public boolean isSystemAdmin(User user) {
        return user.Role.id == TSConst.USER_ROLE.SYSTEM_ADMIN.value;
    }

    @Override
    public boolean isAdmin(User user) {
        return user.Role.id == TSConst.USER_ROLE.ADMIN.value;
    }

    @Override
    public boolean isManager(User user) {
        return user.Role.id == TSConst.USER_ROLE.MANAGER.value;
    }

    @Override
    public boolean isAuthor(User user) {
        return user.Role.id == TSConst.USER_ROLE.AUTHOR.value;
    }

    @Override
    public boolean isLearner(User user) {
        return user.Role.id == TSConst.USER_ROLE.LEARNER.value;
    }

    @Override
    public boolean isAdminOrManager(User user) {
        return isAdmin(user) || isManager(user);
    }

    @Override
    public boolean isAuthorOrLearner(User user) {
        return isAuthor(user) || isLearner(user);
    }
}
