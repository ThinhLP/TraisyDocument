package services.impl;

import commons.TSConst;
import commons.Utils;
import daos.PlanDao;
import daos.ProgramDao;
import fronts.ProgramData;
import models.*;
import play.db.jpa.JPAApi;
import services.CourseService;
import services.LogService;
import services.PlanService;
import services.ProgramService;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class ProgramServiceImpl implements ProgramService {

    @Inject
    private ProgramDao programDao;
    @Inject
    private PlanDao planDao;
    @Inject
    private JPAApi jpaApi;
    @Inject
    private PlanService planService;
    @Inject
    private CourseService courseService;

    /**
     * create a program
     *
     * @param title
     * @param description
     * @param startDate
     * @param endDate
     * @param planId
     * @return program data that created
     */
    @Override
    public ProgramData createProgram(String title, String description, String startDate, String endDate, long planId) {
        Program addProgram = new Program();
        ProgramData result = new ProgramData();
        addProgram.title = title;
        addProgram.description = description;
        result.title = title;
        result.description = description;
        if (startDate != null) {
            Timestamp start = Utils.convertStringToTimestamp(startDate);
            result.startDate = start;
            addProgram.startDate = start;
        }
        if (endDate != null) {
            Timestamp end = Utils.convertStringToTimestamp(endDate);
            result.endDate = end;
            addProgram.endDate = end;
        }

        Plan plan = planDao.findPlanById(planId, jpaApi.em());

        if (plan != null) {
            addProgram.Plan = plan;

        }
        try {
            programDao.addProgram(addProgram, jpaApi.em());
            return result;

        } catch (Exception e) {
            String err = String.format("There is an error when add program : %s",
                    e.getMessage());
            LogService.logger.error(err);
            return null;
        }
    }

    @Override
    public boolean updateProgram(long id, String title, long startDate, long endDate) {
        EntityManager em = jpaApi.em();
        Program program = programDao.findProgramById(id, em);

        if (program == null) {
            return false;
        }

        program.title = title;
        if (startDate > 0 && endDate > 0) {
            program.startDate = new Timestamp(startDate);
            program.endDate = new Timestamp(endDate);
        }

        return programDao.updateProgram(program, em);
    }

    /**
     * find all program by plan
     *
     * @param planId
     * @return
     */
    @Override
    public List<ProgramData> listAllProgramByPlanId(long planId) {
        List<Program> programs;

        programs = programDao.getAllProgramByPlanId(planId, jpaApi.em());
        List<ProgramData> programDataList = new ArrayList<>();

        for (Program program :
                programs) {
            ProgramData temp = new ProgramData();
            temp.description = program.description;
            temp.title = program.title;
            temp.endDate = program.endDate;
            temp.startDate = program.startDate;
            temp.id = program.id;
            programDataList.add(temp);
        }
        return programDataList;
    }

    @Override
    public boolean removeProgram(long id) {
        EntityManager em = jpaApi.em();
        Program program = programDao.findProgramById(id, em);
        if (program != null) {
            program.status = TSConst.COMMON_STATUS.DELETED;
            return programDao.updateProgram(program, em);
        }
        return false;
    }

    @Override
    public ProgramData convertToProgramData(Program program) {
        if (program == null) {
            return null;
        }
        ProgramData data = new ProgramData();
        data.id = program.id;
        data.title = program.title;
        data.startDate = program.startDate;
        data.endDate = program.endDate;
        data.Plan =  planService.convertToPlanData(program.Plan);
        if (program.Courses!=null && !program.Courses.isEmpty()) {
            data.Courses = courseService.convertToCourseDataList(program.Courses);
        }
        return data;
    }

    @Override
    public List<ProgramData> convertToListProgramData(List<Program> programs, long currentUserId) {
        List<ProgramData> result = new ArrayList<>();
        for (Program program : programs) {
            ProgramData temp = convertToProgramData(program);
            temp.Courses = courseService.convertToCourseDataList(program.Courses, currentUserId);
            result.add(temp);
        }
        return result;
    }

    @Override
    public ProgramData createSimpleProgram(Plan plan, String title, long startDate, long endDate) {
        EntityManager em = jpaApi.em();
        Program program = new Program();
        program.title = title;
        program.Plan = plan;
        program.status = TSConst.COMMON_STATUS.PUBLIC;
        if (startDate > 0 && endDate > 0) {
            program.startDate = new Timestamp(startDate);
            program.endDate = new Timestamp(endDate);
        }
        return convertToProgramData(programDao.addProgram(program, em));
    }
}
