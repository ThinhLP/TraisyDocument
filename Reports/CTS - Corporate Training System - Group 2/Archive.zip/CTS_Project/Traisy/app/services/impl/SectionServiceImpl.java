package services.impl;

import daos.CourseDao;
import daos.CourseLectureDao;
import daos.CourseSectionDao;
import daos.UserDao;
import fronts.CourseSectionData;
import models.Course;
import models.CourseLecture;
import models.CourseSection;
import play.db.jpa.JPAApi;
import services.LectureService;
import services.SectionService;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SectionServiceImpl implements SectionService {

    @Inject private UserDao userDao;
    @Inject private CourseSectionDao courseSectionDao;
    @Inject private CourseDao courseDao;
    @Inject private CourseLectureDao courseLectureDao;
    @Inject private JPAApi jpaApi;
    @Inject private LectureService lectureService;

    @Override
    public CourseSection findSectionById(long id) {
        return jpaApi.em().find(CourseSection.class, id);
    }

    public int getNewSectionOrder(Course course) {
        List<CourseSection> list = courseSectionDao.getAllSectionByCourseId(course.id, jpaApi.em());
        if (list == null) {
            return -1;
        }
        return list.size() + 1;
    }

    public CourseSectionData convertToSectionData(CourseSection section) {
        CourseSectionData data = new CourseSectionData();
        data.title = section.title;
        data.id = section.id;
        data.order = section.order;
        if (section.CourseLectures != null){
            data.CourseLectures = lectureService.convertToListLectureData(section.CourseLectures);
        }
        return data;
    }

    @Override
    public List<CourseSectionData> convertToListSectionData(List<CourseSection> sections) {
        List<CourseSectionData> result = new ArrayList<>();
        for (CourseSection section :
                sections) {
            result.add(convertToSectionData(section));
        }
        return result;
    }

    @Override
    public List<CourseSection> getAllSectionWithPublishLecture(long courseId) {
        List<CourseSection> result = new ArrayList<>();
        EntityManager em = jpaApi.em();
        Course course = courseDao.findCourseById(courseId,em);
        for(CourseSection section : course.CourseSections){
            List<CourseLecture> publishLecturesOfSection =  courseLectureDao.getAllPublishLectureInSection(section.id, em);
            if (publishLecturesOfSection != null && !publishLecturesOfSection.isEmpty()){
                section.CourseLectures = publishLecturesOfSection;
                result.add(section);
            }
        }
        return result;
    }

    @Override
    public CourseSectionData createSection(Course course, String sectionTitle) {
        EntityManager em = jpaApi.em();
        CourseSection section = new CourseSection();
        section.title = sectionTitle;
        section.order = getNewSectionOrder(course);
        section.Course = course;
        section.CourseLectures = new ArrayList<>();

        CourseSection newSection = courseSectionDao.createSection(section, em);
        if (newSection != null) {
            courseDao.updateCourseUploadDate(course, new Timestamp(new Date().getTime()), em);
            return convertToSectionData(newSection);
        } else {
            return null;
        }
    }

    @Override
    public boolean updateSection(long sectionId, String title) {
        CourseSection section = findSectionById(sectionId);
        if (section != null) {
            section.title =  title;
            return courseSectionDao.updateSection(section, jpaApi.em());
        }
        return false;
    }

    @Override
    public boolean removeSection(long sectionId) {
        CourseSection section = findSectionById(sectionId);
        if (section != null) {
            jpaApi.em().remove(section);
        }
        return false;
    }
}
