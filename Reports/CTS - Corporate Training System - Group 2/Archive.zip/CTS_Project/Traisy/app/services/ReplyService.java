package services;

import com.google.inject.ImplementedBy;
import fronts.CourseFeedbackData;
import fronts.CourseFeedbackReplyData;
import models.CourseFeedback;
import services.impl.CourseFeedbackServiceImpl;
import services.impl.ReplyServiceImpl;

import java.sql.Timestamp;
import java.util.List;

@ImplementedBy(ReplyServiceImpl.class)
public interface ReplyService {


    CourseFeedbackReplyData addReply(String content, Timestamp createDate, int status, long userId, long feedbackId);

    boolean removeReply(long id);

    boolean updateReply(long id, String content, Timestamp createDate);
}
