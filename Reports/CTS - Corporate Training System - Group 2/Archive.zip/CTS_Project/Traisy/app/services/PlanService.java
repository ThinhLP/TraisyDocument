package services;

import com.google.inject.ImplementedBy;
import fronts.PlanData;
import fronts.UserData;
import fronts.UserPlanData;
import fronts.report.AuthorPlanReportDetail;
import fronts.report.LearnerPlanReportDetail;
import fronts.report.PlanReport;
import models.Brand;
import models.Plan;
import models.User;
import services.impl.PlanServiceImpl;

import java.io.File;
import java.util.List;

@ImplementedBy(PlanServiceImpl.class)
public interface PlanService {

    List<Plan> listAllPlansByBrandId(int brandId);

    List<PlanData> getPlansByBrandId(int brandId, int pageNo, int size);

    List<Plan> listAllPlanByUserId(long userId);

    List<Plan> getAllParticipantPlan(long userId);

    List<PlanData> listAllPlanByTitle(String title);

    PlanData createPlan(String title, String startDate, String endDate, String description);

    PlanData convertToPlanData(Plan plan);

    boolean removePlan(long id, User user);

    boolean updatePlanBasicInfo(Plan plan, String title, String description, long startDate, long endDate);

    Plan findPlanByTitleUrl(String titleUrl);

    Plan findPlanById(long id);

    Plan createSimplePlan(String title, User user);

    void updatePlanImage(File file, String planTitle);

    void addUserToPlan(Plan plan, long userId);

    List<UserData> getUsersOfPlan(Plan plan, int role, int pageNo, int size);
    List<UserData> getAllUsersOfPlan(Plan plan, int role);

    List<LearnerPlanReportDetail> getLearnerPlanParticipants(Plan plan, int pageNo, int size);

    List<LearnerPlanReportDetail> searchLearnerPlanParticipants(Plan plan, String name, int pageNo, int size);

    List<LearnerPlanReportDetail> getAllLearnerPlanParticipants(Plan plan);

    List<UserData> getPlanAvailableUsers(Plan plan, Brand brand, int role, int pageNo, int size);

    List<PlanData> getAllPlanOfUserWithProcessOfCourse(long userId);

    PlanData convertToFullPlanData(Plan plan, long userId);

    boolean removeUserFromPlan(Plan plan, User user);

    boolean hasParticipated(Plan plan, User user);

    LearnerPlanReportDetail getLearnerReportDetail(Plan plan, User user);

    double getUserPlanProcess(Plan plan, User user);

    List<PlanReport> getPlanReportList(int brandId);

    List<AuthorPlanReportDetail> getAuthorPlanParticipants(Plan plan, int pageNo, int size);

    List<AuthorPlanReportDetail> getAllAuthorPlanParticipants(Plan plan);

    AuthorPlanReportDetail getAuthorReportDetail(Plan plan, User user);

}
