package services;

import com.google.inject.ImplementedBy;
import models.Answer;
import models.Brand;
import models.Question;
import services.impl.AnswerServiceImpl;
import services.impl.BrandServiceImpl;

import java.io.File;
import java.util.List;


@ImplementedBy(AnswerServiceImpl.class)
public interface AnswerService {

    boolean removeAnswer(Question question, long id);

    Answer createAnswer(String content, int correct, long questionId);

    boolean updateAnswer(long id,int correct, String content);

    List<Answer> getAllAnswerByQuestionId(long questionId);


}
