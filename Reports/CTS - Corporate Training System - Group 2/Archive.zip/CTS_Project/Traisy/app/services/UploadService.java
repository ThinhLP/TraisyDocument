package services;

import com.google.inject.ImplementedBy;
import models.Course;
import models.CourseLecture;
import play.mvc.Http;
import services.impl.UploadServiceImpl;

import java.nio.file.Path;

@ImplementedBy(UploadServiceImpl.class)
public interface UploadService {

    Path uploadIntroVideo(Course course, Http.MultipartFormData.FilePart videoFile);

    Path uploadLectureVideo(CourseLecture lecture, Http.MultipartFormData.FilePart videoFile);

    Path uploadLectureText(CourseLecture lecture, Http.MultipartFormData.FilePart textFile);

    String uploadLectureSlideshow(CourseLecture lecture, Http.MultipartFormData.FilePart slideShowFile);

    //String testUploadLectureSlideshow(CourseLecture lecture, Http.MultipartFormData.FilePart slideShowFile);

}
