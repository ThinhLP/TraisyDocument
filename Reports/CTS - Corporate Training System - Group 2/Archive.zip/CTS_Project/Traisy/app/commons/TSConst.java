package commons;

import com.google.inject.Singleton;
import play.Configuration;

import javax.inject.Inject;

@Singleton
public class TSConst {

    @Inject private static Configuration configuration;

    public static class USER_SESSION {
        public static final String USERNAME = "username";
        public static final String PREVIOUS_URL = "prevUrl";
    }

    public static class USER_CONFIG {
        public static class STATUS {
            public static int ACTIVE = 1;
            public static int LOCKED = 0;
        }
    }

    public static class COMMON_STATUS {
        public static int PUBLIC = 1;
        public static int PRIVATE = 0;
        public static int DELETED = -1;
    }

    public static class LIST_CONFIG {
        public static int USER_LIST_MAX_SIZE = 12;
    }

    public enum USER_ROLE {
        SYSTEM_ADMIN(1),
        ADMIN(2),
        MANAGER(3),
        AUTHOR(4),
        LEARNER(5),
        GUEST(6);

        public final int value;

        USER_ROLE(int value) {
            this.value = value;
        }

        public static USER_ROLE getRole(int roleId) {
            if (roleId == SYSTEM_ADMIN.value) return SYSTEM_ADMIN;
            if (roleId == ADMIN.value) return ADMIN;
            if (roleId == MANAGER.value) return MANAGER;
            if (roleId == AUTHOR.value) return AUTHOR;
            if (roleId == AUTHOR.value) return LEARNER;
            return GUEST;
        }
    }

    public static class MESSAGE{
        public static final String USERNAME_ERROR = "Tên đăng nhập phải từ 4 tới 35 ký tự";
        public static final String PASSWORD_ERROR = "Mật khẩu phải từ 4 tới 30 ký tự";
        public static final String FULLNAME_ERROR = "Họ và tên phải từ 5 tới 80 ký tự";
    }
    public static class FIELD_VALIDATION {

        public static final int MIN_NAME_LEN = 4;

        public static final int MAX_NAME_LEN = 35;

        public static final int MIN_EMAIL_LEN = 5;

        public static final int MAX_EMAIL_LEN = 40;

        public static final int MIN_TITLE_LEN = 5;

        public static final int MAX_TITLE_LEN = 80;

        public static final int MIN_PASSWORD_LEN = 4;

        public static final int MAX_PASSWORD_LEN = 30;

        public static final int MAX_REVIEW_TITLE_LEN = 80;

        public static final int MAX_REVIEW_CONTENT_LEN = 200;

        public static final long MAX_SIZE_USER_PICTURE = Long.valueOf(configuration.getString("max.size.user.picture"));

        public static final int MIN_QUESTION_LENGTH = 5;

        public static final int MAX_QUESTION_LENGTH = 500;


    }

    public static class COURSE_CONFIG {
        public static class STATUS {
            public static int PRIVATE = 0;
            public static int PUBLIC = 1;
            public static int REVIEWING = 2;
            public static int DELETE = -1;
        }

        public static class FEEDBACK {
            public enum FEEDBACK_STATUS {
                NOT_APPROVED(0),
                APPROVED(1);

                public final int value;

                FEEDBACK_STATUS(int value) {
                    this.value = value;
                }

                public static boolean isValidStatus(int type) {
                    return (type == NOT_APPROVED.value) || (type == APPROVED.value);
                }
            }
        }
    }

    public static class LECTURE_CONFIG {
        public enum LECTURE_TYPE {
            VIDEO(0),
            TEXT(1),
            QUIZ(2),
            POWERPOINT(3);

            public final int value;

            LECTURE_TYPE(int value) {
                this.value = value;
            }

            public static boolean isValidType(int type) {
                return (type == VIDEO.value) || (type == TEXT.value) || (type == QUIZ.value) || (type == POWERPOINT.value);
            }
        }

        public enum LEARNING_STATUS {
            NOT_COMPLETED(0),
            COMPLETED(1);

            public final int value;

            LEARNING_STATUS(int value) {
                this.value = value;
            }
        }
    }

    public static class WOWZA_CONFIG {
        public static String PLAYER_KEY = "PLAY1-7PVeE-yhrtu-7mdhW-aRG3f-RUdYY";

    }

    public static class UPLOAD_CONFIG {
        public static final String VIDEO_ROOT_PATH = "C:/traisy/videos";
        public static final String INTRO_VIDEO_ROOT_PATH = "C:/traisy/videos/intro";

        public static class IMAGE {
            public static int MAX_IMAGE_SIZE = 5242880; // 5MB
            public static String ALLOW_TYPES = "png,jpg,jpeg";
            public static String ACCEPT_FILES = ".png,.jpg,.jpeg";
        }

        public static class TEXT {
            public static int MAX_TEXT_SIZE = 10485760; // 10MB
        }

        public static class SLIDE_SHOW {
            public static int MAX_SLIDE_SHOW_SIZE = 20485760; // 10MB
            public static String ALLOW_TYPES = "ppt,pptx";
            public static String ACCEPT_FILES = ".ppt,.pptx";
        }

        public static class VIDEO {
            public static int MAX_INTRO_VIDEO_SIZE = 31457280; // 30MB
            public static int MAX_VIDEO_LECTURE_SIZE = 209715200; // 200MB
            public static String ALLOW_TYPES = "mp4";
            public static String ACCEPT_FILES = ".mp4";
        }
    }

    public static class QUIZ_CONFIG {
        public enum QUIZ_RESULT {
            FAIL(0),
            PASS(1);

            public final int value;

            QUIZ_RESULT(int value) {
                this.value = value;
            }
        }

        public enum QUESTION_TYPE {
            MULTIPLE_CHOICE(0),
            ESSAY(1),
            SINGLE_CHOICE(2);

            public final int value;

            QUESTION_TYPE(int value) {
                this.value = value;
            }

            public static boolean isValidType(int type) {
                return (type == MULTIPLE_CHOICE.value) || (type == ESSAY.value);
            }
        }
    }
}
