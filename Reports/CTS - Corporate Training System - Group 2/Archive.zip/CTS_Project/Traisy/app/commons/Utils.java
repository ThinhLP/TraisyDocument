package commons;

import models.Answer;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import services.LogService;

import javax.imageio.ImageIO;
import javax.persistence.EntityManager;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Utils {

    public static Timestamp convertStringToTimestamp(String dateString){
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date ;
        try {
            date = dateFormat.parse(dateString);
            long time = date.getTime();
            Timestamp timestamp = new Timestamp(time);
            return timestamp;
        } catch (Exception e){
            LogService.logger.error(e.getMessage());
            return null;
        }
    }

    public static String convertToSimpleDate(Timestamp timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(timestamp);
    }

    public static String removeAccents(String text) {
        return text == null ? null
                : Normalizer.normalize(text, Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "")
                .replaceAll("[đ]+", "d")
                .replaceAll("[Đ]+", "D")
                .replaceAll("[\\W]+", "-").toLowerCase();
    }

    public static byte[] getBytesFromFile(File file) {
        try {
            byte[] fileContent = Files.readAllBytes(file.toPath());
            return fileContent;
        } catch (IOException ioe) {
            LogService.logger.error("Cannot convert file to bytes", ioe);
        }
        return null;
    }

    public static List<byte[]> convertPPTtoImages(File file){
        try {
            List<byte[]> result = new ArrayList<>();
            //creating an empty presentation
            String extensionOfFile = FilenameUtils.getExtension(file.getName());
            if (extensionOfFile.equals("ppt")) {
                HSLFSlideShow ppt = new HSLFSlideShow(new FileInputStream(file));
                Dimension pgsize = ppt.getPageSize();

                for (HSLFSlide slide : ppt.getSlides()) {
                    BufferedImage img = new BufferedImage(pgsize.width, pgsize.height, BufferedImage.TYPE_INT_RGB);
                    Graphics2D graphics = img.createGraphics();

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();

                    graphics.setPaint(Color.white);
                    graphics.fill(new Rectangle2D.Float(0, 0, pgsize.width, pgsize.height));
                    slide.draw(graphics);

                    ImageIO.write(img, "png", baos);
                    baos.flush();
                    byte[] imageInByte = baos.toByteArray();
                    result.add(imageInByte);
                    baos.close();
                }
            } else {
                XMLSlideShow ppt = new XMLSlideShow(new FileInputStream(file));
                Dimension pgsize = ppt.getPageSize();

                for (XSLFSlide slide: ppt.getSlides()) {
                    BufferedImage img = new BufferedImage(pgsize.width, pgsize.height, BufferedImage.TYPE_INT_RGB);
                    Graphics2D graphics = img.createGraphics();

                    graphics.setPaint(Color.white);
                    graphics.fill(new Rectangle2D.Float(0, 0, pgsize.width, pgsize.height));
                    slide.draw(graphics);

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    ImageIO.write(img, "png", baos);
                    baos.flush();
                    byte[] imageInByte = baos.toByteArray();
                    result.add(imageInByte);
                    baos.close();
                }
            }
            return result;
        } catch (IOException ex) {
            LogService.logger.error("Error", ex);
            return null;
        }
    }

    public static boolean convertPPTtoImage(File file, String destination, String fileName) {
        try {
            String extensionOfFile = FilenameUtils.getExtension(fileName);
            if (extensionOfFile.equals("ppt")) {
                FileInputStream is = new FileInputStream(file);
                HSLFSlideShow ppt = new HSLFSlideShow(is);
                is.close();

                //getting the dimensions and size of the slide
                Dimension pgsize = ppt.getPageSize();

                int i = 0;
                String outputDir = destination + "/";
                for (HSLFSlide slide : ppt.getSlides()) {
                    BufferedImage img = new BufferedImage(pgsize.width, pgsize.height, BufferedImage.TYPE_INT_RGB);
                    Graphics2D graphics = img.createGraphics();

                    graphics.setPaint(Color.white);
                    graphics.fill(new Rectangle2D.Float(0, 0, pgsize.width, pgsize.height));
                    slide.draw(graphics);

                    String name = "p" + (i + 1 < 10 ? "0" + (i + 1) : (i + 1));

                    FileOutputStream out = new FileOutputStream(outputDir + name + ".png");
                    javax.imageio.ImageIO.write(img, "png", out);
                    out.close();
                }
                return true;
            } else {
                FileInputStream is = new FileInputStream(file);
                XMLSlideShow ppt = new XMLSlideShow(is);
                is.close();
                //getting the dimensions and size of the slide
                Dimension pgsize = ppt.getPageSize();

                List<XSLFSlide> slide = ppt.getSlides();

                String outputDir = destination+ "/";
                for (int i = 0; i < slide.size(); i++) {
                    BufferedImage img = new BufferedImage(pgsize.width, pgsize.height, BufferedImage.TYPE_INT_RGB);
                    Graphics2D graphics = img.createGraphics();

                    graphics.setPaint(Color.white);
                    graphics.fill(new Rectangle2D.Float(0, 0, pgsize.width, pgsize.height));
                    slide.get(i).draw(graphics);

                    String name = "p" + (i + 1 < 10 ? "0" + (i + 1) : (i + 1));


                    FileOutputStream out = new FileOutputStream(outputDir  + name + ".png");
                    javax.imageio.ImageIO.write(img, "png", out);
                    out.close();
                }
                return true;
            }
        } catch (Exception ex) {
            return false;
        }

    }

    public static String secondToHourMinutes(Integer totalSeconds) {
        if (totalSeconds <= 0) return "";
        int totalMinutes = totalSeconds / 60;
        int minutes = totalMinutes % 60;
        int hours = totalMinutes / 60;
        return (hours > 0 ? String.format("%sh ", hours) : "") + (minutes > 0 ? String.format("%sp", minutes) : "");
    }

    public static String secondToMinutes(Integer totalSeconds) {
        if (totalSeconds == null) {
            return "0";
        }
        if (totalSeconds <= 0) return "0";

        int seconds = totalSeconds % 60;
        int totalMinutes = totalSeconds / 60;

        if (totalMinutes >= 60) {
            return secondToHourMinutes(totalSeconds);
        }

        String minStr = "";
        if (totalMinutes < 10) {
            minStr += totalMinutes;
        } else {
            minStr += totalMinutes;
        }

        String secStr = "";
        if (seconds < 10) {
            secStr = "0" + seconds;
        } else {
            secStr += seconds;
        }

        return minStr + ":" + secStr;
    }

    public static String normalizeFileName(String filename) {
        return Normalizer.normalize(filename, Normalizer.Form.NFD)
                .replaceAll("\\s","-")
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "")
                .replaceAll("[đ]+", "d")
                .replaceAll("[Đ]+", "D");
    }

    public static int getMinutes(int duration) {
        if (duration == 0) {
            return 0;
        }
        return duration/60;
    }

    public static int getSeconds(int duration) {
        if (duration == 0) {
            return 0;
        }
        int min = getMinutes(duration);
        return duration - min * 60;
    }

    public static <T> void removeAllElements(List<T> list, EntityManager em) {
        if (list == null || list.isEmpty()) {
            return;
        }
        int num = list.size();
        for (int i = 0; i < num; i++) {
            T elm = list.get(i);
            list.remove(elm);
            em.remove(elm);
            i--;
            num--;
        }
    }

    public static String getDurationString(Timestamp creationDate) {
        Long time = new Date().getTime() - creationDate.getTime();
        long MUL_DATE = 24 * 60 * 60 * 1000;
        long MUL_HOUR = MUL_DATE / 24;
        long MUL_MIN = MUL_DATE / (24 * 60);
        long MUL_SEC = MUL_DATE / (24 * 60 * 60);
        long MUL_MONTH = MUL_DATE * 30;
        long MUL_YEAR = MUL_MONTH * 365;

        int year, month;
        Long day, hour, min, sec;

        year = new Long(time/ MUL_YEAR).intValue();
        if (year > 0) {
            return year + " năm trước";
        }

        month = new Long(time / MUL_MONTH).intValue();
        if (month > 0) {
            return month + " tháng trước";
        }

        day = time / MUL_DATE;
        if (day > 0) {
            if (day == 1) {
                return "Hôm qua";
            }
            return day + " ngày trước";
        }

        hour = time / MUL_HOUR;
        if (hour > 0) {
            return hour + " giờ trước";
        }

        min = time / MUL_MIN;
        if (min > 0) {
            return min + " phút trước";
        }

        sec = time / MUL_SEC;

        return sec + " giây trước";
    }

    public static String toNumberString(double number) {
        int tmp = new Double(number * 10).intValue();
        if (tmp % 10 == 0) {
            return String.format("%d", tmp / 10);
        }
        return String.format("%.1f", number);
    }

    public static int getIntegerPercentage(double number) {
        return new Double(Math.floor(number)).intValue();
    }

    public static int getNumOfCorrectAnswers(List<Answer> answers) {
        int result = 0;
        for (Answer answer: answers) {
            result += answer.isCorrect;
        }
        return result;
    }

    public static int countNumberOfPages(int size, int noOfCoursesPerPage) {
        Double result = Math.ceil(size * 1.0 / noOfCoursesPerPage);
        return result.intValue();
    }
}
