package security.authorization.handler;

import commons.TSConst;
import controllers.routes;
import models.User;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Result;
import security.authorization.Authorization;
import services.UserService;

import javax.inject.Inject;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

public class AuthorizationAnnotationHandler extends Action<Authorization> {

    @Inject UserService userService;

    @Override
    public CompletionStage<Result> call(Http.Context ctx) {
        ctx.session().put(TSConst.USER_SESSION.PREVIOUS_URL,  ctx.request().uri());
        TSConst.USER_ROLE role = configuration.role();
        if (role == TSConst.USER_ROLE.GUEST) {
            return CompletableFuture.completedFuture(redirect(routes.Application.loginPage().url()));
        }

        User currentUser = userService.getCurrentUser();

        if (currentUser == null) {
            return CompletableFuture.completedFuture(redirect(routes.Application.loginPage().url()));
        }

        // Skip authorization
        if (currentUser.Role.id == TSConst.USER_ROLE.SYSTEM_ADMIN.value) {
            return delegate.call(ctx);
        }

        if (currentUser.Brand.status == TSConst.COMMON_STATUS.DELETED) {
            return CompletableFuture.completedFuture(redirect(routes.Application.notFoundPage().url()));
        }

        if (currentUser.Role.id <= role.value) {
            return delegate.call(ctx);
        }

        return CompletableFuture.completedFuture(redirect(routes.Application.accessDeniedPage().url()));
    }
}
