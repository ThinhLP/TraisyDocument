package security.authorization;

import commons.TSConst;
import play.mvc.With;
import security.authorization.handler.AuthorizationAnnotationHandler;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@With(AuthorizationAnnotationHandler.class)
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)

public @interface Authorization {
    TSConst.USER_ROLE role() default TSConst.USER_ROLE.GUEST;
}
