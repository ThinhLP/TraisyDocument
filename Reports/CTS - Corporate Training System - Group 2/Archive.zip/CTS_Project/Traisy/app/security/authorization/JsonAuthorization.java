package security.authorization;

import commons.TSConst;
import play.mvc.With;
import security.authorization.handler.JsonAuthorizationHandler;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@With(JsonAuthorizationHandler.class)
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface JsonAuthorization {

    TSConst.USER_ROLE role() default TSConst.USER_ROLE.GUEST;

}
