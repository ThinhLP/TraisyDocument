package security;

import org.apache.shiro.authc.*;
import org.apache.shiro.realm.jdbc.JdbcRealm;
import org.apache.shiro.util.JdbcUtils;
import services.UserService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TraisyRealm extends JdbcRealm {

    @Override
    public boolean supports(AuthenticationToken token) {
        return token instanceof UsernamePasswordToken;
    }

    private String[] executeQueryForAuth(Connection conn, String statement, String username, int n) throws SQLException {
        String[] result = new String[n];
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement(statement);
            ps.setString(1, username);
            rs = ps.executeQuery();
            boolean foundResult = false;
            while (rs.next()) {
                if (foundResult) {
                    throw new AuthenticationException("More than one user row found for user [" + username + "]. Usernames must be unique.");
                }
                //result[0] = rs.getString(1);
                for (int i=0;i<n;i++) {
                    result[i] =  rs.getString(i+1);
                }
                foundResult = true;
            }
        } finally {
            JdbcUtils.closeResultSet(rs);
            JdbcUtils.closeStatement(ps);
        }

        return result;
    }

    protected AuthenticationInfo doGetAuthenticationInfo(Connection conn,  String username) throws SQLException {
        AuthenticationInfo info = null;
        String [] passResult = executeQueryForAuth(conn, authenticationQuery, username, 2);
        String password = passResult[0];
        String salt = passResult[1];
        info = new TraisySaltedAuthenticationInfo(username, password, salt);
        return info;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        // identify account to log to
        UsernamePasswordToken userPassToken = (UsernamePasswordToken) token;
        final String username = userPassToken.getUsername();

        if (username == null) {
            System.out.println("Username is null.");
            return null;
        }

        Connection conn = null;
        AuthenticationInfo info = null;
        try {
            conn = dataSource.getConnection();

             info = doGetAuthenticationInfo(conn, username);

            if (info == null) {
                throw new UnknownAccountException("No account found for user [" + username + "]");
            }

        } catch (SQLException e) {
            final String message = "There was a SQL error while authenticating user [" + username + "]";
            System.out.println(message);
            //  LogService.logger.error(message, e);
            // Rethrow any SQL errors as an authentication exception
            throw new AuthenticationException(message, e);
        } finally {
            JdbcUtils.closeConnection(conn);
        }

        return info;
    }
}
