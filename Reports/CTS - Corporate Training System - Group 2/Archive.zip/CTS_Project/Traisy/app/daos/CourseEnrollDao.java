package daos;

import com.google.inject.ImplementedBy;
import daos.impl.CourseEnrollDaoImpl;
import daos.impl.RoleDaoImpl;
import models.CourseEnroll;
import models.Role;
import models.User;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Created by Hung on 12/3/2018.
 */
@ImplementedBy(CourseEnrollDaoImpl.class)
public interface CourseEnrollDao {

    List<User> findUsersEnrollInCourse(long courseId, EntityManager em);

    CourseEnroll getUserCourseEnroll(long courseId, long userId, EntityManager em);

    boolean create(CourseEnroll enroll, EntityManager em);
}
