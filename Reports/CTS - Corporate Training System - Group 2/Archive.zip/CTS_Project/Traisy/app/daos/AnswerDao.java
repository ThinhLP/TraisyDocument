package daos;

import com.google.inject.ImplementedBy;
import daos.impl.AnswerDaoImpl;
import daos.impl.BrandDaoImpl;
import models.Answer;
import models.Brand;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Created by Hung on 6/2/2018.
 */
@ImplementedBy(AnswerDaoImpl.class)
public interface AnswerDao {

    Answer findAnswerById(long id, EntityManager em);
    List<Answer> getAllAnswerByQuestionId (long questionId, EntityManager em);

    Answer createAnswer(Answer answer, EntityManager em);

    boolean removeAnswer(long id, EntityManager em);

    boolean updateAnswer(Answer answer, EntityManager em);
}
