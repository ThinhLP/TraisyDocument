package daos;

import com.google.inject.ImplementedBy;
import daos.impl.PlanParticipantDaoImpl;
import fronts.UserData;
import fronts.UserPlanData;
import models.Plan;
import models.PlanParticipant;
import models.User;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Created by Hung on 2/2/2018.
 */
@ImplementedBy(PlanParticipantDaoImpl.class)
public interface PlanParticipantDao {
    boolean isParticipated(long planId, long userId,  EntityManager em);
    boolean addUserToPlan(Plan plan, User user, EntityManager em);
    List<User> getUserParticipants(Plan plan, int role, int pageNo, int size, EntityManager em);
    List<User> getAllUserParticipants(Plan plan, int role, EntityManager em);
    List<Plan> getAllPlansOfUser(long userId, EntityManager em);
    PlanParticipant findPlanParticipant(long planId, long userId, EntityManager em);
    boolean removeUserFromPlan(long planId, long userId, EntityManager em);

    List<Object[]> getUserParticipantsWithDate(Plan plan, int role, int pageNo, int size, EntityManager em);
    List<Object[]> searchUserParticipants(Plan plan, int role, String name, int pageNo, int size, EntityManager em);

    List<Object[]> getAllUserParticipantsWithDate(Plan plan, int role, EntityManager em);
}
