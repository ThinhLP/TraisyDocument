package daos;

import com.google.inject.ImplementedBy;
import daos.impl.CourseFeedbackDaoImpl;
import models.CourseFeedback;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Created by Hung on 17/2/2018.
 */
@ImplementedBy(CourseFeedbackDaoImpl.class)
public interface CourseFeedbackDao {

    CourseFeedback findFeedbackById(long id, EntityManager em);

    List<CourseFeedback> getAllFeedbackByCourse(long courseId, EntityManager em);

    CourseFeedback createFeedback(CourseFeedback courseFeedback, EntityManager em);

    boolean updateFeedback(CourseFeedback courseFeedback, EntityManager em);

    boolean removeFeedback(long id, EntityManager em);

    boolean removeListFeedback(List<CourseFeedback> feedbackReplies, EntityManager em);

   /* boolean deleteFeedbackReplies(List<CourseFeedback> replies, EntityManager em);*/
}
