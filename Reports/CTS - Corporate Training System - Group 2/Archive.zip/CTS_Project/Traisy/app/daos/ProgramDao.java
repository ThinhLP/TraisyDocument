package daos;

import com.google.inject.ImplementedBy;
import daos.impl.ProgramDaoImpl;
import models.Program;

import javax.persistence.EntityManager;
import java.util.List;

@ImplementedBy(ProgramDaoImpl.class)
public interface ProgramDao {

    Program findProgramById(long id, EntityManager em);

    List<Program> getAllProgramByPlanId(long id, EntityManager em);

    Program addProgram(Program addProgram, EntityManager em);

    boolean updateProgram(Program updateProgram, EntityManager em);

}
