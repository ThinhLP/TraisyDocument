package daos;


import com.google.inject.ImplementedBy;
import daos.impl.PlanDaoImpl;
import models.Plan;

import javax.persistence.EntityManager;
import java.sql.Timestamp;
import java.util.List;

@ImplementedBy(PlanDaoImpl.class)
public interface PlanDao {

    Plan findPlanById(long id, EntityManager em);

    List<Plan> getAllPlans(int brandId, EntityManager em);

    List<Plan> getPlans(int brandId, int pageNo, int size, EntityManager em);

    List<Plan> getAllPlanByUserId(long userId, EntityManager em);

    List<Plan> getAllPlanByTitle(String title, EntityManager em);

    Plan createPlan(Plan plan, EntityManager em);

    boolean updatePlan(Plan plan, EntityManager em);

    boolean removePlan(long id, EntityManager em);

    Plan findPlanByTitleUrl(String titleUrl, EntityManager em);

    boolean updatePlanInfo(Plan plan, String newTitle, String newDescription, Timestamp startDate, Timestamp endDate, EntityManager em);


}
