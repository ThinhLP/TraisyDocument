package daos;

import com.google.inject.ImplementedBy;
import daos.impl.LearnerProcessDaoImpl;
import daos.impl.RoleDaoImpl;
import models.Course;
import models.CourseLecture;
import models.LearnerProcess;
import models.Role;

import javax.persistence.EntityManager;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by Hung on 11/3/2018.
 */
@ImplementedBy(LearnerProcessDaoImpl.class)
public interface LearnerProcessDao {

    LearnerProcess findLearnerProcess(long id, EntityManager em);
    List<LearnerProcess> getFinishProcessOfUserAndCourse(long userId, long courseId, int status, EntityManager em);

    List<LearnerProcess> getAllProcessOfOfLecture(long lectureId, EntityManager em);

    boolean deleteProcess(long id, EntityManager em);

    boolean deleteListProcess(List<LearnerProcess> learnerProcesses, EntityManager em);

    LearnerProcess getLearnerProcessInLecture(long userId, long courseId, long lectureId, EntityManager em);

    boolean create(LearnerProcess process, EntityManager em);

    boolean update(LearnerProcess process, EntityManager em);

    CourseLecture getLastLearningLecture(long userId, long courseId, EntityManager em);

    List<LearnerProcess> getCompleteLearnerProcessOfUser(long userId, long courseId, EntityManager em);

    boolean updateLearningProcess(long courseId, long lectureId, long userId, EntityManager em);

    LearnerProcess getLearnerProcessByStatus(long courseId, long lectureId, long userId, int status, EntityManager em);

    Timestamp getLastLearningDate(long user, EntityManager em);

}
