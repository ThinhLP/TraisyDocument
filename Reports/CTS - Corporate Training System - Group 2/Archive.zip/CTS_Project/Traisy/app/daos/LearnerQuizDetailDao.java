package daos;

import com.google.inject.ImplementedBy;
import daos.impl.LearnerQuizDetailDaoImpl;
import models.LearnerQuizDetail;

import javax.persistence.EntityManager;

@ImplementedBy(LearnerQuizDetailDaoImpl.class)
public interface LearnerQuizDetailDao {

    LearnerQuizDetail findLearnerQuizDetailById(Long id, EntityManager em);
    boolean create(LearnerQuizDetail detail, EntityManager em);
    boolean update(LearnerQuizDetail detail, EntityManager em);

}
