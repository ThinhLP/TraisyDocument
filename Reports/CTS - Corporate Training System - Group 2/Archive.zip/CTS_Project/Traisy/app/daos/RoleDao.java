package daos;

import com.google.inject.ImplementedBy;
import daos.impl.BrandDaoImpl;
import daos.impl.RoleDaoImpl;
import models.Brand;
import models.Role;

import javax.persistence.EntityManager;

/**
 * Created by Hung on 2/2/2018.
 */
@ImplementedBy(RoleDaoImpl.class)
public interface RoleDao {
    Role findRoleById(int id, EntityManager em);
}
