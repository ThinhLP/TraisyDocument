package daos;

import com.google.inject.ImplementedBy;
import daos.impl.LearnerQuizDaoImpl;
import models.LearnerQuiz;

import javax.persistence.EntityManager;

@ImplementedBy(LearnerQuizDaoImpl.class)
public interface LearnerQuizDao {
    LearnerQuiz findLearnerQuizById(Long id, EntityManager em);
    boolean create(LearnerQuiz learnerQuiz, EntityManager em);
    boolean update(LearnerQuiz learnerQuiz, EntityManager em);

    LearnerQuiz getLastLearnerQuiz(long userId, long quizId,  EntityManager em);

}
