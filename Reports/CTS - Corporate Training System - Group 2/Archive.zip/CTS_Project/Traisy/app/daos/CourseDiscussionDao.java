package daos;

import com.google.inject.ImplementedBy;
import daos.impl.CourseDiscussionDaoImpl;
import models.CourseDiscussion;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Created by Hung on 2/2/2018.
 */
@ImplementedBy(CourseDiscussionDaoImpl.class)
public interface CourseDiscussionDao {

    CourseDiscussion findDiscussionById(long id, EntityManager em);

    List<CourseDiscussion> getAllDiscussion(long courseLectureID, EntityManager em);

    CourseDiscussion createDiscussion(CourseDiscussion courseDiscussion, EntityManager em);

    boolean updateDiscussion(CourseDiscussion courseDiscussion, EntityManager em);

    boolean removeDiscussion(long id, EntityManager em);

    boolean deleteListDiscussion(List<CourseDiscussion> lectureDiscussions, EntityManager em);

}
