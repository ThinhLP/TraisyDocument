package daos;

import com.google.inject.ImplementedBy;
import daos.impl.QuizDaoImpl;
import models.CourseLecture;
import models.Quiz;

import javax.persistence.EntityManager;

@ImplementedBy(QuizDaoImpl.class)
public interface QuizDao {

    Quiz findQuizById(Long id, EntityManager em);

    Quiz updateQuiz(Quiz quiz, EntityManager em);

    int getNewQuestionOrder(long quizId, EntityManager em);

}
