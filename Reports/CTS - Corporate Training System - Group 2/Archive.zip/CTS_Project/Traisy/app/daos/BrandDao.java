package daos;

import com.google.inject.ImplementedBy;
import daos.impl.BrandDaoImpl;
import models.Brand;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Created by Hung on 2/2/2018.
 */
@ImplementedBy(BrandDaoImpl.class)
public interface BrandDao {
    Brand findBrandById(int id, EntityManager em);

    List<Brand> getAllBrand(EntityManager em);

    Brand createSimpleBrand(String name, EntityManager em);
    Brand createBrand(Brand brand, EntityManager em);

    boolean updateBrand(Brand brand, EntityManager em);

    boolean removeBrand(int id, EntityManager em);

}
