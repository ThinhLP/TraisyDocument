package daos;

import com.google.inject.ImplementedBy;
import commons.TSConst;
import daos.impl.CourseLectureDaoImpl;
import models.Course;
import models.CourseLecture;

import javax.persistence.EntityManager;
import java.util.List;

@ImplementedBy(CourseLectureDaoImpl.class)
public interface CourseLectureDao  {

    CourseLecture findLectureById(long lectureId, EntityManager em);

    CourseLecture findLectureByTitleUrl(String titleUrl, EntityManager em);

    int getMaxLectureOrderInSection(long sectionId, EntityManager em);

    List<CourseLecture> getAllLecturesInSection(long sectionId, EntityManager em);

    List<CourseLecture> getAllPublishLectureInCourse(long courseId, EntityManager em);

    List<CourseLecture> getAllPublishLectureInSection(long sectionId, EntityManager em);
    CourseLecture createLecture(CourseLecture lecture, EntityManager em);
  
    CourseLecture updateLecture(CourseLecture lecture, EntityManager em);

    boolean removeLecture(CourseLecture lecture, EntityManager em);

    boolean isCourseOwner(long lectureId, long userId, EntityManager em);

    CourseLecture findLectureByQuizId(long quizId, EntityManager em);

    CourseLecture getFirstPublicLecture(long courseId, EntityManager em);

    CourseLecture getPreviousLecture(Course course, CourseLecture currentLecture, EntityManager em);

    CourseLecture getNextLecture(Course course, CourseLecture currentLecture, EntityManager em);

}
