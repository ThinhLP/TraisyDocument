package daos;

import com.google.inject.ImplementedBy;
import daos.impl.CourseFeedbackDaoImpl;
import daos.impl.CourseFeedbackReplyDaoImpl;
import models.CourseFeedback;
import models.CourseFeedbackReply;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Created by Hung on 17/2/2018.
 */
@ImplementedBy(CourseFeedbackReplyDaoImpl.class)
public interface CourseFeedbackReplyDao {

    CourseFeedbackReply findFeedbackReplyById(long id, EntityManager em);

    List<CourseFeedbackReply> getAllReplyByFeedback(long feedbackId, EntityManager em);

    List<CourseFeedbackReply> getAllReplyByCourseId(long courseId, EntityManager em);

    CourseFeedbackReply createReply(CourseFeedbackReply courseFeedbackReply, EntityManager em);

    boolean updateReply(CourseFeedbackReply reply, EntityManager em);

    boolean removeReply(long id, EntityManager em);


}
