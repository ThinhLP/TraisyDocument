package daos;

import com.google.inject.ImplementedBy;
import daos.impl.CourseSectionDaoImpl;
import models.Course;
import models.CourseLecture;
import models.CourseSection;

import javax.persistence.EntityManager;
import java.util.List;

@ImplementedBy(CourseSectionDaoImpl.class)
public interface CourseSectionDao {


    CourseSection findSection(long id, EntityManager em);

    Course findCourseBySectionId(long sectionId, EntityManager em);

    List<CourseSection> getAllSection(EntityManager em);

    List<CourseSection> getAllSectionByCourseId(long courseId, EntityManager em);

    CourseSection createSection(CourseSection section, EntityManager em);

    boolean updateSection(CourseSection sectionUpdate, EntityManager em);

    boolean removeSection(long id, EntityManager em);



}
