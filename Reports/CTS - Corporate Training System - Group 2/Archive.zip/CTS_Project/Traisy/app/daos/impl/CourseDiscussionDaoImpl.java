package daos.impl;

import daos.CourseDiscussionDao;
import models.CourseDiscussion;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;
import java.util.List;

public class CourseDiscussionDaoImpl implements CourseDiscussionDao {

    @Override
    public CourseDiscussion findDiscussionById(long id, EntityManager em) {
        return em.find(CourseDiscussion.class, id);
    }

    @Override
    public List<CourseDiscussion> getAllDiscussion(long courseLectureID, EntityManager em) {
        Query query = em.createQuery("SELECT c FROM CourseDiscussion c WHERE c.CourseLecture.id =:courseLectureId");
        query.setParameter("courseLectureId", courseLectureID);
        return query.getResultList();
    }

    @Override
    public CourseDiscussion createDiscussion(CourseDiscussion courseDiscussion, EntityManager em) {
        try {
            em.persist(courseDiscussion);
        } catch (EntityExistsException e) {
            System.out.println("CourseDiscussionDaoImpl_EntityExistsException: " + e.getMessage());
            return null;
        } catch (TransactionRequiredException e) {
            System.out.println("CourseDiscussionDaoImpl_TransactionRequiredException: " + e.getMessage());
            return null;
        }
        return courseDiscussion;
    }

    @Override
    public boolean updateDiscussion(CourseDiscussion courseDiscussion, EntityManager em) {
        CourseDiscussion updateDiscussion = findDiscussionById(courseDiscussion.id, em);
        if (updateDiscussion != null) {
            updateDiscussion.content = courseDiscussion.content;
            updateDiscussion.createdDate = courseDiscussion.createdDate;
            em.merge(updateDiscussion);
            return true;
        }
        return false;
    }

    @Override
    public boolean removeDiscussion(long id, EntityManager em) {
        CourseDiscussion removeDiscussion = findDiscussionById(id, em);
        if (removeDiscussion != null) {
            em.remove(removeDiscussion);
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteListDiscussion(List<CourseDiscussion> lectureDiscussions, EntityManager em) {
        if (lectureDiscussions!=null ){
            for (CourseDiscussion courseDiscussion: lectureDiscussions){
                em.remove(courseDiscussion);
            }
            return true;
        }
        return false;
    }
}
