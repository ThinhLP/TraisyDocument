package daos.impl;

import daos.LearnerQuizDetailDao;
import models.LearnerQuizDetail;
import services.LogService;

import javax.persistence.EntityManager;

public class LearnerQuizDetailDaoImpl implements LearnerQuizDetailDao {
    @Override
    public LearnerQuizDetail findLearnerQuizDetailById(Long id, EntityManager em) {
        return em.find(LearnerQuizDetail.class, id);
    }

    @Override
    public boolean create(LearnerQuizDetail detail, EntityManager em) {
        try {
            em.persist(detail);
            return true;
        } catch (Exception ex) {
            LogService.logger.error("Error create Learner Quiz Detail", ex);
            return false;
        }
    }

    @Override
    public boolean update(LearnerQuizDetail detail, EntityManager em) {
        try {
            em.merge(detail);
            return true;
        } catch (Exception ex) {
            LogService.logger.error("Error update Learner Quiz detail", ex);
            return false;
        }
    }

}
