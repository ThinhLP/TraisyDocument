package daos.impl;

import daos.LearnerQuizDao;
import models.LearnerQuiz;
import services.LogService;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

public class LearnerQuizDaoImpl implements LearnerQuizDao {
    @Override
    public LearnerQuiz findLearnerQuizById(Long id, EntityManager em) {
        return em.find(LearnerQuiz.class, id);
    }

    @Override
    public boolean create(LearnerQuiz learnerQuiz, EntityManager em) {
        try {
            em.persist(learnerQuiz);
            return true;
        } catch (Exception ex) {
            LogService.logger.error("Error create Learner Quiz", ex);
            return false;
        }
    }

    @Override
    public boolean update(LearnerQuiz learnerQuiz, EntityManager em) {
        try {
            em.merge(learnerQuiz);
            return true;
        } catch (Exception ex) {
            LogService.logger.error("Error update Learner Quiz", ex);
            return false;
        }
    }

    @Override
    public LearnerQuiz getLastLearnerQuiz(long userId, long quizId, EntityManager em) {
        Query query = em.createQuery("SELECT q FROM LearnerQuiz q WHERE q.User.id = :userId AND q.Quiz.id = :quizId ORDER BY q.date DESC")
                .setParameter("userId", userId)
                .setParameter("quizId", quizId)
                .setFirstResult(0)
                .setMaxResults(1);
        try {
            return (LearnerQuiz) query.getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }
}
