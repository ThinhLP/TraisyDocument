package daos.impl;

import commons.TSConst;
import daos.UserDao;
import fronts.UserData;
import models.Brand;
import models.Plan;
import models.User;
import play.i18n.Messages;
import services.LogService;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao {

    @Override
    public User findUserById(long id, EntityManager em) {
        return em.find(User.class, id);
    }

    @Override
    public User findUserByUsername(String username, EntityManager em) {
        try {
            User user = (User) em.createQuery("SELECT u from User u where u.username= :username")
                    .setParameter("username", username).getSingleResult();
            return user;
        } catch (Exception ex) {
            return null;
        }
    }

    @Override
    public User getUserByUsernameAndStatus(String username, int status, EntityManager em) {
        User user = null;
        List list = em.createQuery("SELECT u from User u where u.username= :username and u.status = :status")
                .setParameter("username", username)
                .setParameter("status", status).getResultList();
        if (!list.isEmpty()) user = (User) list.get(0);
        return user;
    }

    @Override
    public List<User> getAllUserByBrandId(int id, EntityManager em) {
        Query query = em.createQuery("SELECT u FROM User u WHERE u.Brand.id = :id").setParameter("id", id);
        return query.getResultList();
    }

    @Override
    public User createUser(User addUser, EntityManager em) {
        try {
            em.persist(addUser);
        } catch (EntityExistsException e) {
            String err = String.format("Entity exist -- user dao : %s",
                    e.getMessage());
            LogService.logger.error(err);
            return null;
        } catch (IllegalArgumentException e) {
            String err = String.format("Instance is not an entity-- user dao : %s",
                    e.getMessage());
            LogService.logger.error(err);
            return null;
        } catch (TransactionRequiredException e) {
            String err = String.format("Transaction or EntityManager has problem -- user dao : %s",
                    e.getMessage());
            LogService.logger.error(err);
            return null;
        }
        return addUser;
    }

    @Override
    public List<UserData> convertToUserData(List<User> userList) {
        List<UserData> result = new ArrayList<>();
        for (User user: userList) {
            UserData userData = new UserData();
            userData.id = user.id;
            userData.username = user.username;
            userData.fullname = user.fullname;
            userData.title = user.title;
            userData.brandName = user.Brand.name;
            userData.roleId = user.Role.id;
            result.add(userData);
        }
        return result;
    }

    @Override
    public boolean removeAllUserByBrandId(int id, EntityManager em) {
        List<User> listUserByBrand = getAllUserByBrandId(id, em);

        for (User userTemp :
                listUserByBrand) {
            userTemp.Brand = null;
            userTemp.status = 0;
            em.merge(userTemp);
        }
        return true;
    }

    public List<User> getAvailableAuthors(Plan plan, Brand brand, int pageNo, int size, EntityManager em) {
        Query query = em.createQuery("SELECT u FROM User u WHERE u.Brand.id = :brandId AND u.Role.id = :roleAuthor AND " +
                "u.id NOT IN (SELECT p.User.id FROM PlanParticipant p WHERE p.Plan.id = :planId)")
                .setParameter("brandId", brand.id)
                .setParameter("roleAuthor", TSConst.USER_ROLE.AUTHOR.value)
                .setParameter("planId", plan.id)
                .setMaxResults(size)
                .setFirstResult(size * (pageNo - 1));
        return query.getResultList();
    }

    @Override
    public List<User> getPlanAvailableUsers(Plan plan, Brand brand, int role, int pageNo, int size, EntityManager em) {
        Query query = em.createQuery("SELECT u FROM User u WHERE u.Brand.id = :brandId AND u.Role.id = :role AND " +
                "u.id NOT IN (SELECT p.User.id FROM PlanParticipant p WHERE p.Plan.id = :planId)")
                .setParameter("brandId", brand.id)
                .setParameter("role", role)
                .setParameter("planId", plan.id)
                .setMaxResults(size)
                .setFirstResult(size * (pageNo - 1));
        return query.getResultList();

    }
}
