package daos.impl;

import daos.PlanDao;
import models.Plan;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;
import java.sql.Timestamp;
import java.util.List;

public class PlanDaoImpl implements PlanDao {

    /**
     * Find plan by id , using entity
     *
     * @param id id to find
     * @param em entity
     * @return
     */
    @Override
    public Plan findPlanById(long id, EntityManager em) {
        return em.find(Plan.class, id);
    }

    @Override
    public List<Plan> getAllPlans(int brandId, EntityManager em) {
        Query query = em.createQuery("SELECT p FROM Plan p WHERE p.User.Brand.id = :brandId and p.status = 1")
                .setParameter("brandId", brandId);
        return query.getResultList();
    }

    @Override
    public List<Plan> getPlans(int brandId, int pageNo, int size, EntityManager em) {
        Query query = em.createQuery("SELECT p FROM Plan p WHERE p.User.Brand.id = :brandId and p.status = 1 ORDER BY p.startDate desc")
                .setParameter("brandId", brandId)
                .setMaxResults(size)
                .setFirstResult(size * (pageNo - 1));
        return query.getResultList();
    }

    /**
     * Get all plan according to user_id
     *
     * @param userId
     * @param em
     * @return
     */
    @Override
    public List<Plan> getAllPlanByUserId(long userId, EntityManager em) {
        Query query = em.createQuery("SELECT p FROM  Plan p WHERE p.User.id = :userId and p.status = 1");
        query.setParameter("userId", userId);
        return query.getResultList();
    }

    @Override
    public List<Plan> getAllPlanByTitle(String title, EntityManager em) {
        Query query = em.createQuery("SELECT p FROM  Plan p WHERE p.title = :title");
        query.setParameter("title", title);
        return query.getResultList();
    }

    @Override
    public Plan createPlan(Plan plan, EntityManager em) {
        try {
            em.persist(plan);
        } catch (EntityExistsException e) {
            System.out.println("PlanDaoImpl_EntityExistsException: " + e.getMessage());
            return null;
        } catch (TransactionRequiredException e) {
            System.out.println("PlanDaoImpl_TransactionRequiredException: " + e.getMessage());
            return null;
        }
        return plan;
    }

    @Override
    public boolean updatePlan(Plan plan, EntityManager em) {
        try {
            em.merge(plan);
            return true;
        } catch(Exception ex) {
            return false;
        }
    }

    @Override
    public boolean removePlan(long id, EntityManager em) {
        Plan removePlan = findPlanById(id, em);
        if (removePlan != null) {
            em.remove(removePlan);
            return true;
        }
        return false;
    }

    @Override
    public Plan findPlanByTitleUrl(String titleUrl, EntityManager em) {
        Plan plan = null;
        Query query = em.createQuery("SELECT p FROM Plan p WHERE p.titleUrl = :titleUrl");
        query.setParameter("titleUrl", titleUrl);
        List list = query.getResultList();
        if (!list.isEmpty()) plan = (Plan) list.get(0);
        return plan;
    }

    @Override
    public boolean updatePlanInfo(Plan plan, String newTitle, String newDescription, Timestamp startDate, Timestamp endDate, EntityManager em) {
        plan.description = newDescription;
        plan.title = newTitle;
        plan.startDate = startDate;
        plan.endDate = endDate;
        try {
            em.merge(plan);
            return true;
        } catch(Exception ex) {
            return false;
        }


    }
}
