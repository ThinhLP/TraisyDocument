package daos.impl;

import commons.TSConst;
import daos.BrandDao;
import models.Brand;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

public class BrandDaoImpl implements BrandDao {
    @Override
    public Brand findBrandById(int id, EntityManager em) {
        Brand brand = em.find(Brand.class, id);
        return brand;
    }

    @Override
    public List<Brand> getAllBrand(EntityManager em) {
        Query query = em.createQuery("SELECT b FROM Brand b where b.status = 1");
        return query.getResultList();
    }

    @Override
    public Brand createSimpleBrand(String name, EntityManager em) {
        return null;
    }

    @Override
    public Brand createBrand(Brand brand, EntityManager em) {
        try {
            em.persist(brand);
            return brand;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean updateBrand(Brand brand, EntityManager em) {
        try {
            em.merge(brand);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean removeBrand(int id, EntityManager em) {
        Brand removeBrand = findBrandById(id, em);
        if (removeBrand != null) {
            removeBrand.status = TSConst.COMMON_STATUS.DELETED;
            em.merge(removeBrand);
            return true;
        } else {
            return false;
        }
    }
}
