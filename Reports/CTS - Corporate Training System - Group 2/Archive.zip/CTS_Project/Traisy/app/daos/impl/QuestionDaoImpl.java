package daos.impl;

import daos.QuestionDao;
import daos.SkillDao;
import models.Question;
import models.Skill;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

public class QuestionDaoImpl implements QuestionDao {

    @Override
    public Question findQuestionById(long id, EntityManager em) {
        try{
            Question result = em.find(Question.class, id);
            return result;
        } catch (Exception e){
            return null;
        }
    }

    @Override
    public List<Question> getAllQuestions(EntityManager em) {
        Query query = em.createQuery("SELECT q FROM Question q");
        List<Question> result = query.getResultList();
        return result;
    }

    @Override
    public List<Question> getAllQuestionsByQuizId(long id, EntityManager em) {
        Query query = em.createQuery("SELECT q FROM Question q WHERE q.Quiz.id =: quizId");
        query.setParameter("quizId", id);
        List<Question> result = query.getResultList();
        return result;
    }

    @Override
    public Question createQuestion(Question question, EntityManager em) {
        try {
            em.persist(question);
            return question;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean updateQuestion(Question question, EntityManager em) {
        try {
            em.merge(question);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean removeQuestion(long id, EntityManager em) {
        Question question = findQuestionById(id, em);
        if (question != null) {
            em.remove(question);
            return true;
        } else {
            return false;
        }
    }
}
