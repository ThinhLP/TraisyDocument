package daos.impl;

import daos.BrandDao;
import daos.SkillDao;
import models.Brand;
import models.Skill;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

public class SkillDaoImpl implements SkillDao {

    @Override
    public Skill findSkillById(int id, EntityManager em) {
        return em.find(Skill.class, id);
    }

    @Override
    public List<Skill> getAllSkill(EntityManager em) {
        Query query = em.createQuery("SELECT s FROM Skill s");
        return query.getResultList();
    }

    @Override
    public Skill createSkill(Skill skill, EntityManager em) {
        try {
            em.persist(skill);
            return skill;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean updateSkill(Skill skill, EntityManager em) {
        try {
            em.merge(skill);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean removeSkill(int id, EntityManager em) {
        Skill removeSkill = findSkillById(id, em);
        if (removeSkill != null) {
            em.remove(removeSkill);
            return true;
        } else {
            return false;
        }
    }
}
