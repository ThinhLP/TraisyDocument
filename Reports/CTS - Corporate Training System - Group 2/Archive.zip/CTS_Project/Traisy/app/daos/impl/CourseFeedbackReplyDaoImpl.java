package daos.impl;

import daos.CourseFeedbackDao;
import daos.CourseFeedbackReplyDao;
import models.CourseFeedback;
import models.CourseFeedbackReply;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

public class CourseFeedbackReplyDaoImpl implements CourseFeedbackReplyDao {


    @Override
    public CourseFeedbackReply findFeedbackReplyById(long id, EntityManager em) {
        return em.find(CourseFeedbackReply.class, id);
    }

    @Override
    public List<CourseFeedbackReply> getAllReplyByFeedback(long feedbackId, EntityManager em) {
        Query query = em.createQuery("SELECT r FROM CourseFeedbackReply r WHERE r.CourseFeedback.id =:feedbackId");
        query.setParameter("feedbackId", feedbackId);
        return query.getResultList();
    }

    @Override
    public List<CourseFeedbackReply> getAllReplyByCourseId(long courseId, EntityManager em) {
        Query query = em.createQuery("SELECT r FROM CourseFeedbackReply r WHERE r.CourseFeedback.Course.id =:courseId");
        query.setParameter("courseId", courseId);
        return query.getResultList();
    }

    @Override
    public CourseFeedbackReply createReply(CourseFeedbackReply courseFeedbackReply, EntityManager em) {
        try {
            em.persist(courseFeedbackReply);
            return courseFeedbackReply;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean updateReply(CourseFeedbackReply reply, EntityManager em) {
        try {
            em.merge(reply);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean removeReply(long id, EntityManager em) {
        try {
            CourseFeedbackReply removeReply = findFeedbackReplyById(id, em);
            em.remove(removeReply);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
