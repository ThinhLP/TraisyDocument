package daos.impl;

import commons.TSConst;
import daos.CourseFeedbackDao;
import models.CourseDiscussion;
import models.CourseFeedback;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;
import java.util.List;

public class CourseFeedbackDaoImpl implements CourseFeedbackDao {

    @Override
    public CourseFeedback findFeedbackById(long id, EntityManager em) {
        return em.find(CourseFeedback.class, id);
    }

    @Override
    public List<CourseFeedback> getAllFeedbackByCourse(long courseId, EntityManager em) {
        Query query = em.createQuery("SELECT f FROM CourseFeedback f WHERE f.Course.id =:courseId");
        query.setParameter("courseId", courseId);
        return query.getResultList();
    }

    @Override
    public CourseFeedback createFeedback(CourseFeedback courseFeedback, EntityManager em) {
        try {
            em.persist(courseFeedback);
            return courseFeedback;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean updateFeedback(CourseFeedback courseFeedback, EntityManager em) {
        if (courseFeedback != null) {
            em.merge(courseFeedback);
            return true;
        }
        return false;
    }

    @Override
    public boolean removeFeedback(long id, EntityManager em) {
        CourseFeedback removeFeedback = findFeedbackById(id, em);
        if (removeFeedback != null) {
            em.remove(removeFeedback);
            return true;
        }
        return false;
    }

    @Override
    public boolean removeListFeedback(List<CourseFeedback> feedbackReplies, EntityManager em) {
        if (feedbackReplies!=null ){
            for (CourseFeedback courseDiscussion: feedbackReplies){
                em.remove(courseDiscussion);
            }
            return true;
        }
        return false;
    }
}
