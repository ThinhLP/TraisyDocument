package daos.impl;

import daos.CourseDao;
import models.Course;
import models.Plan;
import models.User;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class CourseDaoImpl implements CourseDao {

    @Override
    public Course findCourseById(long id, EntityManager em) {
        Course course = em.find(Course.class, id);
        return course;
    }

    @Override
    public List<Course> getAllCourse(EntityManager em) {
        List<Course> listAllCourse;
        Query query = em.createQuery("SELECT c FROM Course c WHERE c.status <> -1");
        listAllCourse = query.getResultList();
        return listAllCourse;
    }

    @Override
    public List<Course> getAllCourseByPlanId(long planId, EntityManager em) {
        List<Course> listCourseByPlanId;
        Query query = em.createQuery("SELECT c FROM Course c WHERE c.Plan.id = :planId AND c.status <> -1");
        query.setParameter("planId", planId);
        listCourseByPlanId = query.getResultList();
        return listCourseByPlanId;
    }

    @Override
    public List<Course> getAllCourseByUserId(long userId, EntityManager em) {
        List<Course> listCourseByUserId;
        Query query = em.createQuery("SELECT c FROM Course c WHERE c.User.id = :userId AND c.status <> -1");
        query.setParameter("userId", userId);
        listCourseByUserId = query.getResultList();
        return listCourseByUserId;
    }

    @Override
    public List<Course> getAllCourseByUserIdAndPlanId(long planId, long userId, EntityManager em) {
        Query query = em.createQuery("SELECT c FROM Course c WHERE c.User.id = :userId AND c.Plan.id = :planId AND c.status <> -1");
        query.setParameter("userId", userId)
                .setParameter("planId", planId);
        return query.getResultList();
    }

    @Override
    public List<Course> getAllCourseByUserIdAndProgramId(long programId, long userId, EntityManager em) {
        Query query;
        if (programId > 0) {
            query = em.createQuery("SELECT c FROM Course c WHERE c.User.id = :userId AND c.Program.id = :programId AND c.status <> -1")
                    .setParameter("userId", userId)
                    .setParameter("programId", programId);
        } else {
            query = em.createQuery("SELECT c FROM Course c WHERE c.User.id = :userId AND c.Program = NULL AND c.status <> -1")
                    .setParameter("userId", userId);
        }

        return query.getResultList();
    }


    @Override
    public List<Course> getAllCourseByProgramId(long programId, EntityManager em) {
        List<Course> listCourseByProgramId;
        Query query = em.createQuery("SELECT c FROM Course c WHERE c.Program.id = :programId AND c.status <> -1");
        query.setParameter("programId", programId);
        listCourseByProgramId = query.getResultList();
        return listCourseByProgramId;
    }

    @Override
    public Course findCourseByTitleUrl(String titleUrl, EntityManager em) {
        Course course = null;
        Query query = em.createQuery("SELECT c FROM Course c WHERE c.titleUrl = :titleUrl");
        query.setParameter("titleUrl", titleUrl);
        List list = query.getResultList();
        if (!list.isEmpty()) course = (Course) list.get(0);
        return course;
    }

    @Override
    public boolean createCourse(Course course, EntityManager em) {
        try {
            em.persist(course);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public boolean updateCourse(Course course, EntityManager em) {
        try {
            course.updatedDate = new Timestamp(new Date().getTime());
            em.merge(course);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public void updateCourseImage(Course course, byte[] image, EntityManager em) {
        course.introImage = image;
        em.merge(course);
    }

    @Override
    public void updateCourseUploadDate(Course course, Timestamp time, EntityManager em) {
        course.updatedDate = time;
        em.merge(course);
    }

    @Override
    public Timestamp getLastUpdateCourse(long planId, long userId, EntityManager em) {
        Query query = em.createQuery("SELECT MAX(c.updatedDate) FROM Course c where c.Plan.id = :planId AND c.User.id = :userId AND c.status <> -1")
                .setParameter("userId", userId)
                .setParameter("planId", planId);
        try {
            return (Timestamp) query.getSingleResult();
        } catch (Exception ex) {
            return new Timestamp(0);

        }
    }

    @Override
    public List<Course> getReviewingCourses(int brandId, EntityManager em) {
        Query query = em.createQuery("SELECT c FROM Course c where c.Plan.User.Brand.id = :brandId AND c.status = 2")
                .setParameter("brandId", brandId);
        return query.getResultList();
    }

    @Override
    public int getNoOfReviewingCourses(int brandId, EntityManager em) {
        Query query = em.createQuery("SELECT COUNT(c) FROM Course c where c.Plan.User.Brand.id = :brandId AND c.status = 2")
                .setParameter("brandId", brandId);
        try {
            return ((Long) query.getSingleResult()).intValue();
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }

    }
}
