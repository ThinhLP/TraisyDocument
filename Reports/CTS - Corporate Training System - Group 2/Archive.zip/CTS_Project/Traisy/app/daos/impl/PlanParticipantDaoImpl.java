package daos.impl;

import daos.PlanParticipantDao;
import fronts.UserData;
import fronts.UserPlanData;
import models.Brand;
import models.Plan;
import models.PlanParticipant;
import models.User;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PlanParticipantDaoImpl implements PlanParticipantDao {

    @Override
    public boolean isParticipated(long planId, long userId, EntityManager em) {
        Query query = em.createNativeQuery("SELECT id FROM plan_participant WHERE user_id = :userId AND plan_id = :planId")
                .setParameter("userId", userId)
                .setParameter("planId", planId);
        List result = query.getResultList();
        return !result.isEmpty();
    }

    @Override
    public PlanParticipant findPlanParticipant(long planId, long userId, EntityManager em) {
        Query query = em.createQuery("SELECT p FROM PlanParticipant p WHERE p.Plan.id = :plandId AND p.User.id = :userId")
                .setParameter("plandId", planId)
                .setParameter("userId", userId);
        try {
            return (PlanParticipant) query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean addUserToPlan(Plan plan, User user, EntityManager em) {
        PlanParticipant planParticipant = new PlanParticipant();
        planParticipant.participateDate = new Timestamp(new Date().getTime());
        planParticipant.Plan = plan;
        planParticipant.User = user;
        try {
            em.persist(planParticipant);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public List<User> getUserParticipants(Plan plan, int role, int pageNo, int size, EntityManager em) {
        Query query = em.createQuery("SELECT p.User FROM PlanParticipant p WHERE p.Plan.id = :planId AND p.User.Role.id = :role")
                .setParameter("planId", plan.id)
                .setParameter("role", role)
                .setFirstResult((pageNo - 1) * size)
                .setMaxResults(size);
        List<User> result = query.getResultList();
        return result;
    }


    @Override
    public List<User> getAllUserParticipants(Plan plan, int role, EntityManager em) {
        Query query = em.createQuery("SELECT p.User FROM PlanParticipant p WHERE p.Plan.id = :planId AND p.User.Role.id = :role")
                .setParameter("planId", plan.id)
                .setParameter("role", role);
        List<User> result = query.getResultList();
        return result;
    }

    @Override
    public List<Object[]> getUserParticipantsWithDate(Plan plan, int role, int pageNo, int size, EntityManager em) {
        Query query = em.createQuery("SELECT p.User, p.participateDate, p.Plan FROM PlanParticipant p WHERE p.Plan.id = :planId AND p.User.Role.id = :role")
                .setParameter("planId", plan.id)
                .setParameter("role", role)
                .setFirstResult((pageNo - 1) * size)
                .setMaxResults(size);

        return query.getResultList();
    }

    @Override
    public List<Object[]> searchUserParticipants(Plan plan, int role, String name, int pageNo, int size, EntityManager em) {
        Query query = em.createQuery("SELECT p.User, p.participateDate, p.Plan FROM PlanParticipant p WHERE p.Plan.id = :planId AND p.User.Role.id = :role AND p.User.fullname LIKE :fullname")
                .setParameter("planId", plan.id)
                .setParameter("role", role)
                .setParameter("fullname", "%" + name + "%")
                .setFirstResult((pageNo - 1) * size)
                .setMaxResults(size);

        return query.getResultList();
    }

    @Override
    public List<Object[]> getAllUserParticipantsWithDate(Plan plan, int role, EntityManager em) {
        Query query = em.createQuery("SELECT p.User, p.participateDate, p.Plan FROM PlanParticipant p WHERE p.Plan.id = :planId AND p.User.Role.id = :role")
                .setParameter("planId", plan.id)
                .setParameter("role", role);

        return query.getResultList();
    }

    @Override
    public List<Plan> getAllPlansOfUser(long userId, EntityManager em) {
        Query query = em.createQuery("SELECT p.Plan FROM PlanParticipant p WHERE p.User.id = :userId ")
                .setParameter("userId", userId);
        List<Plan> result = query.getResultList();
        return result;
    }

    @Override
    public boolean removeUserFromPlan(long planId, long userId, EntityManager em) {
        try {
            PlanParticipant planParticipant = findPlanParticipant(planId, userId, em);
            if (planParticipant != null) {
                em.remove(planParticipant);
                return true;
            }
            return false;
        } catch (Exception ex) {
            return false;
        }
    }
}
