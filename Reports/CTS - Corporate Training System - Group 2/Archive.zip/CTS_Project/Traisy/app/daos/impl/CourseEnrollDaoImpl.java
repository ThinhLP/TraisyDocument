package daos.impl;

import daos.CourseEnrollDao;
import models.CourseEnroll;
import models.User;
import services.LogService;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class CourseEnrollDaoImpl implements CourseEnrollDao{

    @Override
    public List<User> findUsersEnrollInCourse(long courseId, EntityManager em) {
        Query query = em.createQuery("SELECT e FROM CourseEnroll e WHERE e.Course.id = :courseId ");
        try {
            query.setParameter("courseId", courseId);
            List<CourseEnroll> enrollList = query.getResultList();
            List<User> result = new ArrayList<>();
            if (enrollList != null && !enrollList.isEmpty()){
                for (CourseEnroll e :
                        enrollList) {
                    result.add(e.User);
                }
            }
            return result;
        } catch (Exception e){
            return null;
        }
    }

    @Override
    public CourseEnroll getUserCourseEnroll(long courseId, long userId, EntityManager em) {
        Query query = em.createQuery("SELECT e FROM CourseEnroll e WHERE e.Course.id = :courseId  and e.User.id = :userId")
                .setParameter("courseId", courseId)
                .setParameter("userId", userId);
        List list = query.getResultList();

        return list.isEmpty() ? null : (CourseEnroll) list.get(0);
    }

    @Override
    public boolean create(CourseEnroll enroll, EntityManager em) {
        try {
            em.persist(enroll);
            return true;
        } catch (Exception ex) {
            LogService.logger.error("Cannot create enroll", ex);
            return false;
        }
    }
}
