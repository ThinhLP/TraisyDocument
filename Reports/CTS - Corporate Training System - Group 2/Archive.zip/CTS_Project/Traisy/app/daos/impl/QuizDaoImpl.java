package daos.impl;

import daos.QuizDao;
import models.CourseLecture;
import models.Quiz;
import play.db.jpa.JPA;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

public class QuizDaoImpl implements QuizDao {

    @Override
    public Quiz findQuizById(Long id, EntityManager em){
        return em.find(Quiz.class, id);
    }

    @Override
    public Quiz updateQuiz(Quiz quiz, EntityManager em){
        return em.merge(quiz);
    }

    @Override
    public int getNewQuestionOrder(long quizId, EntityManager em) {
        String jpql = "SELECT q FROM Question q WHERE q.Quiz.id = :id";

        Query query = em.createQuery(jpql).setParameter("id", quizId);

        List rs = query.getResultList();

        if (rs == null) {
            return -1;
        }

        return rs.size() + 1;
    }
}
