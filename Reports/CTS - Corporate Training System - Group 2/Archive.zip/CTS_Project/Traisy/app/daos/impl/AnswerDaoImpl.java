package daos.impl;

import daos.AnswerDao;
import daos.BrandDao;
import models.Answer;
import models.Brand;
import services.LogService;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

public class AnswerDaoImpl implements AnswerDao {

    @Override
    public Answer findAnswerById(long id, EntityManager em) {
        return em.find(Answer.class, id);
    }

    @Override
    public List<Answer> getAllAnswerByQuestionId(long questionId, EntityManager em) {
        Query query = em.createQuery("SELECT q FROM Question q");
        List<Answer> result = query.getResultList();
        return result;
    }

    @Override
    public Answer createAnswer(Answer answer, EntityManager em) {
        try {
            em.persist(answer);
            return answer;
        } catch (Exception e){
            LogService.logger.error("Error: ", e);
            return null;
        }
    }

    @Override
    public boolean removeAnswer(long id, EntityManager em) {
        Answer answerDelete = em.find(Answer.class, id);
        if (answerDelete != null){
            em.remove(answerDelete);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean updateAnswer(Answer answer, EntityManager em) {
        try {
            em.merge(answer);
            return true;
        } catch (Exception e){
            LogService.logger.error("Error: ", e);
            return false;
        }
    }


}
