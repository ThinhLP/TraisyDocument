package daos.impl;

import commons.TSConst;
import daos.LearnerProcessDao;
import daos.RoleDao;
import models.Course;
import models.CourseLecture;
import models.LearnerProcess;
import models.Role;
import play.db.jpa.JPA;
import services.LogService;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.List;

public class LearnerProcessDaoImpl implements LearnerProcessDao{

    @Override
    public LearnerProcess findLearnerProcess(long id, EntityManager em) {
        return em.find(LearnerProcess.class, id);
    }

    @Override
    public List<LearnerProcess> getFinishProcessOfUserAndCourse(long userId, long courseId, int status, EntityManager em) {
        Query query = em.createQuery("SELECT p FROM LearnerProcess p WHERE p.User.id = :userId " +
                "AND p.Course.id = :courseId  AND p.status = :status");
        query.setParameter("userId", userId);
        query.setParameter("courseId", courseId);
        query.setParameter("status", status);
        List<LearnerProcess> result = query.getResultList();
        return result;
    }

    @Override
    public List<LearnerProcess> getAllProcessOfOfLecture(long lectureId, EntityManager em) {
        Query query = em.createQuery("SELECT p FROM  LearnerProcess p WHERE p.CourseLecture.id = :lectureId");
        query.setParameter("lectureId", lectureId);
        List<LearnerProcess> result = query.getResultList();
        return result;
    }

    @Override
    public boolean deleteProcess(long id, EntityManager em) {
        LearnerProcess process = em.find(LearnerProcess.class, id);
        if (process!= null){
            em.remove(process);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean deleteListProcess(List<LearnerProcess> learnerProcesses, EntityManager em) {
        if (learnerProcesses!=null ){
            for (LearnerProcess learnerProcess: learnerProcesses){
                em.remove(learnerProcess);
            }
            return true;
        }
        return false;
    }

    @Override
    public LearnerProcess getLearnerProcessInLecture(long userId, long courseId, long lectureId, EntityManager em) {
        List<LearnerProcess> list = em.createQuery("SELECT lp from LearnerProcess lp where lp.Course.id = :courseId and lp.CourseLecture.id = :lectureId and lp.User.id = :userId")
                .setParameter("courseId", courseId)
                .setParameter("lectureId", lectureId)
                .setParameter("userId", userId)
                .getResultList();
        return list.isEmpty() ? null : list.get(0);
    }

    @Override
    public boolean create(LearnerProcess process, EntityManager em) {
        try {
            em.persist(process);
            return true;
        } catch (Exception ex) {
            LogService.logger.error("Create learner process error: ", ex);
            return false;
        }
    }

    @Override
    public boolean update(LearnerProcess process, EntityManager em) {
        try {
            em.merge(process);
            return true;
        } catch (Exception ex) {
            LogService.logger.error("Update learner process error: ", ex);
            return false;
        }
    }

    @Override
    public CourseLecture getLastLearningLecture(long userId, long courseId, EntityManager em) {
        List list = JPA.em().createQuery("SELECT lp.CourseLecture from LearnerProcess lp " +
                "where lp.Course.id = :courseId " +
                "And lp.User.id = :userId " +
                "And lp.lastLearningDate = (SELECT max(lp2.lastLearningDate) from LearnerProcess lp2 " +
                "where lp2.Course.id = :courseId And lp2.User.id = :userId)")
                .setParameter("courseId", courseId)
                .setParameter("userId", userId)
                .getResultList();

        return list.isEmpty() ? null : (CourseLecture) list.get(0);
    }

    @Override
    public List<LearnerProcess> getCompleteLearnerProcessOfUser(long userId, long courseId, EntityManager em) {
        Query query = em.createQuery("SELECT p FROM LearnerProcess p WHERE p.status = 1 AND p.User.id = :userId AND p.Course.id = :courseId")
                .setParameter("userId", userId)
                .setParameter("courseId", courseId);

        return query.getResultList();
    }

    @Override
    public LearnerProcess getLearnerProcessByStatus(long courseId, long lectureId, long userId, int status, EntityManager em) {
        List<LearnerProcess> list = em.createQuery("SELECT lp from LearnerProcess lp " +
                "where lp.Course.id = :courseId And lp.CourseLecture.id = :lectureId And " +
                "lp.User.id = :userId And lp.status = :status")
                .setParameter("courseId", courseId)
                .setParameter("lectureId", lectureId)
                .setParameter("userId", userId)
                .setParameter("status", status)
                .getResultList();
        return !list.isEmpty() ? list.get(0) : null;

    }

    @Override
    public Timestamp getLastLearningDate(long userId, EntityManager em) {
        Query query = em.createQuery("SELECT lp.lastLearningDate FROM LearnerProcess lp WHERE lp.User.id = :userId ORDER BY lp.lastLearningDate DESC")
                .setParameter("userId", userId)
                .setFirstResult(0)
                .setMaxResults(1);
        try {
            return (Timestamp) query.getSingleResult();
        } catch (Exception ex) {
            return null;
        }
    }

    @Override
    public boolean updateLearningProcess(long courseId, long lectureId, long userId, EntityManager em) {
        LearnerProcess process = getLearnerProcessByStatus(courseId, lectureId, userId, TSConst.LECTURE_CONFIG.LEARNING_STATUS.NOT_COMPLETED.value, em);
        if (process != null) {
            process.status = TSConst.LECTURE_CONFIG.LEARNING_STATUS.COMPLETED.value;
            em.merge(process);
            return true;
        }
        return true;
    }

}
