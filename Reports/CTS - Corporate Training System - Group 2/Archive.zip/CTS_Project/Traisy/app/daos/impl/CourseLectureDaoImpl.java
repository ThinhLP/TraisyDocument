package daos.impl;

import commons.TSConst;
import daos.CourseLectureDao;
import models.Course;
import models.CourseLecture;
import org.apache.commons.io.FileUtils;
import services.LogService;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.io.File;
import java.math.BigInteger;
import java.util.List;

public class CourseLectureDaoImpl implements CourseLectureDao {

    @Override
    public CourseLecture findLectureById(long lectureId, EntityManager em) {
        return em.find(CourseLecture.class, lectureId);
    }

    @Override
    public CourseLecture findLectureByTitleUrl(String titleUrl, EntityManager em) {
        CourseLecture courseLecture = null;
        Query query = em.createQuery("SELECT l FROM CourseLecture l WHERE l.titleUrl = :titleUrl");
        query.setParameter("titleUrl", titleUrl);
        List list = query.getResultList();
        if (!list.isEmpty()) courseLecture = (CourseLecture) list.get(0);
        return courseLecture;
    }

    @Override
    public List<CourseLecture> getAllLecturesInSection(long sectionId, EntityManager em) {
        Query query = em.createQuery("SELECT l FROM CourseLecture l WHERE l.CourseSection.id = :sectionId");
        query.setParameter("sectionId", sectionId);
        return query.getResultList();
    }

    @Override
    public List<CourseLecture> getAllPublishLectureInCourse(long courseId, EntityManager em) {
        Query query = em.createQuery("SELECT l FROM CourseLecture l WHERE l.Course.id = :courseId AND l.status = :status");
        query.setParameter("status", 1);
        query.setParameter("courseId", courseId);
        return query.getResultList();
    }

    @Override
    public List<CourseLecture> getAllPublishLectureInSection(long sectionId, EntityManager em) {
        Query query = em.createQuery("SELECT l FROM CourseLecture l WHERE l.CourseSection.id = :sectionId AND l.status = :status");
        query.setParameter("status", 1);
        query.setParameter("sectionId", sectionId);
        return query.getResultList();
    }

    @Override
    public int getMaxLectureOrderInSection(long sectionId, EntityManager em) {
        Query query = em.createNativeQuery("SELECT MAX(`order`) FROM course_lecture where course_section_id = :secId")
                .setParameter("secId", sectionId);
        Object obj = query.getSingleResult();
        if (obj == null) {
            return 0;
        }
        return (Integer) obj;
    }

    public CourseLecture createLecture(CourseLecture lecture, EntityManager em) {
        try {
            em.persist(lecture);
            return lecture;
        } catch (Exception ex) {
            LogService.logger.error("Cannot create lecture");
            return null;
        }
    }

    @Override
    public CourseLecture updateLecture(CourseLecture lecture, EntityManager em) {
        try {
            return em.merge(lecture);
        } catch (Exception ex) {
            LogService.logger.error("Cannot update lecture");
            return null;
        }
    }

    @Override
    public boolean removeLecture(CourseLecture lecture, EntityManager em) {
        try {
            if (lecture.lectureFile != null){
                File f = new File(lecture.lectureFile);
                if (f != null){
                    FileUtils.deleteDirectory(f);
                }
            }
            em.remove(lecture);
            return true;
        } catch (Exception e){
            return false;
        }
    }

    @Override
    public boolean isCourseOwner(long lectureId, long userId, EntityManager em) {
        String jpql = "SELECT l FROM CourseLecture l WHERE l.id = :id AND l.Course.User.id = :userId";
        Query query = em.createQuery(jpql).setParameter("id", lectureId).setParameter("userId", userId);
        List<CourseLecture> courseLectures = query.getResultList();
        return !courseLectures.isEmpty();
    }

    @Override
    public CourseLecture findLectureByQuizId(long quizId, EntityManager em) {
        Query query = em.createQuery("SELECT l.Quiz FROM CourseLecture l where l.Quiz.id = :quizId")
                .setParameter("quizId", quizId);
        List list = query.getResultList();
        return list.isEmpty() ? null : (CourseLecture) list.get(0);
    }

    @Override
    public CourseLecture getFirstPublicLecture(long courseId, EntityManager em) {
        Query query = em.createQuery("SELECT l FROM CourseLecture l WHERE l.Course.id = :courseId AND l.status = 1 ORDER BY l.order ASC")
                .setParameter("courseId", courseId)
                .setFirstResult(0)
                .setMaxResults(1);
        List list = query.getResultList();
        return list.isEmpty() ? null : (CourseLecture) list.get(0);
    }

    @Override
    public CourseLecture getPreviousLecture(Course course, CourseLecture currentLecture,EntityManager em) {
        List list = em.createQuery("SELECT l FROM CourseLecture l " +
                "WHERE l.Course.id = :courseId " +
                "AND l.status = :lectureStatus " +
                "ORDER BY l.CourseSection.order, l.order ASC")
                .setParameter("courseId", course.id)
                .setParameter("lectureStatus", TSConst.COURSE_CONFIG.STATUS.PUBLIC)
                .getResultList();

        int index = list.indexOf(currentLecture);
        int prevIndex = index > 0 ? index - 1 : 0;
        return (CourseLecture) list.get(prevIndex);
    }

    @Override
    public CourseLecture getNextLecture(Course course, CourseLecture currentLecture, EntityManager em) {
        List list = em.createQuery("SELECT l FROM CourseLecture l " +
                "WHERE l.Course.id = :courseId " +
                "AND l.status = :lectureStatus " +
                "ORDER BY l.CourseSection.order, l.order ASC")
                .setParameter("courseId", course.id)
                .setParameter("lectureStatus", TSConst.COURSE_CONFIG.STATUS.PUBLIC)
                .getResultList();

        int index = list.indexOf(currentLecture);
        int nextIndex = index < list.size() -1 ? index + 1 : index;
        return (CourseLecture) list.get(nextIndex);
    }

}
