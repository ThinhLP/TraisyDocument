package daos.impl;

import daos.RoleDao;
import models.Role;

import javax.persistence.EntityManager;

public class RoleDaoImpl implements RoleDao{

    @Override
    public Role findRoleById(int id, EntityManager em){
        Role role = em.find(Role.class, id);
        return role;
    }
}
