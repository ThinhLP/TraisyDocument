package daos.impl;


import daos.CourseSectionDao;
import models.Course;
import models.CourseLecture;
import models.CourseSection;
import services.LogService;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;
import java.util.List;

public class CourseSectionDaoImpl implements CourseSectionDao {


    /**
     * find a specific section
     * @param id
     * @param em
     * @return
     */
    @Override
    public CourseSection findSection(long id, EntityManager em) {
        return em.find(CourseSection.class, id);
    }

    @Override
    public Course findCourseBySectionId(long sectionId, EntityManager em) {
        Query query = em.createQuery("SELECT s.Course FROM CourseSection s WHERE s.id = :sectionId")
                .setParameter("sectionId", sectionId);
        List list = query.getResultList();
        if (list.isEmpty()) {
            return null;
        }
        return (Course) list.get(0);
    }

    /**
     * get all course section
     * @param em
     * @return
     */
    @Override
    public List<CourseSection> getAllSection(EntityManager em) {
        Query query = em.createQuery("SELECT s FROM CourseSection s");
        return query.getResultList();
    }

    @Override
    public List<CourseSection> getAllSectionByCourseId(long courseId, EntityManager em) {
        Query query = em.createQuery("SELECT s FROM CourseSection s WHERE s.Course.id = :courseId");
        query.setParameter("courseId",courseId);
        return query.getResultList();
    }

    /**
     * Add section to database
     * @param section course section
     * @param em
     * @return course section
     */
    @Override
    public CourseSection createSection(CourseSection section, EntityManager em) {
        try {
            em.persist(section);
            return section;
        } catch (Exception ex) {
            ex.printStackTrace();
            LogService.logger.error("Can not create section");
            return null;
        }
    }

    /**
     * update information of section
     * @param sectionUpdate
     * @param em
     * @return
     */
    @Override
    public boolean updateSection(CourseSection sectionUpdate, EntityManager em) {
        try {
            em.merge(sectionUpdate);
        } catch (Exception e){
            return false;
        }
        return true;
    }

    @Override
    public boolean removeSection(long id, EntityManager em) {
        CourseSection section = findSection(id, em);
        if (section != null){
            section.Course = null;
            em.remove(section);
            return true;
        } else{
            return false;
        }
    }
}
