package daos.impl;

import daos.ProgramDao;
import models.Program;
import services.LogService;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TransactionRequiredException;
import java.util.ArrayList;
import java.util.List;

public class ProgramDaoImpl implements ProgramDao {

    /**
     * Find program by id
     *
     * @param id id to find
     * @param em entity
     * @return
     */
    @Override
    public Program findProgramById(long id, EntityManager em) {
        try {
            Program program = em.find(Program.class, id);
            return program;
        } catch (Exception ex) {
            return null;
        }
    }

    /**
     * Get all programs according to plan
     *
     * @param planId id of plan
     * @param em
     * @return list of programs
     */
    @Override
    public List<Program> getAllProgramByPlanId(long planId, EntityManager em) {
        List<Program> listAllProgram;
        Query query = em.createQuery("SELECT p FROM Program p WHERE p.Plan.id =:planId");
        query.setParameter("planId", planId);
        listAllProgram = query.getResultList();
        return listAllProgram;
    }

    /**
     * Add a program to database
     *
     * @param addProgram program to add
     * @param em
     * @return program that added to database
     */
    @Override
    public Program addProgram(Program addProgram, EntityManager em) {
        try {
            em.persist(addProgram);
            em.flush();
            return addProgram;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean updateProgram(Program program, EntityManager em) {
        if (program != null) {
            try {
                em.merge(program);
            } catch (Exception e) {
                LogService.logger.error(e.getMessage());
                return false;
            }
        }
        return true;
    }
}
