package daos;

import com.google.inject.ImplementedBy;
import daos.impl.CourseDaoImpl;
import models.Course;
import models.Plan;
import models.User;

import javax.persistence.EntityManager;
import java.sql.Timestamp;
import java.util.List;

@ImplementedBy(CourseDaoImpl.class)
public interface CourseDao {

    Course findCourseById(long id, EntityManager em);

    List<Course> getAllCourse(EntityManager em);

    List<Course> getAllCourseByPlanId(long planId, EntityManager em);

    List<Course> getAllCourseByUserId(long userId, EntityManager em);

    List<Course> getAllCourseByUserIdAndPlanId(long planId, long userId, EntityManager em);

    List<Course> getAllCourseByUserIdAndProgramId(long programId, long userId, EntityManager em);

    List<Course> getAllCourseByProgramId(long programId, EntityManager em);

    Course findCourseByTitleUrl(String titleUrl, EntityManager em);

    boolean createCourse(Course course, EntityManager em);

    boolean updateCourse(Course course, EntityManager em);

    void updateCourseImage(Course course, byte[] image, EntityManager em);

    void updateCourseUploadDate(Course course, Timestamp time, EntityManager em);

    Timestamp getLastUpdateCourse(long planId, long userId, EntityManager em);

    List<Course> getReviewingCourses(int brandId, EntityManager em);

    int getNoOfReviewingCourses(int brandId, EntityManager em);

}
