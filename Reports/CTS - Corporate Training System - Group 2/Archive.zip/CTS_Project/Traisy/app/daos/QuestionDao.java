package daos;

import com.google.inject.ImplementedBy;
import daos.impl.QuestionDaoImpl;
import daos.impl.SkillDaoImpl;
import models.Question;
import models.Skill;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Created by Hung on 5/3/2018.
 */
@ImplementedBy(QuestionDaoImpl.class)
public interface QuestionDao {

    Question findQuestionById(long id, EntityManager em);

    List<Question> getAllQuestions(EntityManager em);

    List<Question> getAllQuestionsByQuizId(long id, EntityManager em);

    Question createQuestion(Question question, EntityManager em);

    boolean updateQuestion(Question question, EntityManager em);

    boolean removeQuestion(long id, EntityManager em);

}
