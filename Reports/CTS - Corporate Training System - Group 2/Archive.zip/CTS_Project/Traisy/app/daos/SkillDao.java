package daos;

import com.google.inject.ImplementedBy;
import daos.impl.SkillDaoImpl;
import models.Skill;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Created by Hung on 4/3/2018.
 */
@ImplementedBy(SkillDaoImpl.class)
public interface SkillDao {
    Skill findSkillById(int id, EntityManager em);

    List<Skill> getAllSkill(EntityManager em);

    Skill createSkill(Skill skill, EntityManager em);

    boolean updateSkill(Skill skill, EntityManager em);

    boolean removeSkill(int id, EntityManager em);

}
