package daos;

import models.RolePermissions;
import models.Skill;

import javax.persistence.EntityManager;

/**
 * Created by Hung on 2/2/2018.
 */
public class RolePermissionDao {
    public static RolePermissions findRolePermissionById(Long id, EntityManager em){
        RolePermissions rolePermissions = em.find(RolePermissions.class, id);
        return rolePermissions;
    }
}
