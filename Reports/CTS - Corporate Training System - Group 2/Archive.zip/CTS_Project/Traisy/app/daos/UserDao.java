package daos;

import com.google.inject.ImplementedBy;
import daos.impl.UserDaoImpl;
import fronts.UserData;
import models.Brand;
import models.Plan;
import models.User;

import javax.persistence.EntityManager;
import java.util.List;

@ImplementedBy(UserDaoImpl.class)
public interface UserDao {

    User findUserById(long id, EntityManager em);
  
    User findUserByUsername(String username, EntityManager em);

    User getUserByUsernameAndStatus(String username, int status, EntityManager em);

    List<User> getAllUserByBrandId(int id, EntityManager em);

//    User createUser(String username, String password, String salt, String fullname, int roleId, int status);

    User createUser(User addUser, EntityManager em);

    List<UserData> convertToUserData(List<User> userList);

    boolean removeAllUserByBrandId(int id, EntityManager em);

    List<User> getAvailableAuthors(Plan plan, Brand brand, int pageNo, int size, EntityManager em);

    List<User> getPlanAvailableUsers(Plan plan, Brand brand, int role, int pageNo, int size, EntityManager em);

}
