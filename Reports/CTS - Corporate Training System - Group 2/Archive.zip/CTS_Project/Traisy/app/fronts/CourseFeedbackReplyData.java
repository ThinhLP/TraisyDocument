package fronts;


import java.io.Serializable;
import java.sql.Timestamp;


public class CourseFeedbackReplyData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public Timestamp created_date;

    public String content;

    public CourseFeedbackData CourseFeedback;

    public UserData User;

    public int status = 1;

    public CourseFeedbackReplyData() {

    }

}
