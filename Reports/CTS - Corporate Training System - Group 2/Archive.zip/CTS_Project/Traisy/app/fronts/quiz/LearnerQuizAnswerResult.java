package fronts.quiz;

public class LearnerQuizAnswerResult {
    public long answerId;

    public String answerContent;

    public boolean isCorrect;

    public boolean isSelected;

    public String userAnswerContent = "";

    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        LearnerQuizAnswerResult LearnerQuizAnswerResult = (LearnerQuizAnswerResult) obj;
        return LearnerQuizAnswerResult.answerId == this.answerId;
    }
}
