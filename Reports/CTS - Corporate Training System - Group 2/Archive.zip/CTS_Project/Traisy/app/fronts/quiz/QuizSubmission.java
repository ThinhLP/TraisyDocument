package fronts.quiz;

import java.util.List;

public class QuizSubmission {
    public long lectureId;

    public List<QuestionSubmission> questionSubmissions;
}
