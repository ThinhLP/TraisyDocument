package fronts.quiz;

import java.util.List;

public class LearnerQuizResult implements Comparable<LearnerQuizResult> {
    public long questionId;

    public String questionContent;

    public int quesType;

    public String explaination;

    public boolean isCorrect = false;

    public int order;

    public List<LearnerQuizAnswerResult> answerResults;

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) return false;

        LearnerQuizResult LearnerQuizResult = (LearnerQuizResult) obj;

        return questionId == LearnerQuizResult.questionId;
    }

    @Override
    public int compareTo(LearnerQuizResult o) {
        return this.order - o.order;
    }
}
