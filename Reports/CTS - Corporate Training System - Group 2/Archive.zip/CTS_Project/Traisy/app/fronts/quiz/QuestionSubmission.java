package fronts.quiz;

import java.util.List;

public class QuestionSubmission {
    public long questionId;

    public List<Long> answers;

    public String answerContent;
}
