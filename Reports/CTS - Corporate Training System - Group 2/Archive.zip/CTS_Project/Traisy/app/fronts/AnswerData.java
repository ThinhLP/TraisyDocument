package fronts;

public class AnswerData {

    public long id = 0;

    public String content;

    public int isCorrect;

}
