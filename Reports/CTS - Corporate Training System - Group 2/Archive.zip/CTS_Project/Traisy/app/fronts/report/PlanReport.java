package fronts.report;

public class PlanReport {
    public long id;
    public String title;
    public String titleUrl;

    public int totalLearners;
    public int totalCompleted;
    public int totalAuthors;

    public boolean isOutOfDated;
}
