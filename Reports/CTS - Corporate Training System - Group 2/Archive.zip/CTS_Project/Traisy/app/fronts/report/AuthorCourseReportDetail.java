package fronts.report;

import java.sql.Timestamp;

public class AuthorCourseReportDetail {

    public long id;

    public String title;

    public String titleUrl;

    public int status;

    public Timestamp createdDate;
}
