package fronts.report;

import java.sql.Timestamp;
import java.util.List;

public class AuthorProgramReportDetail implements Comparable<AuthorProgramReportDetail>{
    public long id;
    public String title;
    public Timestamp startDate;
    public Timestamp endDate;

    public int noOfPublic;
    public int noOfReviewing;
    public int noOfPrivate;

    public List<AuthorCourseReportDetail> courses;

    @Override
    public int compareTo(AuthorProgramReportDetail o) {
        return (o.noOfPublic + o.noOfReviewing + o.noOfPrivate) - (this.noOfPublic + this.noOfReviewing + this.noOfPrivate);
    }
}
