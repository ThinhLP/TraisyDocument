package fronts.report;

public class LearnerCourseReportDetail {

    public long id;

    public String title;

    public String author;

    public String titleUrl;

    public double courseProcess;

}
