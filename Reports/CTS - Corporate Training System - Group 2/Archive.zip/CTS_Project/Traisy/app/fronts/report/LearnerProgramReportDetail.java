package fronts.report;

import java.sql.Timestamp;
import java.util.List;

public class LearnerProgramReportDetail {

    public long id;

    public String title;

    public Timestamp startDate;
    public Timestamp endDate;

    public double programProcess;

    public List<LearnerCourseReportDetail> courses;

}
