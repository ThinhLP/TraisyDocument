package fronts.report;

import java.sql.Timestamp;
import java.util.List;

public class AuthorPlanReportDetail {

    public long id;

    public String username;

    public String fullname;

    public String title;

    public int roleId;

    public int totalCourses;

    public Timestamp participatePlanDate;

    public List<AuthorProgramReportDetail> programs;

    public Timestamp lastCourseUpdated;
}
