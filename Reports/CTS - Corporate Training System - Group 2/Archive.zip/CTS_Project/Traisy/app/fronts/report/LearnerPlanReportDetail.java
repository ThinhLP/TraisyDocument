package fronts.report;

import java.sql.Timestamp;
import java.util.List;

public class LearnerPlanReportDetail {

    public long id;

    public String username;

    public String fullname;

    public String title;

    public int roleId;

    public double planProcess;

    public Timestamp participatePlanDate;

    public Timestamp lastLearningDate;

    public List<LearnerProgramReportDetail> programs;

}
