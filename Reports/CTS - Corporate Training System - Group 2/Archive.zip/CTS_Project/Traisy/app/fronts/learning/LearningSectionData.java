package fronts.learning;

import java.util.ArrayList;
import java.util.List;

public class LearningSectionData implements Comparable<LearningSectionData> {
    public long id;
    public String title;
    public int order;
    public List<LearningLectureData> lectures = new ArrayList<>();
    public int noOfCompletedLectures;


    @Override
    public int compareTo(LearningSectionData o) {
        return this.order - o.order;
    }
}
