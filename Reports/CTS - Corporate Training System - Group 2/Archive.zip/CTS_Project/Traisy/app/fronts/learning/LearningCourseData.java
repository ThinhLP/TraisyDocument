package fronts.learning;

import java.util.ArrayList;
import java.util.List;

public class LearningCourseData {

    public long id;

    public String title;

    public String titleUrl;

    public List<LearningSectionData> sections = new ArrayList<>();

    public double learningProcess = 0;
}
