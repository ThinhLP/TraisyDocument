package fronts.learning;

public class LearningLectureData implements Comparable<LearningLectureData> {
    public long id;
    public String title;
    public String titleUrl;
    public int order;
    public int type;
    public boolean isCompleted = false;

    @Override
    public int compareTo(LearningLectureData o) {
        return this.order - o.order;
    }
}
