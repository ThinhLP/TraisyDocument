package fronts.order;

public class LectureOrder {
    public long lecId;
    public int order;
}
