package fronts.order;

import java.util.List;

public class CourseOrder {

    public long courseID;

    public List<SectionOrder> sections;
}
