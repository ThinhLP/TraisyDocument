package fronts.order;

import java.util.List;

public class SectionOrder {
    public long secId = -1;
    public int order = -1;

    public List<LectureOrder> lectures;
}
