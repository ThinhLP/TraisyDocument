package fronts;

public class UserData {

    public long id;

    public String username;

    public String fullname;

    public String title;

    public String brandName;

    public int roleId;

    public double process;



}
