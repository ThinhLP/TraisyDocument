package fronts;

import models.Course;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

public class SkillData implements Serializable {

    private static final long serialVersionUID = 1L;

    public int id;

    public String title;

    public String description;

    public List<CourseData> Courses;
}
