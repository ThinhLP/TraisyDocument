package fronts;

import java.sql.Timestamp;

public class UserPlanData {

    public long id;

    public String username;

    public String fullname;

    public String title;

    public int roleId;

    public double planProcess;

    public Timestamp participatePlanDate;
}
