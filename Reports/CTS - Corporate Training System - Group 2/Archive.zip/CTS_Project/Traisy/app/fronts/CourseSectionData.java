package fronts;

import models.Course;
import models.CourseLecture;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

public class CourseSectionData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public String title;

    public int order;

    public CourseData Course;

    public List<CourseLectureData> CourseLectures;

}
