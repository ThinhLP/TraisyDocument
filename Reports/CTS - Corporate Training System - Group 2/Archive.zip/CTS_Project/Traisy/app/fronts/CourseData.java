package fronts;

import models.*;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class CourseData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public String title;

    public String titleUrl;

    public String description;

    public Integer duration;

    public Timestamp createdDate;

    public Timestamp updatedDate;

    public int status;

    public byte[] introImage;

    public PlanData Plan;

    public Program Program;

    public UserData User;

    public List<CourseSectionData> CourseSections;

    public List<CourseLecture> CourseLectures;

    public List<CourseEnrollData> CourseEnrolls;

    public List<SkillData> Skills;

    public String process;
}
