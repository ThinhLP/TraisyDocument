package fronts;

import models.User;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

public class BrandData implements Serializable {
    private static final long serialVersionUID = 1L;

    public int id;

    public String name;

    public byte[] logo;

    public String description;

    public List<UserData> Users;

}
