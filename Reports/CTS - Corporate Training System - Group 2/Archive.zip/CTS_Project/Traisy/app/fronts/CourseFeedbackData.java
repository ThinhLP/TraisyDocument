package fronts;

import models.Course;
import models.CourseFeedbackReply;
import models.User;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class CourseFeedbackData implements Serializable{

    private static final long serialVersionUID = 1L;

    public long id;

    public Timestamp createdDate;

    public String content;

    public int status;

    public String title;

    public CourseData Course;

    public UserData User;

    public List<CourseFeedbackReply> CourseFeedbackReplies;

    public CourseFeedbackData() {
    }
}
