package fronts;

import models.Answer;
import models.CourseLecture;
import models.LearnerQuizDetail;
import models.Quiz;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class QuestionData {
    public long id = 0;

    public String content;

    public int type;

    public String explaination;

    public int order = 0;

    public List<AnswerData> Answers = new ArrayList<>();

}
