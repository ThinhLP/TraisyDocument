package fronts;

import java.sql.Timestamp;

public class SimpleCourseData {

    public long id;

    public String title;

    public String titleUrl;

    public String description;

    public Integer duration;

    public Timestamp createdDate;

    public Timestamp updatedDate;

    public int status;

    public String author;

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof SimpleCourseData)) {
            return false;
        }
        SimpleCourseData c = (SimpleCourseData) obj;
        return this.id == c.id;
    }
}
