package fronts;

import models.LearnerQuizDetail;
import models.Quiz;
import models.User;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class LearnerQuizData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public double score;

    public Timestamp date;

    public int result;

    public UserData User;

    public QuizData Quiz;

    public List<LearnerQuizDetailData> LearnerQuizDetails;

}
