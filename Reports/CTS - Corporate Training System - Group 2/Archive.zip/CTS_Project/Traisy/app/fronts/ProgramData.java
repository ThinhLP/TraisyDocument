package fronts;

import com.fasterxml.jackson.annotation.JsonIgnore;
import models.Course;
import models.Plan;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class ProgramData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public String title;

    public String description;

    public Timestamp startDate;

    public Timestamp endDate;

    public PlanData Plan;

    public List<CourseData> Courses;

    public ProgramData() {
    }

    public ProgramData(long id, String title, String description, Timestamp startDate, Timestamp endDate) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public ProgramData(String title, String description, Timestamp startDate, Timestamp endDate) {
        this.title = title;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
    }
}
