package fronts;

import models.LearnerQuiz;
import models.Question;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

public class QuizData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public Integer duration;

    public Integer noOfQuestions;

    public Double minScore;

    public List<LearnerQuizData> LearnerQuizs;

    public List<QuestionData> Questions;
}
