package fronts;

import models.Course;
import models.CourseSection;
import models.Quiz;

import javax.persistence.*;
import java.io.Serializable;

public class CourseLectureData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public String title;

    public String titleUrl;

    public int order;

    public int status;

    public int type;

    public CourseSectionData CourseSection;

    public CourseData Course;

    public String lectureFile;

    public Integer duration;

    public String note;

    public QuizData Quiz;



}
