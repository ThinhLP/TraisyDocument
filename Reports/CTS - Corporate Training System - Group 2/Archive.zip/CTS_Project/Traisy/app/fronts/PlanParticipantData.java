package fronts;

import models.Plan;
import models.User;

import javax.persistence.*;
import java.io.Serializable;

public class PlanParticipantData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public UserData User;

    public PlanData Plan;

    public String participateDate;

}
