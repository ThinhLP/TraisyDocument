package fronts;

import models.Course;
import models.PlanParticipant;
import models.Program;
import models.User;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class PlanData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public String title;

    public String titleUrl;

    public Timestamp startDate;

    public Timestamp endDate;

    public String description;

    public byte[] planImage;

    public User User;

    public List<ProgramData> Programs;

    public List<CourseData> Courses;

    public List<PlanParticipantData> PlanParticipants;

    public int process;

    public int overDue;

    public boolean hasAnotherProgram;

    public int status;
}
