package fronts;

import models.User;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

public class RoleData implements Serializable {

    private static final long serialVersionUID = 1L;

    public int id;

    public String roleName;

    public List<UserData> Users;
}
