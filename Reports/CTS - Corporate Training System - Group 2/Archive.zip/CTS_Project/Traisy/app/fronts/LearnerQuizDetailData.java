package fronts;

import models.Answer;
import models.LearnerQuiz;
import models.Question;

import javax.persistence.*;
import java.io.Serializable;

public class LearnerQuizDetailData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public LearnerQuizData LearnerQuiz;

    public QuestionData Question;

    public AnswerData Answer;

}
