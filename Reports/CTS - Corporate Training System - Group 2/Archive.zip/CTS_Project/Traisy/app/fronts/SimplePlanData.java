package fronts;

import java.util.ArrayList;
import java.util.List;

public class SimplePlanData {

    public long id;

    public String title;

    public String titleUrl;

    public List<SimpleCourseData> courses = new ArrayList<>();

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof SimplePlanData)) {
            return false;
        }
        SimplePlanData c = (SimplePlanData) obj;
        return this.id == c.id;
    }

}
