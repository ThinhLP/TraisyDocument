package fronts;

import java.io.Serializable;
import java.sql.Timestamp;

public class CourseDiscussionData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public String content;

    public int status;

    public Timestamp createdDate;

    public UserData User;

    public models.CourseLecture CourseLecture;
}
