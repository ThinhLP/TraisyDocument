package fronts;

import models.Course;
import models.User;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

public class CourseEnrollData implements Serializable {
    private static final long serialVersionUID = 1L;

    public long id;

    public UserData User;

    public CourseData Course;

    public Timestamp enrollDate;

}
