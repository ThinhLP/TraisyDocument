package settings;

import com.google.inject.Singleton;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.config.IniSecurityManagerFactory;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.util.Factory;

@Singleton
public class OnStartup {

    public OnStartup() {
        Factory<SecurityManager> factory = new IniSecurityManagerFactory(("conf/shiro.ini"));
        SecurityManager securityManager = factory.getInstance();

        SecurityUtils.setSecurityManager(securityManager);
    }
}
