package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import commons.TSConst;
import commons.Utils;
import models.Brand;
import models.Plan;
import models.Skill;
import models.User;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import security.authorization.Authorization;
import security.authorization.JsonAuthorization;
import services.*;

import javax.inject.Inject;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class SkillController extends Controller {

    @Inject
    UserService userService;
    @Inject
    SkillService skillService;
    @Inject
    PlanService planService;

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result manageSkillPage() {
        User currentUser = userService.getCurrentUser();
        List<Skill> skills = skillService.findAllSkill();
        return ok(views.html.author.ManageSkill.render(skills, currentUser));
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result createSkill() {
        JsonNode jsonNode = request().body().asJson();
        String title = jsonNode.findPath("title").asText("");
        String description = jsonNode.findPath("description").asText("");
        skillService.createSkill(title, description);
        return noContent();
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateSkill() {
        JsonNode jsonNode = request().body().asJson();
        int id = jsonNode.findPath("id").asInt();
        String title = jsonNode.findPath("title").asText("");
        String description = jsonNode.findPath("description").asText("");
        boolean result = skillService.updateSkill(id, title, description);
        if (result) {
            return noContent();
        }
        return notFound();
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result removeSkill(){
        JsonNode jsonNode = request().body().asJson();
        int id = jsonNode.findPath("id").asInt();
        boolean result = skillService.removeSkill(id);
        if (result){
            return noContent();
        }
        return notFound();
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result addSkillToCourse(){
        JsonNode jsonNode = request().body().asJson();
        long courseId = jsonNode.findPath("courseId").asLong();
        int skillId = jsonNode.findPath("skillId").asInt();

        Skill result = skillService.addSkillToCourse(courseId, skillId);
        if (result != null){
            return noContent();
        }
        return notFound();
    }

    @Transactional
    public Result getSkills(){
        List<Skill> getAllSkils = skillService.findAllSkill();
        if (getAllSkils != null){
            return ok();
        }
        return notFound();
    }

    /**
     * var jsonObjects=[{'id':1}, {'id':2}]
     * ajax call this function with data ={ 'skillId': JSON.stringify(jsonObjects) };
     * @param courseId : courseId of course to add skills
     * @return
     */
    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result addSkillsToCourse(long courseId){
        JsonNode jsonNode = request().body().asJson();

        ObjectMapper mapper = new ObjectMapper();

        String listSkillId = jsonNode.findPath("skillId").asText();
        try {
            //json parse string into List of skill
            List<Skill> listSkill = mapper.readValue(listSkillId,mapper.getTypeFactory().constructCollectionType(
                            List.class, Skill.class));

            skillService.addSkillsToCourse(courseId, listSkill);
            return ok();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return notFound();

    }
}
