package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import fronts.CourseFeedbackData;
import fronts.CourseFeedbackReplyData;
import models.CourseFeedbackReply;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import services.CourseFeedbackService;
import services.ReplyService;
import services.UserService;

import javax.inject.Inject;
import java.sql.Timestamp;

public class ReplyController extends Controller {
    @Inject private UserService userService;
    @Inject private CourseFeedbackService courseFeedbackService;
    @Inject private ReplyService replyService;



    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result createReply(){
        JsonNode jsonNode = request().body().asJson();

        String content = jsonNode.findPath("content").asText("");
        Timestamp createdDate = new Timestamp(System.currentTimeMillis());
        int status = 1;
        long userId = userService.getCurrentUser().id;
        long feedbackId =jsonNode.findPath("feedbackId").asLong(-1);


        CourseFeedbackReplyData reply = replyService.addReply(content,createdDate,status,userId,feedbackId);
        if (reply != null){
            return ok(Json.toJson(reply));
        } else{
            return notFound();
        }
    }
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateReply(){
        JsonNode jsonNode = request().body().asJson();

        long id = jsonNode.findPath("replyId").asLong(-1);
        String content = jsonNode.findPath("content").asText("");
        Timestamp createdDate = new Timestamp(System.currentTimeMillis());
        int status = 1;

        boolean result = replyService.updateReply(id,content,createdDate);
        if (result){
            return noContent();
        } else{
            return notFound();
        }
    }
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result deleteReply(){
        JsonNode jsonNode = request().body().asJson();
        long id = jsonNode.findPath("replyId").asLong(-1);
        boolean result = replyService.removeReply(id);

        if (result){
            return noContent();
        } else{
            return notFound();
        }
    }
}
