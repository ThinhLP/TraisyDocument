package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import commons.TSConst;
import models.CourseSection;
import models.Question;
import models.User;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import security.authorization.JsonAuthorization;
import services.*;

import javax.inject.Inject;
import java.io.IOException;
import java.util.List;

public class QuestionController extends Controller {
    @Inject private UserService userService;
    @Inject private AuthService authService;
    @Inject private SectionService sectionService;
    @Inject private QuestionService questionService;


//    /**
//     * var jsonObjects=[{'id':1, 'order':1}, {'id':2, 'order':2}]
//     * ajax call this function with data ={ 'questionOrder': JSON.stringify(jsonObjects) };
//     * Utils.callJsonAjax(reorderSection, 'POST', data, onSuccess, onFail);
//     * @return
//     */
//    @Transactional
//    @BodyParser.Of(BodyParser.Json.class)
//    public Result reorderQuestion(){
//        JsonNode json = request().body().asJson();
//
//        ObjectMapper mapper = new ObjectMapper();
//
//        //questionOrder with format : [{'id':1, 'order':1}, {'id':2, 'order':2}]
//        String questionOrderInString = json.findPath("questionOrder").asText();
//        try {
//            //json parse string into List of Section
//            List<Question> questions = mapper.readValue(questionOrderInString,
//                    mapper.getTypeFactory().constructCollectionType(List.class, Question.class));
//
//            //reorder sections
//            questionService.reorderQuestion(questions);
//            return ok();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return notFound();
//    }
//
//    @Transactional
//    @BodyParser.Of(BodyParser.Json.class)
//    public Result findQuestion(){
//        JsonNode jsonNode = request().body().asJson();
//
//        long id = jsonNode.findPath("id").asLong();
//
//        Question result = questionService.findQuestion(id);
//        if (result != null){
//            return ok();
//        } else{
//            return notFound();
//        }
//    }
//
//    @Transactional
//    public Result getAllQuestion(){
//
//        List<Question> result = questionService.getAllQuestion();
//        if (result != null){
//            return ok();
//        } else{
//            return notFound();
//        }
//    }
//
//    @Transactional
//    @BodyParser.Of(BodyParser.Json.class)
//    public Result findQuestionByQuizId(){
//        JsonNode jsonNode = request().body().asJson();
//
//        long id = jsonNode.findPath("quizId").asLong();
//
//        List<Question> result = questionService.getAllQuestionByQuizId(id);
//        if (result != null){
//            return ok();
//        } else{
//            return notFound();
//        }
//    }
//
//    @Transactional
//    @BodyParser.Of(BodyParser.Json.class)
//    public Result removeQuestion(){
//        JsonNode jsonNode = request().body().asJson();
//
//        long id = jsonNode.findPath("id").asLong();
//
//        boolean result = questionService.removeQuestion(id);
//        if (result){
//            return ok();
//        } else{
//            return notFound();
//        }
//    }
//
//    @Transactional
//    @BodyParser.Of(BodyParser.Json.class)
//    public Result createQuestion(){
//        JsonNode jsonNode = request().body().asJson();
//
//        String content = jsonNode.findPath("content").asText("");
//        int type = jsonNode.findPath("type").asInt(-1);
//        String explanation = jsonNode.findPath("explanation").asText("");
//        long quizId = jsonNode.findPath("quizId").asLong(-1);
//
//        Question result = questionService.createQuestion(content,type,explanation,quizId);
//
//        if (result != null){
//            return ok();
//        } else{
//            return notFound();
//        }
//    }
}
