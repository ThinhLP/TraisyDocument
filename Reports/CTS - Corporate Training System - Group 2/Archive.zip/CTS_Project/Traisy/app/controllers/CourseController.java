package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import commons.TSConst;
import commons.Utils;
import fronts.*;
import fronts.order.CourseOrder;
import models.*;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import security.authorization.Authorization;
import security.authorization.JsonAuthorization;
import services.*;

import javax.inject.Inject;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class CourseController extends Controller {

    @Inject private CourseService courseService;
    @Inject private UserService userService;
    @Inject private PlanService planService;
    @Inject private AuthService authService;
    @Inject private CourseEnrollService courseEnrollService;
    @Inject private SkillService skillService;
    @Inject private SectionService sectionService;
    @Inject private CourseFeedbackService courseFeedbackService;
    @Inject private LectureService lectureService;

    /**
     * get all couse
     * @return
     */
    @Transactional
    public Result getAllCourse() {
        List<CourseData> courseDataList = courseService.listAllCourse();
        if (courseDataList != null) {
            return ok(Json.toJson((courseDataList)));
        } else {
            return badRequest("Có lỗi xảy ra");
        }
    }

    /**
     * get all course according to plan
     * @return
     */
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result getAllCourseByPlanId() {
        JsonNode json = request().body().asJson();
        long id = json.findPath("planID").asLong();
        List<CourseData> courseDataList = courseService.listAllCourseByPlanId(id);
        if (courseDataList != null) {
            return ok(Json.toJson((courseDataList)));
        } else {
            return badRequest("Có lỗi xảy ra");
        }
    }

    /**
     * get all course by user
     * @return
     */
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result getAllCourseByUserId() {
        JsonNode json = request().body().asJson();
        long id = json.findPath("userID").asLong();
        List<CourseData> courseDataList = courseService.listAllCourseByUserId(id);
        if (courseDataList != null) {
            return ok(Json.toJson((courseDataList)));
        } else {
            return badRequest("Có lỗi xảy ra");

        }
    }

    /**
     * get all course by program
     * @return
     */
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result getAllCourseByProgramId() {
        JsonNode json = request().body().asJson();
        long id = json.findPath("programID").asLong();
        List<CourseData> courseDataList = courseService.listAllCourseByProgramId(id);
        if (courseDataList != null) {
            return ok(Json.toJson((courseDataList)));
        } else {
            return badRequest("Có lỗi xảy ra");
        }
    }

    /**
     * API - Create course
     */
    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result createSimpleCourse() {
        User user = userService.getCurrentUser();

        JsonNode json = request().body().asJson();
        long planId = json.findPath("planId").asLong(-1);
        long programId = json.findPath("programId").asLong(-1);
        String courseTitle = json.findPath("title").asText().trim();

        Plan plan = planService.findPlanById(planId);

        if (plan == null) {
            return notFound();
        }

        // Check authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        CourseData course = courseService.createSimpleCourse(user, plan, programId, courseTitle);

        if (course != null) {
            return ok(Json.toJson(course));
        }

        return notFound();
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateCourse(Long courseId) {
        Course course = courseService.findCourseById(courseId);
        if (course == null) {
            return notFound();
        }

        User currentUser = userService.getCurrentUser();
        // Admin manage must be belong to brand
        if (authService.isAdminOrManager(currentUser) && course.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }
        // Check author owner
        if (authService.isAuthor(currentUser) && course.User.id != currentUser.id) {
            return forbidden();
        }

        JsonNode json = request().body().asJson();
        String courseTitle = json.findPath("title").asText("").trim();
        String courseDescription = json.findPath("description").asText("").trim();

        // TOOD: server side validation

        boolean isUpdated = courseService.updateCourseIntro(course, courseTitle, courseDescription);
        if (isUpdated) {
            return noContent();
        } else {
            return notFound();
        }
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result uploadCourseImage(Long courseId) {
        Http.MultipartFormData body = request().body().asMultipartFormData();
        Http.MultipartFormData.FilePart picture = body.getFile("picture");
        if (picture != null) {
            Course course = courseService.findCourseById(courseId);
            if (course != null) {

            }
            File file = (File) picture.getFile();
            boolean isUpload = courseService.uploadCourseImage(file, course);
            if (isUpload) {
                ObjectNode result = Json.newObject();
                String modified = "?modified=" + new Date().getTime();
                result.put("imageUrl", routes.CourseController.getCourseIntroImage(courseId).url() + modified);
                return ok(result);
            }
        }
        return badRequest();
    }

    @Transactional
    public Result getCourseIntroImage(Long courseId) {
        byte[] image = courseService.findCourseById(courseId).introImage;
        if (image == null) {
            image = Utils.getBytesFromFile(new File("public/resources/images/course_default.jpg"));
        }
        return ok(image).as("image/jpeg");
    }


    @Transactional
    @Authorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result manageCoursePage(String courseTitleUrl) {
        User user = userService.getCurrentUser();
        Course course = courseService.findCourseByTitleUrl(courseTitleUrl);

        if (course.status == TSConst.COURSE_CONFIG.STATUS.DELETE) {
            return redirect(routes.Application.notFoundPage());
        }

        boolean isCourseAuthor = authService.isAdminOrManager(user) || course.User.id == user.id;
        if (!isCourseAuthor) {
            return redirect(routes.Application.notFoundPage());
        }

        List<Skill> allSkills = skillService.findAllSkill();
        HashMap<Integer, String> hm = new HashMap<>();

        List<CourseFeedback> discussionData = courseFeedbackService.getAllFeedbackByCourse(courseTitleUrl);

        for (Skill s :
                course.Skills) {
            hm.put(s.id, s.title);
        }
        List<UserData> learnerDataOfCourse = userService.findUsersEnrollInCourse(course.id);
        if (course.CourseSections != null && !course.CourseSections.isEmpty()) {
            Collections.sort(course.CourseSections);
        }
        int notification = 0;
        for (CourseFeedback temp : discussionData){
            if (temp.status == 0 && temp.parentId == null){
                notification++;
            }
        }
        //get all duration of feedback
        HashMap<Long,String> feedbackDuration = new HashMap<>();
        for (CourseFeedback feedbackTemp : discussionData) {
            feedbackDuration.put(feedbackTemp.id,Utils.getDurationString(feedbackTemp.createdDate));
        }
        return ok(views.html.author.ManageCoursePage.render(course, user, learnerDataOfCourse, allSkills, hm,discussionData,notification, feedbackDuration));
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result overviewCourseLearnerPage(String titleUrl) {

        Course course = courseService.findCourseByTitleUrl(titleUrl);
        if (course == null) {
            //todo: render 404 page
            return notFound();
        }
        course.CourseSections = sectionService.getAllSectionWithPublishLecture(course.id);
        course.CourseLectures = lectureService.getAllLectureByCourseId(course.id);
        User user = userService.getCurrentUser();

        if (course.status == TSConst.COURSE_CONFIG.STATUS.DELETE) {
            return notFound(); // TODO: render 404 page
        }

        if (course.CourseSections != null && !course.CourseSections.isEmpty()) {
            Collections.sort(course.CourseSections);
        }
        List<Course> tempList = new ArrayList<>();
        tempList.add(course);
        List<CourseData> courseData = courseService.convertToCourseDataList(tempList,user.id);
        CourseData result = new CourseData();
        if (courseData!= null && !courseData.isEmpty()){
            result = courseData.get(0);
        }
        return ok(views.html.learner.CourseOverview.render(user, result));
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result updateSectionAndLectureOrder() {
        Http.RequestBody body = request().body();
        JsonNode jsonData = body.asJson();
        CourseOrder courseOrder;
        try {
            courseOrder = Json.fromJson(jsonData, CourseOrder.class);
        } catch (Exception e) {
            return internalServerError();
        }
        courseService.resetCourseSecLecOrders(courseOrder);
        return noContent();
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateCourseStatus(Long courseId) {
        if (courseId <= 0) {
            return notFound();
        }

        JsonNode json = request().body().asJson();
        int status = json.findPath("status").asInt(-1);

        User user = userService.getCurrentUser();
        Course course = courseService.findCourseById(courseId);

        if (course == null) {
            return notFound();
        }

        boolean isUpdated = courseService.updateCourseStatus(course, status);
        if (isUpdated) {
            if (status == 0){
                status = 1;
            } else{
                status = 0;
            }
            ObjectNode result = Json.newObject();
            result.put("status",status);
            return ok(result);
        } else {
            return notFound();
        }
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result sendCourseToReview(Long courseId) {
        if (courseId <= 0) {
            return notFound();
        }

        User user = userService.getCurrentUser();
        Course course = courseService.findCourseById(courseId);

        if (course == null) {
            return notFound();
        }

        boolean isCourseAuthor = authService.isAdminOrManager(user) || course.User.id == user.id;
        if (!isCourseAuthor) {
            return forbidden();
        }

        boolean isUpdated = courseService.updateCourseStatus(course, TSConst.COURSE_CONFIG.STATUS.REVIEWING);
        if (isUpdated) {
            return noContent();
        } else {
            return notFound();
        }
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    @BodyParser.Of(BodyParser.Json.class)
    public Result removeCourse(Long courseId) {
        if (courseId <= 0) {
            return notFound();
        }
        User user = userService.getCurrentUser();
        Course course = courseService.findCourseById(courseId);
        String planUrl = course.Plan.titleUrl;

        if (course == null) {
            return notFound();
        }

        boolean isCourseAuthor = authService.isAdminOrManager(user) || course.User.id == user.id;
        if (!isCourseAuthor) {
            return notFound();
        }

        boolean isRemoved = courseService.updateCourseStatus(course, TSConst.COMMON_STATUS.DELETED);

        if (isRemoved) {
            ObjectNode result = Json.newObject();
            result.put("url", routes.PlanController.managePlanDetail(planUrl).url());
            return ok(result);
        }
        return notFound();
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result uploadIntroVideoCourse(Long courseId) {
        Http.MultipartFormData body = request().body().asMultipartFormData();
        List<Http.MultipartFormData.FilePart> uploadFiles = body.getFiles();

        if (uploadFiles == null || uploadFiles.size() < 1) {
            return badRequest();
        }

        Http.MultipartFormData.FilePart uploadFile = uploadFiles.get(0);

        Course course = courseService.uploadIntroVideo(courseId, uploadFile);

        if (course == null) {
            return notFound();
        }

        return noContent();
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result getLearnerEnrollOfCourse(){
        JsonNode jsonNode = request().body().asJson();
        long courseId = jsonNode.findPath("courseId").asLong(-1);
        List<User> users = courseEnrollService.findUsersEnrollInCourse(courseId);
        if (users != null){
            return noContent();
        } else {
            return notFound();
        }

    }
//    @Transactional
//    public Result getIntroVideoThumbnail(long courseId) {
//       /* BCourseLecture lecture = LectureService.findLectureByID(lectrueID);
//        if (lecture == null) {
//            return notFound("COULD NOT FOUND THE FILE");
//        }*/
//        File imageFile = CourseToolService.getCourseVideoPreview(courseID);
//
//        if (imageFile == null) {
//            return BConst.ERROR_URI.NOT_FOUND_PAGE.redirect();
//        }
//
//        byte[] image;
//
//        //File imageFile = new File(path);
//        if (imageFile.exists() == false) {
//            imageFile = new File("public/images/default_video_preview.jpg");
//        }
//
//        image = commons.Utils.getBytesFromFile(imageFile);
//        return ok(image).as("image/jpeg");
//    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result addSkillToCourse(){
        JsonNode jsonNode = request().body().asJson();
        long courseId = jsonNode.findPath("courseId").asLong();
        int skillId = jsonNode.findPath("skillId").asInt();

        Skill skill= skillService.addSkillToCourse(courseId, skillId);
        SkillData result = skillService.convertToSkillData(skill);
        if (result!= null){
            return ok(Json.toJson(result));
        }
        return notFound();
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result removeSkillFromCourse(){
        JsonNode jsonNode = request().body().asJson();
        long courseId = jsonNode.findPath("courseId").asLong();
        int skillId = jsonNode.findPath("skillId").asInt();

        Skill skill= skillService.removeSkillFromCourse(courseId, skillId);
        SkillData result = skillService.convertToSkillData(skill);
        if (result!= null){
            return ok(Json.toJson(result));
        }
        return notFound();
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result enrollCourse(Long courseId) {

        if (courseId <= 0) {
            return redirect(routes.Application.notFoundPage());  // TODO: redirect to 404 page
        }

        Course course = courseService.findCourseById(courseId);
        if (course == null) {
            return redirect(routes.Application.notFoundPage());
        }

        User user = userService.getCurrentUser();

        if (user.Brand.id != course.User.Brand.id) {
            return redirect(routes.Application.notFoundPage());
        }

        boolean skipAuthority = authService.isAdminOrManager(user) || course.User.id == user.id;

        if (skipAuthority) {
            CourseLecture firstPublicLecture = lectureService.getFirstPublicLecture(course.id);
            if (firstPublicLecture == null) {
                return redirect(routes.Application.notFoundPage());
            }
            return redirect(routes.LectureController.loadLecturePage(course.titleUrl, firstPublicLecture.titleUrl));
        }

        if (course.status != TSConst.COURSE_CONFIG.STATUS.PUBLIC) {
            return redirect(routes.Application.notFoundPage());
        }

        if (!planService.hasParticipated(course.Plan, user)) {
            return redirect(routes.Application.notFoundPage());
        }

        courseEnrollService.updateCourseEnroll(user, course);

        CourseLecture firstPublicLecture = lectureService.getFirstPublicLecture(course.id);
        if (firstPublicLecture == null) {
            return redirect(routes.Application.notFoundPage());
        }
        return redirect(routes.LectureController.loadLecturePage(course.titleUrl, firstPublicLecture.titleUrl));
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.MANAGER)
    public Result getNoOfReviewingCourses() {
        User currentUser = userService.getCurrentUser();
        int noOfReviewingCourses = courseService.getNoOfReviewingCourses(currentUser.Brand.id);
        ObjectNode result = Json.newObject();
        result.put("count", noOfReviewingCourses);
        return ok(result);
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.MANAGER)
    public Result manageCourseReview() {
        User currentUser = userService.getCurrentUser();
        List<SimplePlanData> plans = courseService.getReviewingCourses(currentUser.Brand.id);
        return ok(views.html.manager.ManageCourseReview.render(plans,currentUser));
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result teachingCoursesPage() {
        User currentUser = userService.getCurrentUser();
        List<SimplePlanData> plans = courseService.getTeachingCourses(currentUser.id);
        return ok(views.html.author.TeachingCourses.render(plans,currentUser));
    }

}
