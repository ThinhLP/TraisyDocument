package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import fronts.CourseFeedbackData;
import models.CourseFeedback;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import services.*;

import javax.inject.Inject;
import java.sql.Timestamp;
import java.util.List;

public class FeedbackController extends Controller {
    @Inject private UserService userService;
    @Inject private CourseFeedbackService courseFeedbackService;



    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result createFeedback(){
        JsonNode jsonNode = request().body().asJson();

        String title = jsonNode.findPath("title").asText("");
        String content = jsonNode.findPath("content").asText("");
        Timestamp createdDate = new Timestamp(System.currentTimeMillis());
        int status = 0;
        long userId = userService.getCurrentUser().id;
        long courseId =jsonNode.findPath("courseId").asLong(-1);
        long parentId = jsonNode.findPath("parentId").asLong(-1);
        CourseFeedbackData feedback = courseFeedbackService.addFeedback(title,content,createdDate,parentId, status,userId,courseId);

        if (feedback != null){
            return ok(Json.toJson(feedback));
        } else{
            return notFound();
        }
    }


    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateFeedback(){
        JsonNode jsonNode = request().body().asJson();

        long id = jsonNode.findPath("feedbackId").asLong(-1);
        String title = jsonNode.findPath("title").asText("");
        String content = jsonNode.findPath("content").asText("");
        Timestamp createdDate = new Timestamp(System.currentTimeMillis());
        int status = 0;

        boolean result = courseFeedbackService.updateFeedback(id,title,content,createdDate, status);

        if (result){
            return noContent();
        } else{
            return notFound();
        }
    }


    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateFeedbackStatus(){
        JsonNode jsonNode = request().body().asJson();

        long id = jsonNode.findPath("feedbackId").asLong(-1);
        int status = jsonNode.findPath("status").asInt();
        boolean result = courseFeedbackService.updateFeedback(id,null,null,null, status);

        if (result){
            return noContent();
        } else{
            return notFound();
        }
    }
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result deleteFeedback(){
        JsonNode jsonNode = request().body().asJson();
        long id = jsonNode.findPath("feedbackId").asLong(-1);
        boolean result = courseFeedbackService.removeFeedback(id);

        if (result){
            return noContent();
        } else{
            return notFound();
        }
    }
}
