package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import commons.TSConst;
import commons.Utils;
import daos.CourseDao;
import fronts.UserData;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import models.Plan;
import models.User;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import security.authorization.Authorization;
import security.authorization.JsonAuthorization;
import services.PlanService;
import services.UserService;

import javax.inject.Inject;
import java.io.File;
import java.util.Collections;
import java.util.List;

public class UserController extends Controller {

    @Inject
    private UserService userService;
    @Inject
    private  PlanService planService;
    @Inject
    private CourseDao courseDao;

    /**
     * Update user account API
     */
    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateAccount() {

        JsonNode json = request().body().asJson();
        long userId = json.findPath("userId").asLong();
        User user = userService.findUser(userId);
        String newPassword = json.findPath("password").asText("");
        String newFullname = json.findPath("fullname").asText("");
        String newTitle = json.findPath("title").asText();
        int roleId = json.findPath("roleId").asInt(-1);
        int statusId = json.findPath("statusId").asInt(-1);
        if (roleId <= 0 || statusId < 0) {
            return badRequest();
        }

        int fullnameLength = newFullname.length();
        if (fullnameLength > TSConst.FIELD_VALIDATION.MAX_NAME_LEN || fullnameLength < TSConst.FIELD_VALIDATION.MIN_NAME_LEN){
            return badRequest("Họ và tên phải từ 4 đến 30 kí tự");
        }

        // Update account
        boolean update = userService.updateAccount(user, newPassword,newFullname, newTitle, roleId, statusId);

        return noContent();
    }
    /**
     * Update user account API
     */
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateAccountForLearner() {

        // Get value from json and check validation
        JsonNode json = request().body().asJson();
        long userId = json.findPath("userId").asLong();
        String newPassword = json.findPath("password").asText("");
        String currentPassword = json.findPath("currentPassword").asText("");
        String newFullname = json.findPath("fullname").asText("");
        String newTitle = json.findPath("title").asText();

        int fullnameLength = newFullname.length();
        if (fullnameLength > TSConst.FIELD_VALIDATION.MAX_NAME_LEN || fullnameLength < TSConst.FIELD_VALIDATION.MIN_NAME_LEN){
            return badRequest("Họ và tên phải từ 4 đến 30 kí tự");
        }

//         Update account
        boolean update = userService.updateAccountForLearner(userId,currentPassword, newPassword,newFullname, newTitle);
        if (!update){
            return badRequest();
        }
        return noContent();
    }


    @Transactional
    public Result uploadUserImage(long id) {
        User currentUser = userService.getCurrentUser();
        Http.MultipartFormData body = request().body().asMultipartFormData();
        Http.MultipartFormData.FilePart picture = body.getFile("picture");
        if (picture != null) {
            File file = (File) picture.getFile();
            userService.updateUserImage(id, file);
        }
        return redirect(routes.UserController.manageProfilePage());
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @Authorization(role = TSConst.USER_ROLE.MANAGER)
    public Result createUser() {
        User user = userService.getCurrentUser();
        // Todo: Check authority - admin, manager

        // Get value from json and check validation
        JsonNode json = request().body().asJson();
        String username = json.findPath("username").asText("");
        String password = json.findPath("password").asText("");
        int brandId = user.Brand.id;
        String fullname = json.findPath("fullname").asText("");
        int roleId = json.findPath("roleId").asInt(-1);
        int status = json.findPath("statusId").asInt(-1);
        String title = json.findPath("title").asText("");
        if (brandId <= 0 || roleId <= 0) {
            return badRequest();
        }

//        if (username.length() < TSConst.FIELD_VALIDATION.MIN_EMAIL_LEN || username.length() > TSConst.FIELD_VALIDATION.MAX_EMAIL_LEN) {
//            return badRequest("Tên đăng nhập phải từ 5 đến 40 kí tự");
//        }
        User createUser = userService.findUser(username);

        if (createUser != null){
            return badRequest("Tên đăng nhập bị trùng");
        }
        int passwordLength = password.length();
        if (passwordLength > TSConst.FIELD_VALIDATION.MAX_PASSWORD_LEN || passwordLength < TSConst.FIELD_VALIDATION.MIN_PASSWORD_LEN) {
            return badRequest("Mật khẩu phải từ 4 đến 30 kí tự");
        }

        int fullnameLength = fullname.length();
        if (fullnameLength > TSConst.FIELD_VALIDATION.MAX_NAME_LEN || fullnameLength < TSConst.FIELD_VALIDATION.MIN_NAME_LEN){
            return badRequest("Họ và tên phải từ 4 đến 30 kí tự");
        }
        // Create account
        boolean isCreated = userService.createAccount(username, password, fullname, title, brandId, roleId, status);
        if (isCreated) {
            return noContent();
        }
        return notFound();
    }

    /**
     * list user with brand id
     *
     * @return
     */
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result findUserById() {
        JsonNode jsonNode = request().body().asJson();
        long id = jsonNode.findPath("userId").asLong();
        User user = userService.findUser(id);
        if (user != null) {
            ObjectNode result = Json.newObject();
            result.put("username", user.username);
            result.put("fullname", user.fullname);
            result.put("title", user.title);
            result.put("role", user.Role.roleName);
            result.put("status", user.status);
            return ok(Json.toJson(result));
        } else return badRequest("Có lỗi xảy ra");
//        return badRequest("asd");
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.MANAGER)
    public Result manageUserPage() {
        User currentUser = userService.getCurrentUser();
        List<User> users = userService.listAllUserByBrandId(currentUser.Brand.id);
        Collections.sort(users);
        return ok(views.html.admin.ManageUser.render(users, currentUser));
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result manageProfilePage() {
        User currentUser = userService.getCurrentUser();
        return ok(views.html.learner.ManageProfile.render(currentUser));
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result manageProfilePageManager() {
        User currentUser = userService.getCurrentUser();
        return ok(views.html.manager.ManageProfile.render(currentUser));
    }

    @Transactional
    public Result uploadUserImageManager(long id) {
        User currentUser = userService.getCurrentUser();
        Http.MultipartFormData body = request().body().asMultipartFormData();
        Http.MultipartFormData.FilePart picture = body.getFile("picture");
        if (picture != null) {
            File file = (File) picture.getFile();
            userService.updateUserImage(id, file);
        }
        return redirect(routes.UserController.manageProfilePageManager());
    }
    /* Get user avatar */
    @Transactional
    public Result getUserAvatar(long userId) {
        byte[] image = userService.findUser(userId).avatar;
        if (image == null) {
            image = Utils.getBytesFromFile(new File("public/resources/images/man.png"));
        }
        return ok(image).as("image/jpeg");
    }
}
