package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import commons.TSConst;
import fronts.ProgramData;
import models.Plan;
import models.Program;
import models.User;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import security.authorization.JsonAuthorization;
import services.*;

import javax.inject.Inject;
import java.util.List;

public class ProgramController extends Controller {

    @Inject private UserService userService;
    @Inject private AuthService authService;
    @Inject private ProgramService programService;
    @Inject private PlanService planService;

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result getAllProgramById() {
        JsonNode json = request().body().asJson();
        long id = json.findPath("planID").asLong();
        List<ProgramData> listProgram = programService.listAllProgramByPlanId(id);
        if (listProgram != null) {
            return ok(Json.toJson((listProgram)));
        } else {
            String err = String.format("There is an error when get program ");
            LogService.logger.error(err);
            return badRequest("Có lỗi xảy ra");
        }
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateProgram() {
        JsonNode json = request().body().asJson();
        long planId = json.findPath("planId").asLong();
        long programId = json.findPath("programId").asLong();

        Plan plan = planService.findPlanById(planId);
        if (plan == null || plan.status != TSConst.COMMON_STATUS.PUBLIC) {
            return null;
        }

        User currentUser = userService.getCurrentUser();

        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        String title = json.findPath("title").asText();
        long startDate = json.findPath("startDate").asLong(-1);
        long endDate = json.findPath("endDate").asLong(0);

        if (endDate < startDate || title.length() < TSConst.FIELD_VALIDATION.MIN_TITLE_LEN || title.length() > TSConst.FIELD_VALIDATION.MAX_TITLE_LEN) {
            return badRequest();
        }

        boolean isUpdated = programService.updateProgram(programId, title, startDate, endDate);
        if (!isUpdated) {
            return notFound();
        }

        return noContent();


    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    @BodyParser.Of(BodyParser.Json.class)
    public Result removeProgram() {
        JsonNode json = request().body().asJson();
        long planId = json.findPath("planId").asLong();
        long programId = json.findPath("programId").asLong();

        if (planId <= 0 || programId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);
        if (plan == null || plan.status != TSConst.COMMON_STATUS.PUBLIC) {
            return null;
        }

        User currentUser = userService.getCurrentUser();

        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        boolean result = programService.removeProgram(programId);
        if (result) {
            return noContent();
        }
        return notFound();
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    @BodyParser.Of(BodyParser.Json.class)
    public Result createSimpleProgram(Long planId) {

        if (planId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);

        if (plan == null) {
            return notFound();
        }

        JsonNode json = request().body().asJson();
        String title = json.findPath("title").asText();
        long startDate = json.findPath("startDate").asLong(-1);
        long endDate = json.findPath("endDate").asLong(0);

        if (endDate < startDate || title.length() < TSConst.FIELD_VALIDATION.MIN_TITLE_LEN || title.length() > TSConst.FIELD_VALIDATION.MAX_TITLE_LEN) {
            return badRequest();
        }

        ProgramData program = programService.createSimpleProgram(plan, title, startDate, endDate);
        if (program == null) {
            return notFound();
        }

        return ok(Json.toJson(program));

    }

}
