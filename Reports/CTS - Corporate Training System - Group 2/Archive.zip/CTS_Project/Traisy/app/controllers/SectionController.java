package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import commons.TSConst;
import fronts.CourseSectionData;
import models.Course;
import models.CourseSection;
import models.User;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import security.authorization.JsonAuthorization;
import services.*;

import javax.inject.Inject;
import javax.swing.text.View;
import java.io.IOException;
import java.util.List;

public class SectionController extends Controller {
    @Inject private UserService userService;
    @Inject private AuthService authService;
    @Inject private SectionService sectionService;
    @Inject private CourseService courseService;
    @Inject private CouseSectionService couseSectionService;


    /**
     * create section according to course id
     * the section created will have the maximum order of sections in the following course id
     *
     * @return
     */
    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result createSection(Long courseId) {
        JsonNode json = request().body().asJson();
        String sectionTitle = json.findPath("title").asText("").trim();

        Course course = courseService.findCourseById(courseId);
        if (course == null) {
            return notFound();
        }

        // Check authority
        User user = userService.getCurrentUser();
        CourseSectionData sectionData = sectionService.createSection(course, sectionTitle);

        if (sectionData != null) {
            return ok(Json.toJson(sectionData));
        }

        return notFound();
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateSection() {
        User user = userService.getCurrentUser();
        //Todo: check authority

        JsonNode json = request().body().asJson();
        long sectionId = json.findPath("id").asLong(-1);
        String title = json.findPath("title").asText("");

        boolean isUpdated = sectionService.updateSection(sectionId, title);

        if (isUpdated) {
            return noContent();
        }

        return notFound();

    }

    /**
     * var jsonObjects=[{'id':1, 'order':1}, {'id':2, 'order':2}]
     * ajax call this function with data ={ 'courseOrder': JSON.stringify(jsonObjects) };
     * Utils.callJsonAjax(reorderSection, 'POST', data, onSuccess, onFail);
     *
     * @return
     */
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result reorderSection() {
        JsonNode json = request().body().asJson();

        ObjectMapper mapper = new ObjectMapper();

        //courseOrder with format : [{'id':1, 'order':1}, {'id':2, 'order':2}]
        String courseOrderInString = json.findPath("courseOrder").asText();
        try {
            //json parse string into List of Section
            List<CourseSection> sections = mapper.readValue(courseOrderInString,
                    mapper.getTypeFactory().constructCollectionType(List.class, CourseSection.class));

            //reorder section
            couseSectionService.reorderCourseSection(sections);
            return ok();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return notFound();
    }


    /**
     * remove section by id
     *
     * @return
     */
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result removeSection() {
        JsonNode jsonNode = request().body().asJson();

        long id = jsonNode.findPath("id").asLong();
        long courseId = jsonNode.findPath("courseId").asLong();

        User currentUser = userService.getCurrentUser();
        if (currentUser.Role.id == TSConst.USER_ROLE.AUTHOR.value) {
            Course courseOfCurrentUser = courseService.findCourseById(courseId);
            if (courseOfCurrentUser.User.id == currentUser.id) {
                boolean result = couseSectionService.removeCourseSection(id);
                if (result) {
                    return noContent();
                } else {
                    return notFound();
                }
            }
        } else {
            boolean result = couseSectionService.removeCourseSection(id);
            if (result) {
                return noContent();
            } else {
                return notFound();
            }
        }
        return noContent();
    }

}
