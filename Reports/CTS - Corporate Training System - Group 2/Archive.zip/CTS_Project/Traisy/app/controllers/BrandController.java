package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import commons.TSConst;
import commons.Utils;
import models.Brand;
import models.User;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import security.authorization.Authorization;
import security.authorization.JsonAuthorization;
import services.*;

import javax.inject.Inject;
import java.io.File;
import java.util.List;

public class BrandController extends Controller {
    @Inject private UserService userService;
    @Inject private AuthService authService;
    @Inject private BrandService brandService;


    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.SYSTEM_ADMIN)
    @BodyParser.Of(BodyParser.Json.class)
    public Result createSimpleBrand() {
        JsonNode jsonNode = request().body().asJson();
        String title = jsonNode.findPath("name").asText("");

        Brand newBrand = brandService.createSimpleBrand(title);

        String newTitle = Utils.removeAccents(title);

        if (newBrand != null) {
            ObjectNode result = Json.newObject();
            result.put("id",newBrand.id);
            result.put("titleUrl",newTitle );
            return ok(result);
        } else {
            return badRequest();
        }
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.SYSTEM_ADMIN)
    public Result manageBrandPage() {
        User currentUser = userService.getCurrentUser();
        List<Brand> brands = brandService.findAllBrand();
        return ok(views.html.admin.NewManageBrand.render(brands, currentUser));
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.ADMIN)
    public Result manageBrandPageDetail(int id) {
        User currentUser = userService.getCurrentUser();
        Brand currentBrand = brandService.findBrandById(id);

        if (currentBrand == null) {
            return redirect(routes.Application.notFoundPage());
        }

        if (!authService.isSystemAdmin(currentUser) && currentBrand.id != currentUser.Brand.id) {
            return redirect(routes.Application.notFoundPage());
        }

        return ok(views.html.admin.NewManageBrandDetail.render(currentBrand, currentUser));
    }

    @Transactional
    public Result getBrandLogo(int id) {
        Brand brand = brandService.findBrandById(id);
        byte[] image = brand.logo;
        if (image == null) {
            image = Utils.getBytesFromFile(new File("public/resources/images/Default-Logo.png"));
        }
        return ok(image).as("image/jpeg");
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @Authorization(role = TSConst.USER_ROLE.SYSTEM_ADMIN)
    public Result removeBrand(){
        JsonNode jsonNode = request().body().asJson();
        int id = jsonNode.findPath("id").asInt();
        boolean result = brandService.removeBrand(id);
        if (result == true){
            return noContent();
        } else {
            return notFound();
        }
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @Authorization(role = TSConst.USER_ROLE.ADMIN)
    public Result updateBrand(){
        JsonNode jsonNode = request().body().asJson();
        int id = jsonNode.findPath("id").asInt();
        String name = jsonNode.findPath("name").textValue();
        String description = jsonNode.findPath("description").textValue();

        User currentUser = userService.getCurrentUser();

        if (!authService.isSystemAdmin(currentUser) && currentUser.Brand.id != id) {
            return notFound();
        }

        boolean isUpdated = brandService.updateBrand(id,name,description);
        if (isUpdated){
            return noContent();
        } else {
            return notFound();
        }
    }


    @Transactional
    @Authorization(role = TSConst.USER_ROLE.ADMIN)
    public Result uploadBrandImage(int id) {
        Http.MultipartFormData body = request().body().asMultipartFormData();
        Http.MultipartFormData.FilePart picture = body.getFile("picture");

        User currentUser = userService.getCurrentUser();

        if (!authService.isSystemAdmin(currentUser) && currentUser.Brand.id != id) {
            return redirect(routes.Application.notFoundPage());
        }

        if (picture != null) {
            File file = (File) picture.getFile();
            brandService.updateBrandImage(id, file);
        }
        return redirect(routes.BrandController.manageBrandPageDetail(id));
    }
}
