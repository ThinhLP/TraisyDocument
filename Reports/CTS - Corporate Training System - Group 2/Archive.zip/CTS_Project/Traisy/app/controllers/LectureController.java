package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.inject.Inject;
import commons.TSConst;
import commons.Utils;
import fronts.CourseLectureData;
import fronts.learning.LearningCourseData;
import fronts.learning.LearningLectureData;
import models.*;
import play.db.jpa.JPAApi;
import play.db.jpa.Transactional;
import play.i18n.Messages;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import security.authorization.Authorization;
import security.authorization.JsonAuthorization;
import services.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class LectureController extends Controller {

    @Inject private UserService userService;
    @Inject private LectureService lectureService;
    @Inject private AuthService authService;
    @Inject private ResourceService resourceService;
    @Inject private CourseService courseService;
    @Inject private CourseEnrollService courseEnrollService;
    @Inject private PlanService planService;
    @Inject private DiscussionService discussionService;
    @Inject private LearnerProcessService learnerProcessService;


    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result createSimpleLecture() {
        JsonNode jsonNode = request().body().asJson();

        String title = jsonNode.findPath("title").asText("").trim();
        Long sectionId = jsonNode.findPath("sectionId").asLong(-1);

        if (title.length() < TSConst.FIELD_VALIDATION.MIN_TITLE_LEN || title.length() > TSConst.FIELD_VALIDATION.MAX_TITLE_LEN) {
            return badRequest();
        }

        // TODO: Check authority
        User currentUser = userService.getCurrentUser();

        CourseLectureData lecture = lectureService.createSimpleLecture(sectionId, title);
        if (lecture != null) {
            return ok(Json.toJson(lecture));
        }

        return notFound();
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result deleteLecture() {
        JsonNode jsonNode = request().body().asJson();

        Long lectureId = jsonNode.findPath("lectureId").asLong(-1);

        boolean result = lectureService.deleteLecture(lectureId);
        if (result) {
            return noContent();
        }

        return notFound();
    }
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result updateLecture() {
        JsonNode jsonNode = request().body().asJson();

        String title = jsonNode.findPath("title").asText("").trim();
        Long lectureId = jsonNode.findPath("lectureId").asLong(-1);
        int status = jsonNode.findPath("status").asInt(-1);

        if (!title.isEmpty() && (title.length() < TSConst.FIELD_VALIDATION.MIN_TITLE_LEN || title.length() > TSConst.FIELD_VALIDATION.MAX_TITLE_LEN)) {
            return badRequest();
        }

        if (status != -1 && status != TSConst.COURSE_CONFIG.STATUS.PUBLIC && status != TSConst.COURSE_CONFIG.STATUS.PRIVATE) {
            return badRequest();
        }

        // TODO: Check authority
        User currentUser = userService.getCurrentUser();

        CourseLectureData lecture = lectureService.updateLecture(lectureId, title, status);
        if (lecture != null) {
            return ok(Json.toJson(lecture));
        }

        return notFound();
    }


    @Transactional
    public Result downloadLectureResource(String fileName) {
        File resourceFile = resourceService.findResourceFile(fileName);

        if (resourceFile == null || !resourceFile.exists()) {
            return notFound();
        }

        return ok(resourceFile);
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateLectureStatus() {

        JsonNode json = request().body().asJson();
        Long lectureId = json.findPath("id").asLong(-1);
        int status = json.findPath("status").asInt(-1);


        boolean isUpdated = lectureService.updateLectureStatus(lectureId, status);
        if (isUpdated) {
            if (status == 0){
                status = 1;
            } else{
                status = 0;
            }
            ObjectNode result = Json.newObject();
            result.put("status",status);
            return ok(result);
        } else {
            return notFound();
        }
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result manageLecturePage(String lectureTitleUrl) {
        User user = userService.getCurrentUser();

        //Authority
        CourseLecture lecture = lectureService.getLectureByTitleUrl(lectureTitleUrl);
        if (lecture == null) {
            return notFound();
        }
        return ok(views.html.author.ManageLecture.render(lecture, user));
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result uploadLectureVideo(Long lectureId) {
        Http.MultipartFormData body = request().body().asMultipartFormData();
        List<Http.MultipartFormData.FilePart> uploadFiles = body.getFiles();

        if (uploadFiles == null || uploadFiles.size() < 1) {
            return badRequest();
        }

        Http.MultipartFormData.FilePart uploadFile = uploadFiles.get(0);

        CourseLecture lecture = lectureService.uploadLectureVideo(lectureId, uploadFile);

        if (lecture == null) {
            return notFound();
        }

        ObjectNode result = Json.newObject();

        result.put("fileName", lecture.lectureFile);
        result.put("duration", Utils.secondToMinutes(lecture.duration));

        return ok(result);
    }


    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result uploadLectureText(Long lectureId) {
        Http.MultipartFormData body = request().body().asMultipartFormData();
        List<Http.MultipartFormData.FilePart> uploadFiles = body.getFiles();

        if (uploadFiles == null || uploadFiles.size() < 1) {
            return badRequest();
        }

        Http.MultipartFormData.FilePart uploadFile = uploadFiles.get(0);

        CourseLecture lecture = lectureService.uploadLectureText(lectureId, uploadFile);

        if (lecture == null) {
            return notFound();
        }

        return noContent();
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result getLectureTextContent(Long lectureId) {
        byte[] lectureTextContent = lectureService.getLectureTextContent(lectureId);
        if (lectureTextContent == null) {
            return notFound();
        }
        return ok(lectureTextContent);
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result uploadLectureSlideshow(Long lectureId) {
        Http.MultipartFormData body = request().body().asMultipartFormData();
        List<Http.MultipartFormData.FilePart> uploadFiles = body.getFiles();

        if (uploadFiles == null || uploadFiles.size() < 1) {
            return badRequest();
        }

        Http.MultipartFormData.FilePart uploadFile = uploadFiles.get(0);

        CourseLecture lecture = lectureService.uploadLectureSlideshow(lectureId, uploadFile);

        if (lecture == null) {
            return notFound();
        }

        return noContent();
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result getLectureSlideshow(Long lectureId) {
        List<byte[]> lectureSlideshowContent = lectureService.getLectureSlideshow(lectureId);
        if (lectureSlideshowContent == null) {
            return notFound();
        }
        return ok(Json.toJson(lectureSlideshowContent));
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result updateLectureType(Long lectureId) {
        JsonNode jsonNode = request().body().asJson();

        int type = jsonNode.findPath("type").asInt(-1);

        if (!TSConst.LECTURE_CONFIG.LECTURE_TYPE.isValidType(type)) {
            return badRequest();
        }

        // TODO: Check authority
        User currentUser = userService.getCurrentUser();

        boolean isUpdated = lectureService.updateLectureType(lectureId,type);
        if (isUpdated) {
            return noContent();
        }

        return notFound();
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result loadLecturePage(String courseTitleUrl, String lectureTitleUrl) {
        User user = userService.getCurrentUser();

        Course course = courseService.findCourseByTitleUrl(courseTitleUrl);
        if (course == null) {
            return redirect(routes.Application.notFoundPage()); //TODO: redirect to 404 page
        }

        // Check brand
        if (user.Brand.id != course.User.Brand.id) {
            return redirect(routes.Application.notFoundPage());
        }

        boolean skipAuthority = authService.isAdminOrManager(user) || course.User.id == user.id;

        if (course.status != TSConst.COURSE_CONFIG.STATUS.PUBLIC && !skipAuthority) {
            return redirect(routes.Application.notFoundPage());
        }

        if (!skipAuthority && (!planService.hasParticipated(course.Plan, user) || courseEnrollService.getUserEnroll(course.id, user.id) == null)) {
            return redirect(routes.Application.accessDeniedPage());
        }

        Collections.sort(course.CourseSections);
        CourseLecture lecture = lectureService.findLectureByTitleUrl(lectureTitleUrl);

        //get all discussion of lecture
        List<CourseDiscussion> discussionsByLecture = discussionService.getAllDiscussionOfLectureId(lecture.id);
        HashMap<Long,String> discussionDuration = new HashMap<>();
        for (CourseDiscussion discussionTemp : discussionsByLecture) {
            discussionDuration.put(discussionTemp.id,Utils.getDurationString(discussionTemp.createdDate));
        }
        // Load lecture
        if (lecture != null) {
            if (!skipAuthority) {
                courseEnrollService.updateLearnerLearningProgress(user, course, lecture);
            }

            LearningCourseData learningCourseData = courseService.createLearningCourseData(course, user);

            if (lecture.type == TSConst.LECTURE_CONFIG.LECTURE_TYPE.VIDEO.value) {
                return ok(views.html.learner.learning_page.VideoLearningPage.render(learningCourseData, lecture, discussionsByLecture, user, discussionDuration));
            }
            if (lecture.type == TSConst.LECTURE_CONFIG.LECTURE_TYPE.POWERPOINT.value) {
                return ok(views.html.learner.learning_page.SlideshowLearningPage.render(learningCourseData, lecture, discussionsByLecture,user,discussionDuration));
            }
            if (lecture.type == TSConst.LECTURE_CONFIG.LECTURE_TYPE.QUIZ.value) {
                return ok(views.html.learner.learning_page.QuizLearningPage.render(learningCourseData, lecture));
            }
            return ok(views.html.learner.learning_page.TextLearningPage.render(learningCourseData, lecture, discussionsByLecture, user, discussionDuration));
        }
        return notFound();
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result loadLastLecturePage(Long courseId) {

        Course course = courseService.findCourseById(courseId);
        if (course == null) {
            return redirect(routes.Application.notFoundPage());

        }
        // Check brand
        User user = userService.getCurrentUser();

        if (user.Brand.id != course.User.Brand.id) {
            return redirect(routes.Application.notFoundPage());
        }

        CourseLecture lecture = lectureService.getLastLearningLecture(user.id, course.id);

        // Load lecture
        if (lecture != null) {
            return redirect(routes.LectureController.loadLecturePage(course.titleUrl, lecture.titleUrl));

        }
        return redirect(routes.Application.notFoundPage());
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result loadNextLecture(Long courseId, Long lectureId) {
        Course course = courseService.findCourseById(courseId);
        if (course == null) {
            return redirect(routes.Application.notFoundPage());
        }
        // Check brand
        User user = userService.getCurrentUser();

        if (user.Brand.id != course.User.Brand.id) {
            return redirect(routes.Application.notFoundPage());
        }

        CourseLecture currentLecture = lectureService.findLectureById(lectureId);
        if (currentLecture == null) {
            return redirect(routes.Application.notFoundPage());

        }

        CourseLecture lecture = lectureService.getNextLecture(course, currentLecture);

        // Load lecture
        if (lecture != null) {
            // Check complete current lecture
            if (currentLecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.QUIZ.value) {
                learnerProcessService.updateLearnerProcess(user.id, course.id, currentLecture.id);
            }

            return redirect(routes.LectureController.loadLecturePage(course.titleUrl, lecture.titleUrl));

        }
        return redirect(routes.Application.notFoundPage());

    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result loadPreviousLecture(Long courseId, Long lectureId) {
        Course course = courseService.findCourseById(courseId);
        if (course == null) {
            return redirect(routes.Application.notFoundPage());

        }
        // Check brand
        User user = userService.getCurrentUser();

        if (user.Brand.id != course.User.Brand.id) {
            return redirect(routes.Application.notFoundPage());
        }

        CourseLecture currentLecture = lectureService.findLectureById(lectureId);
        if (currentLecture == null) {
            return redirect(routes.Application.notFoundPage());
        }

        CourseLecture lecture = lectureService.getPreviousLecture(course, currentLecture);

        // Load lecture
        if (lecture != null) {
            return redirect(routes.LectureController.loadLecturePage(course.titleUrl, lecture.titleUrl));

        }
        return redirect(routes.Application.notFoundPage());

    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.LEARNER)
    public Result loadLectureTextContent(String courseTitleUrl, String lectureTitleUrl) {
        Course course = courseService.findCourseByTitleUrl(courseTitleUrl);
        if (course == null) {
            return notFound();
        }
        // Check brand
        User user = userService.getCurrentUser();

        if (user.Brand.id != course.User.Brand.id) {
            return notFound();
        }

        boolean skipAuthority = authService.isAdminOrManager(user) || course.User.id == user.id;

        if (!skipAuthority && (!planService.hasParticipated(course.Plan, user) || courseEnrollService.getUserEnroll(course.id, user.id) == null)) {
            return forbidden();
        }

        CourseLecture currentLecture = lectureService.findLectureByTitleUrl(lectureTitleUrl);
        if (currentLecture == null || currentLecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.TEXT.value) {
            return notFound();
        }

        byte[] lectureTextContent = lectureService.getLectureTextContent(currentLecture);
        if (lectureTextContent != null) {
            return ok(lectureTextContent);
        }
        return notFound();
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.LEARNER)
    public Result loadLectureSlideshow(String courseTitleUrl, String lectureTitleUrl) {
        Course course = courseService.findCourseByTitleUrl(courseTitleUrl);
        if (course == null) {
            return notFound();
        }
        // Check brand
        User user = userService.getCurrentUser();

        if (user.Brand.id != course.User.Brand.id) {
            return notFound();
        }

        boolean skipAuthority = authService.isAdminOrManager(user) || course.User.id == user.id;

        if (!skipAuthority && (!planService.hasParticipated(course.Plan, user) || courseEnrollService.getUserEnroll(course.id, user.id) == null)) {
            return forbidden();
        }

        CourseLecture currentLecture = lectureService.findLectureByTitleUrl(lectureTitleUrl);
        if (currentLecture == null) {
            return notFound();
        }

        List<byte[]> lectureSlideshowContent = lectureService.getLectureSlideshow(currentLecture);
        if (lectureSlideshowContent == null) {
            return notFound();
        }
        return ok(Json.toJson(lectureSlideshowContent));
    }



}
