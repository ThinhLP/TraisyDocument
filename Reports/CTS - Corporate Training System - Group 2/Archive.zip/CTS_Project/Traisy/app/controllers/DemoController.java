package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import commons.TSConst;
import commons.Utils;
import models.User;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import security.authorization.Authorization;
import services.AuthService;
import services.BrandService;
import services.LectureService;
import services.UserService;

import javax.inject.Inject;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DemoController extends Controller {

    @Inject private UserService userService;
    @Inject private AuthService authService;
    @Inject private BrandService brandService;
    @Inject private LectureService lectureService;

    public Result testPage(){
//        List<String> stringList = new ArrayList<>();
//        File file = new File("C:\\Users\\Hung\\Desktop\\Chuong 1.pptx");
//        String listDir = Utils.convertPPTtoImage(file,"test");
//        File dir = new File(listDir);
//        File[] directories = dir.listFiles();
//        for (int i = 0 ; i<= directories.length ; i++) {
//            String url = directories[i].getAbsolutePath();
//            stringList.add(url);
//        }
//        stringList.add(directories[1].getAbsolutePath());
        return ok(views.html.test.render());

//        File file = new File("C:\\Users\\Hung\\Desktop\\Chuong 1.pptx");
//        byte[] ppt = Utils.getBytesFromFile(file);
//
//        File.WriteAllBytes(string path, byte[] bytes)
//        brandService.updateBrandImage(3, file);
    }

    @Transactional
    public Result updateLecture(long id, String lectureFile){
        File file = new File("C:\\Users\\Hung\\Desktop\\Chuong 1.pptx");
        //lectureFile = Utils.convertPPTtoImage(file,"test");
        boolean isUpdate = lectureService.updateLectureFile(id,lectureFile);

        File folder = new File(lectureFile);
        File[] listOfFile = folder.listFiles();

        List<String> dir = new ArrayList<>();
        dir.add(listOfFile[1].getAbsolutePath());
        dir.add(listOfFile[2].getAbsolutePath());
        if (isUpdate){
//            return redirect(routes.DemoController.manageBrandPageDetail(id));
            return ok(views.html.displayDemo.render(dir));
        }
        return notFound();
    }

//    public Result updateImage(){
//        return redirect(routes.DemoController.demoPage());
//    }

    @Transactional
    public Result getLogo(String path) {
        File imagePath = new File(path);
        byte[] image = Utils.getBytesFromFile(imagePath);
        if (image == null) {
            image = Utils.getBytesFromFile(new File("public/resources/images/Default-Logo.png"));
        }
        return ok(image).as("image/jpeg");
    }

//    public Result demoPage(){
//        return ok(views.html.admin.NewManageBrandDetail.render(currentBrand, currentUser));
//
//    }
}
