package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import commons.TSConst;
import commons.Utils;
import fronts.CourseDiscussionData;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import security.authorization.JsonAuthorization;
import services.DiscussionService;
import services.UserService;

import javax.inject.Inject;
import java.sql.Timestamp;
import java.util.List;

public class DiscussionController extends Controller {
    @Inject private DiscussionService discussionService;
    @Inject private UserService userService;

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result getAllDiscussion() {
        JsonNode jsonNode = request().body().asJson();
        long courseLectureId = jsonNode.findPath("course_lecture_id").asLong(-1);
        List<CourseDiscussionData> courseDiscussionDataList = discussionService.getAllDiscussion(courseLectureId);
        if (courseDiscussionDataList != null) {
            return ok(Json.toJson(courseDiscussionDataList));
        } else {
            return notFound();
        }
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result getAllDiscussionByCourse() {
        JsonNode jsonNode = request().body().asJson();
        String courseTitle = jsonNode.findPath("courseTitle").asText("");
        List<CourseDiscussionData> courseDiscussionDataList = discussionService.getAllDisscussionByCourse(courseTitle);
        if (courseDiscussionDataList != null) {
            return ok(Json.toJson(courseDiscussionDataList));
        } else {
            ObjectNode node = Json.newObject();
            node.put("ERROR", "Something went wrong when get all discussions");
            return ok(node);
        }
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.LEARNER)
    public Result createDiscussion() {
        JsonNode jsonNode = request().body().asJson();
        String content = jsonNode.findPath("content").textValue();
        long courseLectureId = jsonNode.findPath("lectureId").asLong(-1);
        long parentId = jsonNode.findPath("parentId").asLong(-1);
        Timestamp createdDate = new Timestamp(System.currentTimeMillis());
        int status = 1;
        long userId = userService.getCurrentUser().id;
        CourseDiscussionData discussionData = discussionService.addDiscussion(content, createdDate, parentId, userId, status, courseLectureId);
        if (discussionData != null) {
            return ok(Json.toJson(discussionData));
        } else {
            return notFound();
        }
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.LEARNER)
    public Result updateDiscussion() {
        JsonNode jsonNode = request().body().asJson();
        long id = jsonNode.findPath("discussionId").asLong(-1);
        String content = jsonNode.findPath("content").textValue();
        Timestamp createdDate = new Timestamp(System.currentTimeMillis());
        boolean result = discussionService.updateDiscussion(id, content, createdDate);
        if (result) {
            return noContent();
        } else {
            return notFound();
        }
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.LEARNER)
    public Result removeDiscussion() {
        JsonNode jsonNode = request().body().asJson();
        long id = jsonNode.findPath("discussionId").asLong(-1);
        boolean result = discussionService.removeDiscussion(id);
        if (result) {
            return noContent();
        } else {
            return notFound();
        }
    }

}
