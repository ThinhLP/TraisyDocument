package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import commons.TSConst;
import commons.Utils;
import models.User;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import security.authorization.Authorization;
import services.AuthService;
import services.BrandService;
import services.UserService;

import javax.inject.Inject;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Application extends Controller {

    @Inject private UserService userService;
    @Inject private AuthService authService;
    @Inject private BrandService brandService;
    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result indexPage() {

        User currentUser = userService.getCurrentUser();
        if (authService.isSystemAdmin(currentUser)) {
            // System admin
            return redirect(routes.BrandController.manageBrandPage());
        } else if (authService.isAdminOrManager(currentUser)) {
            // Admin or manager
            return redirect(routes.ReportController.planReportPage());
        } else  {
            // Learner or author
            return redirect(routes.PlanController.viewPlansPage());
        }

    }

    /**
     *   Render login page
     */
    public Result loginPage() {
        if (authService.isAlreadyLogin()) {
            return redirectToPreviousURL();
        }
        return ok(views.html.login.render());
    }

    /**
     *  Login API
     */
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result loginAPI() {

        JsonNode json = request().body().asJson();
        String username = json.findPath("username").asText();
        String password = json.findPath("password").asText();
        ObjectNode result = Json.newObject();

        if (userService.isLockedUser(username)) {
            result.put("error", "Tài khoản của bạn đã bị khóa. Vui lòng liên hệ Admin để được giải quyết.");
            return forbidden(result);
        } else {
            boolean isSuccess = userService.login(username, password, request());
            if (isSuccess) {
                result.put("previousUrl", getPreviousURL());
                return ok(result);
            } else {
                return badRequest("Thông tin đăng nhập không hợp lệ.");
            }
        }

    }

    /**
     * Log out
     */
    @Transactional
    public Result logout() {
        userService.logout();
        session(TSConst.USER_SESSION.PREVIOUS_URL, "/");
        return redirect("/");
    }

    /**
     * This session key is used in combination with apache shiro to verify user credential
     * This is necessary because Play framework does not use Shiro Filter since Shiro use local thread
     * to bind Security Manager.
     *
     * @param value the value
     */
    public static void setSessionKey(String value) {
        session("sesKey", value);
    }

    /**
     * Gets session key.
     *
     * @return the session key
     */
    public static String getSessionKey() {
        return session("sesKey");
    }

    /**
     * Remove session key.
     */
    public static void removeSessionKey() {
        session().remove("sesKey");
    }


    /**
     * Get previous url
     */
    public static String getPreviousURL() {
        return session(TSConst.USER_SESSION.PREVIOUS_URL) == null ? "/dang-nhap" : session(TSConst.USER_SESSION.PREVIOUS_URL);
    }


    public static Result redirectToPreviousURL() {
        String url =  session(TSConst.USER_SESSION.PREVIOUS_URL) == null ? "/dang-nhap" : session(TSConst.USER_SESSION.PREVIOUS_URL);
        return redirect(url);
    }

    /**
     *  Render error page
     */
    public Result accessDeniedPage() {
        return forbidden(views.html.error.ClientError.render("Bạn không có quyền thực hiện chức năng này"));
    }

    public Result notFoundPage() {
        return notFound(views.html.error.ClientError.render("Không tìm thấy tài nguyên bạn yêu cầu"));
    }

    public Result clientErrorPage(){
        return ok(views.html.error.ClientError.render("Lỗi xảy ra"));
    }
}
