package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import commons.TSConst;
import commons.Utils;
import fronts.CourseData;
import fronts.PlanData;
import fronts.UserData;
import fronts.UserPlanData;
import fronts.report.LearnerPlanReportDetail;
import models.Brand;
import models.Course;
import models.Plan;
import models.User;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import security.authorization.Authorization;
import security.authorization.JsonAuthorization;
import services.*;

import javax.inject.Inject;
import java.io.File;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class PlanController extends Controller {

    @Inject
    private UserService userService;
    @Inject
    private AuthService authService;
    @Inject
    private PlanService planService;
    @Inject
    private BrandService brandService;
    @Inject
    private LectureService lectureService;
    @Inject
    private LearnerProcessService learnerProcessService;

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.MANAGER)
    public Result managePlansPage() {
        User currentUser = userService.getCurrentUser();
        List<Plan> plans = planService.listAllPlansByBrandId(currentUser.Brand.id);
        Collections.sort(plans);
        return ok(views.html.manager.ManagePlans.render(plans, currentUser));
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result viewPlansPage() {
        User currentUser = userService.getCurrentUser();
        if (currentUser.Role.id == TSConst.USER_ROLE.AUTHOR.value) {
            List<Plan> plans = planService.getAllParticipantPlan(currentUser.id);
            Collections.sort(plans);
            return ok(views.html.manager.ManagePlans.render(plans, currentUser));
        } else {
            List<PlanData> planDataList = planService.getAllPlanOfUserWithProcessOfCourse(currentUser.id);
            double totalCourses, finishCourse, processOfPlan;
            for (PlanData tempPlan : planDataList) {
                totalCourses = 0;
                finishCourse = 0;
                processOfPlan = 0;
                List<CourseData> coursesOfPlan = tempPlan.Courses;

                for (CourseData tempData : coursesOfPlan) {
                    if (tempData.status == 1) {
                        totalCourses++;
                    }
                }
                for (CourseData courseData : coursesOfPlan) {
                    if (courseData.process != null) {
                        double processOfCourse = Double.parseDouble(courseData.process);
                        if (processOfCourse == 100) {
                            finishCourse++;
                        }
                    }
                }

                if (totalCourses != 0 && finishCourse != 0) {
                    processOfPlan = (finishCourse / totalCourses) * 100;
                }
                tempPlan.process = (int) processOfPlan;

                Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
                if (tempPlan.endDate != null) {
                    if (currentTimestamp.after(tempPlan.endDate)) {
                        tempPlan.overDue = 1;
                    }
                }
            }
            return ok(views.html.learner.AllPlans.render(planDataList, currentUser));
        }
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result planOverviewPage(String planTitle) {

        User currentUser = userService.getCurrentUser();
        Plan plan = planService.findPlanByTitleUrl(planTitle);
        if (plan == null || plan.status != TSConst.COMMON_STATUS.PUBLIC) {
            return redirect(routes.Application.notFoundPage());
        }

        if (!planService.hasParticipated(plan, currentUser)) {
            return redirect(routes.Application.accessDeniedPage());
        }

        PlanData planData = planService.convertToFullPlanData(plan, currentUser.id);

        return ok(views.html.learner.PlanOverview.render(planData, currentUser));
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result createSimplePlan() {
        JsonNode jsonNode = request().body().asJson();
        String title = jsonNode.findPath("title").asText("").trim();

        User currentUser = userService.getCurrentUser();

        if (title.length() < TSConst.FIELD_VALIDATION.MIN_TITLE_LEN || title.length() > TSConst.FIELD_VALIDATION.MAX_TITLE_LEN) {
            return badRequest();
        }

        Plan newPlan = planService.createSimplePlan(title, currentUser);

        if (newPlan != null) {
            ObjectNode result = Json.newObject();
            result.put("titleUrl", newPlan.titleUrl);
            return ok(result);
        } else {
            return badRequest();
        }


    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result removePlan(Long planId) {

        if (planId <= 0) {
            return notFound();
        }

        User currentUser = userService.getCurrentUser();

        boolean result = planService.removePlan(planId, currentUser);

        if (result) {
            return noContent();
        } else {
            return notFound();
        }
    }

    @Transactional
    public Result getPlanIntroImage(Long planId) {
        byte[] image = planService.findPlanById(planId).planImage;
        if (image == null) {
            image = Utils.getBytesFromFile(new File("public/resources/images/plan-default.jpg"));
        }
        return ok(image).as("image/jpeg");
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.MANAGER)
    public Result uploadPlanImage(String titleUrl) {
        Http.MultipartFormData body = request().body().asMultipartFormData();
        Http.MultipartFormData.FilePart picture = body.getFile("picture");
        if (picture != null) {
            File file = (File) picture.getFile();

            planService.updatePlanImage(file, titleUrl);

        }
        return redirect(routes.PlanController.managePlanDetail(titleUrl) + "#hinh-anh");
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.AUTHOR)
    public Result managePlanDetail(String titleUrl) {

        Plan plan = planService.findPlanByTitleUrl(titleUrl);
        if (plan == null) {
            return redirect(routes.Application.notFoundPage());
        } else {
            User currentUser = userService.getCurrentUser();
            if (currentUser.Brand.id != plan.User.Brand.id || plan.status != TSConst.COMMON_STATUS.PUBLIC) {
                return redirect(routes.Application.notFoundPage());
            }
            boolean isEmptyPlan = plan.Programs.isEmpty();
            for(Course course: plan.Courses) {
                if(course.Program == null  && course.status != commons.TSConst.COURSE_CONFIG.STATUS.DELETE) {
                    isEmptyPlan = false;
                    break;
                }
            }

            return ok(views.html.manager.ManagePlanDetail.render(plan, currentUser, isEmptyPlan));
        }
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result updatePlan(Long planId) {

        JsonNode jsonNode = request().body().asJson();

        String title = jsonNode.findPath("title").asText("").trim();
        String description = jsonNode.findPath("description").asText("").trim();
        long startDate = jsonNode.findPath("startDate").asLong(0);
        long endDate = jsonNode.findPath("endDate").asLong(-1);

        if (title.equals("")) {
            return badRequest();
        }
        if (planId <= 0 || startDate > endDate || title.isEmpty()) {
            return badRequest();
        }

        Plan plan = planService.findPlanById(planId);
        if (plan == null) {
            return notFound();
        }

        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        boolean isUpdated = planService.updatePlanBasicInfo(plan, title, description, startDate, endDate);
        if (isUpdated) {
            return noContent();
        } else {
            return notFound();
        }
    }

    /* Add user to plan */
    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result participatePlan(Long planId) {

        if (planId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);

        if (plan == null) {
            return notFound();
        }
        // Authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        JsonNode jsonNode = request().body().asJson();

        JsonNode userIdsNode = jsonNode.findPath("userIds");

        if (!userIdsNode.isArray()) {
            return badRequest();
        }


        List<Long> userIds = new ArrayList<>();
        for (JsonNode userNode : userIdsNode) {
            long id = userNode.asInt(-1);
            if (id > 0) {
                userIds.add(id);
            }
        }

        for (long userId : userIds) {
            planService.addUserToPlan(plan, userId);
        }

        return noContent();
    }

    /* Load author of plan */
    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result getAuthorsOfPlan(Long planId, Integer pageNo) {
        if (planId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);

        if (plan == null) {
            return notFound();
        }

        if (pageNo <= 0) {
            pageNo = 1;
        }

        // Check authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        // Get author list of plan
        List<UserData> authorList = planService.getUsersOfPlan(plan, TSConst.USER_ROLE.AUTHOR.value, 1, TSConst.LIST_CONFIG.USER_LIST_MAX_SIZE);

        return ok(Json.toJson(authorList));
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result getLearnersOfPlan(Long planId, Integer pageNo) {
        if (planId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);

        if (plan == null) {
            return notFound();
        }

        if (pageNo <= 0) {
            pageNo = 1;
        }

        // Check authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        // Get learner list of plan
        List<UserData> learnerList = planService.getUsersOfPlan(plan, TSConst.USER_ROLE.LEARNER.value, pageNo, TSConst.LIST_CONFIG.USER_LIST_MAX_SIZE);

        return ok(Json.toJson(learnerList));
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result getAvailableAuthors(Long planId, Integer pageNo) {
        JsonNode json = request().body().asJson();

        int brandId = json.findPath("brandId").asInt(-1);
        if (planId <= 0 || brandId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);
        if (plan == null) {
            return notFound();
        }

        Brand brand = brandService.findBrandById(brandId);
        if (brand == null) {
            return notFound();
        }

        // Check authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        if (pageNo <= 0) {
            pageNo = 1;
        }

        // Get available author list of plan
        List<UserData> authorList = planService.getPlanAvailableUsers(plan, brand, TSConst.USER_ROLE.AUTHOR.value, pageNo, TSConst.LIST_CONFIG.USER_LIST_MAX_SIZE);

        return ok(Json.toJson(authorList));
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result getAvailableLearners(Long planId, Integer pageNo) {
        JsonNode json = request().body().asJson();

        int brandId = json.findPath("brandId").asInt(-1);
        if (planId <= 0 || brandId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);
        if (plan == null) {
            return notFound();
        }

        Brand brand = brandService.findBrandById(brandId);
        if (brand == null) {
            return notFound();
        }

        // Check authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        if (pageNo <= 0) {
            pageNo = 1;
        }

        // Get available learner list of plan
        List<UserData> learnerList = planService.getPlanAvailableUsers(plan, brand, TSConst.USER_ROLE.LEARNER.value, pageNo, TSConst.LIST_CONFIG.USER_LIST_MAX_SIZE);

        return ok(Json.toJson(learnerList));
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result removeUserFromPlan(Long planId) {
        JsonNode json = request().body().asJson();

        int userId = json.findPath("userId").asInt(-1);
        if (planId <= 0 || userId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);
        if (plan == null) {
            return notFound();
        }
        // Check authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        User user = userService.findUser(userId);
        if (user == null) {
            return notFound();
        }

        // Remove user from plan
        boolean isRemoved = planService.removeUserFromPlan(plan, user);
        if (isRemoved) {
            return noContent();
        } else {
            return notFound();
        }

    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.LEARNER)
    public Result getTopPlans(Integer top) {
        User currentUser = userService.getCurrentUser();

        if (top <= 0) {
            top = 5;
        }

        List<PlanData> plans = planService.getPlansByBrandId(currentUser.Brand.id, 1, top);

        return ok(Json.toJson(plans));

    }
}