package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.inject.Inject;
import commons.TSConst;
import fronts.QuestionData;
import fronts.learning.LearningCourseData;
import fronts.quiz.LearnerQuizResult;
import fronts.quiz.QuizSubmission;
import models.*;
import play.db.jpa.JPAApi;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import security.authorization.Authorization;
import security.authorization.JsonAuthorization;
import services.*;

import javax.persistence.EntityManager;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class QuizController extends Controller {

    @Inject
    UserService userService;
    @Inject
    LectureService lectureService;
    @Inject
    CourseService courseService;
    @Inject
    QuizService quizService;
    @Inject
    AuthService authService;
    @Inject
    QuestionService questionService;
    @Inject
    PlanService planService;
    @Inject
    CourseEnrollService courseEnrollService;
    @Inject
    JPAApi jpaApi;

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateQuiz(Long lectureId) {
        User user = userService.getCurrentUser();
        if (user == null) {
            return forbidden();
        }

        JsonNode json = request().body().asJson();

        Integer duration = json.findPath("duration").asInt(0);
        Double minScore = json.findPath("minScore").asDouble(0);

        if (lectureId <= 0) {
            return badRequest();
        }

        CourseLecture lecture = lectureService.findLectureById(lectureId);

        if (lecture == null || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.QUIZ.value) {
            return notFound();
        }
        if (!lectureService.isCourseOwner(lectureId, user)) {
            return forbidden();
        }


        boolean isUpdated = quizService.updateQuiz(lecture, duration, minScore);

        if (!isUpdated) {
            return notFound();
        }

        return noContent();
    }


    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result createQuestion(Long lectureId) {
        User user = userService.getCurrentUser();

        JsonNode json = request().body().asJson();

        if (lectureId <= 0) {
            return badRequest();
        }

        CourseLecture lecture = lectureService.findLectureById(lectureId);

        if (lecture == null || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.QUIZ.value || lecture.Quiz == null ) {
            return notFound();
        }

        if (!lectureService.isCourseOwner(lecture.id, user)) {
            return forbidden();
        }
        QuestionData questionData = Json.fromJson(json, QuestionData.class);

        QuestionData result = questionService.createQuestion(lecture.Quiz, questionData);

        if (result == null) {
            return notFound();
        }

        return ok(Json.toJson(result));
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateQuestion(Long lectureId) {
        User user = userService.getCurrentUser();

        JsonNode json = request().body().asJson();

        Long questionId = json.findPath("questionId").asLong(-1);

        if (questionId <= 0 || lectureId <= 0) {
            return badRequest();
        }

        // Check permission for quiz
        CourseLecture lecture = lectureService.findLectureById(lectureId);
        if (lecture == null || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.QUIZ.value) {
            return notFound();
        }

        if (!lectureService.isCourseOwner(lecture.id, user)) {
            return forbidden();
        }

        String content = json.findPath("content").asText("");
        String explaination = json.findPath("explaination").asText("");

        if (!content.isEmpty() && (content.length() < TSConst.FIELD_VALIDATION.MIN_QUESTION_LENGTH || content.length() > TSConst.FIELD_VALIDATION.MAX_QUESTION_LENGTH)) {
            return badRequest();
        }

        Question question = questionService.findQuestion(questionId);

        if (question == null) {
            return notFound();
        }

        boolean isUpdated = questionService.updateQuestion(question, content, explaination);

        if (!isUpdated) {
            return notFound();
        }

        return noContent();
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result removeQuestion(Long lectureId) {
        User user = userService.getCurrentUser();
        JsonNode json = request().body().asJson();

        Long questionId = json.findPath("questionId").asLong(-1);

        if (questionId <= 0) {
            return badRequest();
        }

        // Check permission for quiz
        CourseLecture lecture = lectureService.findLectureById(lectureId);
        if (lecture == null || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.QUIZ.value) {
            return notFound();
        }

        if (!lectureService.isCourseOwner(lecture.id, user)) {
            return forbidden();
        }

        Question question = questionService.findQuestion(questionId);

        if (question == null) {
            return notFound();
        }

        boolean isRemoved = questionService.removeQuestion(question);

        if (!isRemoved) {
            return notFound();
        }

        // Update number of questions of test
        quizService.descreaseNoOfQuestion(lecture.Quiz);

        return noContent();
    }

//    @Transactional
//    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
//    @BodyParser.Of(BodyParser.Json.class)
//    public Result reorderQuestion(Long lectureId) {
//        User user = userService.getCurrentUser();
//        JsonNode json = request().body().asJson();
//
//
//        if (lectureId <= 0) {
//            return badRequest();
//        }
//
//        CourseLecture lecture = lectureService.findLectureById(lectureId);
//
//        if (lecture == null || lecture.type != TSConst.LECTURE_CONFIG.LECTURE_TYPE.QUIZ.value) {
//            return notFound();
//        }
//
//        if (!lectureService.isCourseOwner(lecture.id, user)) {
//            return forbidden();
//        }
//
//        Quiz quiz = lecture.Quiz;
//        if (quiz == null) {
//            return notFound();
//        }
//
//        Map<Long, Integer> questionOrder = new HashMap<>();
//
//        JsonNode questionsNode = json.findPath("questions");
//        if (questionsNode.isMissingNode() || !questionsNode.isArray()) {
//            return badRequest();
//        }
//
//        for (JsonNode questionNode : questionsNode) {
//            long id = questionNode.findPath("id").asLong(0);
//            int order = questionNode.findPath("order").asInt(0);
//
//            if (questionService.findQuestion(id) == null) {
//                return notFound();
//            }
//
//            if (questionOrder.containsKey(id) || questionOrder.containsValue(order)) {
//                return badRequest();
//            }
//            questionOrder.put(id, order);
//        }
//
//        questionService.updateQuestionOrder(questionOrder);
//        return noContent();
//    }


    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.LEARNER)
    @BodyParser.Of(BodyParser.Json.class)
    public Result submitQuiz() {
        User user = userService.getCurrentUser();

        JsonNode json = request().body().asJson();

        QuizSubmission submission;

        try {
            submission = Json.fromJson(json, QuizSubmission.class);
        } catch (Exception e) {
            return badRequest();
        }

        CourseLecture lecture = lectureService.findLectureById(submission.lectureId);

        if (lecture == null) {
            return notFound();
        }

        Course course = lecture.Course;

        boolean skipAuthority = authService.isAdminOrManager(user) || course.User.id == user.id;

        if (!skipAuthority && (!planService.hasParticipated(course.Plan, user) || courseEnrollService.getUserEnroll(course.id, user.id) == null)) {
            return forbidden(); //TODO: redirect to 403 page
        }

        boolean isSubmitted = quizService.evaluateSubmission(lecture, user, submission);

        if (!isSubmitted) {
            return notFound();
        }

        return noContent();
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.LEARNER)
    public Result loadQuizResult(String courseTitleUrl, String lectureTitleUrl) {
        User user = userService.getCurrentUser();
        Course course = courseService.findCourseByTitleUrl(courseTitleUrl);
        if (course == null) {
            return notFound();
        }

        CourseLecture lecture = lectureService.findLectureByTitleUrl(lectureTitleUrl);

        // Load the quiz result
        if (course != null && lecture != null) {
            LearnerQuiz learnerQuiz = quizService.getLastLearnerQuiz(user.id, lecture.Quiz.id);
            if (learnerQuiz != null) {
                LearningCourseData learningCourseData = courseService.createLearningCourseData(course, user);

                List<LearnerQuizResult> results = quizService.convertToLearnerLearnerQuizResult(lecture.Quiz, learnerQuiz.LearnerQuizDetails);
                int noOfRightQuestions = 0;
                for (LearnerQuizResult quizResult: results) {
                    if (quizResult.isCorrect) {
                        noOfRightQuestions++;
                    }
                }
                return ok(views.html.learner.learning_page.QuizResultPage.render(learningCourseData, lecture, learnerQuiz, results, noOfRightQuestions));
            }
        }

        return notFound();
    }
}
