package controllers;

import commons.TSConst;
import fronts.UserData;
import fronts.report.AuthorPlanReportDetail;
import fronts.report.LearnerPlanReportDetail;
import fronts.report.PlanReport;
import models.Plan;
import models.Program;
import models.User;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import security.authorization.Authorization;
import security.authorization.JsonAuthorization;
import services.AuthService;
import services.PlanService;
import services.UserService;

import javax.inject.Inject;
import java.util.Collections;
import java.util.List;

public class ReportController extends Controller {

    @Inject
    UserService userService;
    @Inject
    PlanService planService;
    @Inject
    AuthService authService;


    @Transactional
    @Authorization(role = TSConst.USER_ROLE.MANAGER)
    public Result planReportPage() {

        User currentUser = userService.getCurrentUser();

        List<PlanReport> planReports = planService.getPlanReportList(currentUser.Brand.id);

        int noOfOutDate = 0;
        int noOfCompletedPlan = 0;
        for (PlanReport report: planReports) {
            if (report.totalCompleted != 0 && report.totalCompleted == report.totalLearners) {
                noOfCompletedPlan++;
            }
            if (report.isOutOfDated) {
                noOfOutDate++;
            }
        }

        return ok(views.html.manager.ReportPage.render(currentUser, planReports, noOfOutDate, noOfCompletedPlan));
    }

    @Transactional
    @Authorization(role = TSConst.USER_ROLE.MANAGER)
    public Result planReportDetailPage(String planTitleUrl) {
        Plan plan = planService.findPlanByTitleUrl(planTitleUrl);
        if (plan == null) {
            return redirect(routes.Application.notFoundPage());
        }

        User currentUser = userService.getCurrentUser();
        if (plan.User.Brand.id != currentUser.Brand.id) {
            return redirect(routes.Application.notFoundPage());
        }

        List<LearnerPlanReportDetail> learnerList = planService.getAllLearnerPlanParticipants(plan);

        List<UserData> authorList = planService.getAllUsersOfPlan(plan, TSConst.USER_ROLE.AUTHOR.value);

        int noOfCompleted = 0;
        for (LearnerPlanReportDetail detail: learnerList) {
            if (detail.planProcess == 100.0) {
                noOfCompleted++;
            }
        }


        return ok(views.html.manager.PlanReportPage.render(plan, currentUser, noOfCompleted, learnerList.size(), authorList.size()));
    }


    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result getLearnerParticipantsOfPlan(Long planId, Integer pageNo) {
        if (planId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);

        if (plan == null) {
            return notFound();
        }

        if (pageNo <= 0) {
            pageNo = 1;
        }

        // Check authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        // Get learner list of plan
        List<LearnerPlanReportDetail> learnerList = planService.getLearnerPlanParticipants(plan, pageNo, 5);

        return ok(Json.toJson(learnerList));
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result getLearnerParticipantPlanDetail(Long planId, Long userId) {
        if (planId <= 0 || userId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);

        if (plan == null) {
            return notFound();
        }

        // Check authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        User user = userService.findUser(userId);
        if (user == null) {
            return notFound();
        }
        // Get learner list of plan
        LearnerPlanReportDetail reportDetail = planService.getLearnerReportDetail(plan, user);

        return ok(Json.toJson(reportDetail));
    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result getAuthorParticipantsOfPlan(Long planId, Integer pageNo) {
        if (planId <= 0) {
            return notFound();
        }

        Plan plan = planService.findPlanById(planId);

        if (plan == null) {
            return notFound();
        }

        if (pageNo <= 0) {
            pageNo = 1;
        }

        // Check authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        // Get learner list of plan
        List<AuthorPlanReportDetail> authorList = planService.getAuthorPlanParticipants(plan, pageNo, 5);
        return ok(Json.toJson(authorList));
    }
//
//    @Transactional
//    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
//    public Result getAllAuthorParticipantsOfPlan(Long planId) {
//        if (planId <= 0) {
//            return notFound();
//        }
//
//        Plan plan = planService.findPlanById(planId);
//
//        if (plan == null) {
//            return notFound();
//        }
//
//        // Check authority
//        User currentUser = userService.getCurrentUser();
//        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
//            return forbidden();
//        }
//
//        // Get learner list of plan
//        List<AuthorPlanReportDetail> authorList = planService.getAllAuthorPlanParticipants(plan);
//        return ok(Json.toJson(authorList));
//    }

    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.MANAGER)
    public Result getAuthorParticipantPlanDetail(Long planId, Long userId) {
        if (planId <= 0 || userId <= 0) {
            return notFound();
        }
        Plan plan = planService.findPlanById(planId);

        if (plan == null) {
            return null;
        }

        // Check authority
        User currentUser = userService.getCurrentUser();
        if (!authService.isSystemAdmin(currentUser) && plan.User.Brand.id != currentUser.Brand.id) {
            return forbidden();
        }

        User user = userService.findUser(userId);
        if (user == null) {
            return notFound();
        }
        // Get learner list of plan
        AuthorPlanReportDetail reportDetail = planService.getAuthorReportDetail(plan, user);

        if (reportDetail == null) {
            return notFound();
        }

        Collections.sort(reportDetail.programs);
        return ok(Json.toJson(reportDetail));
    }

}
