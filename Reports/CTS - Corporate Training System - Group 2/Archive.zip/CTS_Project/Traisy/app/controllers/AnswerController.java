package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import commons.TSConst;
import models.Answer;
import models.CourseLecture;
import models.Question;
import play.db.jpa.Transactional;
import play.mvc.BodyParser;
import play.mvc.Controller;
import play.mvc.Result;
import security.authorization.JsonAuthorization;
import services.*;

import javax.inject.Inject;
import java.io.IOException;
import java.util.List;

public class AnswerController extends Controller {
    @Inject private UserService userService;
    @Inject private AuthService authService;
    @Inject private AnswerService answerService;
    @Inject private QuestionService questionService;
    @Inject private LectureService lectureService;


    @Transactional
    @JsonAuthorization(role = TSConst.USER_ROLE.AUTHOR)
    @BodyParser.Of(BodyParser.Json.class)
    public Result removeAnswer(){
        JsonNode jsonNode = request().body().asJson();

        long answerId = jsonNode.findPath("answerId").asLong();
        long questionId = jsonNode.findPath("questionId").asLong();

        // Authority
        Question question = questionService.findQuestion(questionId);
        if (question == null || question.type != TSConst.QUIZ_CONFIG.QUESTION_TYPE.MULTIPLE_CHOICE.value) {
            return notFound();
        }

        if (question.Answers.size() == 1) {
            return notFound();
        }

        boolean result = answerService.removeAnswer(question, answerId);
        if (result){
            return noContent();
        } else{
            return notFound();
        }
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result createAnswer(){
        JsonNode jsonNode = request().body().asJson();

        String content = jsonNode.findPath("content").asText("");
        int correct = jsonNode.findPath("correct").asInt(-1);
        long questionId = jsonNode.findPath("questionId").asLong(-1);

        Answer answer = answerService.createAnswer(content, correct, questionId);

        if (answer != null){
            return noContent();
        } else{
            return notFound();
        }
    }

    @Transactional
    @BodyParser.Of(BodyParser.Json.class)
    public Result updateAnswer(){
        JsonNode jsonNode = request().body().asJson();

        long id = jsonNode.findPath("id").asLong(-1);
        String content = jsonNode.findPath("content").asText("");
        int correct = jsonNode.findPath("correct").asInt(-1);

        boolean result = answerService.updateAnswer(id, correct, content);

        if (result){
            return ok();
        } else{
            return notFound();
        }
    }

    @Transactional
    public Result getAnswersByQuestionId(){
        JsonNode jsonNode = request().body().asJson();
        long questionId = jsonNode.findPath("questionId").asLong(-1);

        List<Answer> answers = answerService.getAllAnswerByQuestionId(questionId);

        if (answers != null){
            return ok();
        } else {
            return notFound();
        }
    }
}
