import play.Configuration;
import play.Environment;
import play.api.OptionalSourceMapper;
import play.api.UsefulException;
import play.api.routing.Router;
import play.http.DefaultHttpErrorHandler;
import play.libs.F;
import play.mvc.Http;
import play.mvc.Result;
import play.mvc.Results;
import services.LogService;

import javax.inject.Inject;
import javax.inject.Provider;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

public class ErrorHandler extends DefaultHttpErrorHandler {

    @Inject
    public ErrorHandler(Configuration configuration, Environment environment,
                        OptionalSourceMapper sourceMapper, Provider<Router> routes) {
        super(configuration, environment, sourceMapper, routes);
    }

    protected CompletionStage<Result> onProdServerError(Http.RequestHeader requestHeader, UsefulException exception) {
        String err = String.format("Error on server: client info: %s ", LogService.getClientInfo(requestHeader));
        LogService.logger.error(err, exception);
        return CompletableFuture.completedFuture(Results.internalServerError(views.html.error.ClientError.render("Not found")));
    }

    @Override
    public CompletionStage<Result> onServerError(Http.RequestHeader requestHeader, Throwable throwable) {
        String err = String.format("Error on server: client info: %s ", LogService.getClientInfo(requestHeader));
        LogService.logger.error(err, throwable);
        return CompletableFuture.completedFuture(Results.internalServerError(views.html.error.ClientError.render("Error server 500")));
    }

    protected CompletionStage<Result> onForbidden(Http.RequestHeader requestHeader, String message) {
        String err = String.format("Forbidden: %s client info: %s ", message, LogService.getClientInfo(requestHeader));
        LogService.logger.error(err);
        return CompletableFuture.completedFuture(Results.forbidden("You're not allowed to access this resource."));
    }

    @Override
    protected CompletionStage<Result> onBadRequest(Http.RequestHeader requestHeader, String message) {
        String err = String.format("Bad Request: %s client info: %s ", message, LogService.getClientInfo(requestHeader));
        LogService.logger.error(err);
        return CompletableFuture.completedFuture(Results.badRequest(views.html.error.ClientError.render("Bad request 400")));
    }

    @Override
    protected CompletionStage<Result> onNotFound(Http.RequestHeader requestHeader, String message) {
        String err = String.format("Resource Not Found: %s client info: %s ", message, LogService.getClientInfo(requestHeader));
        LogService.logger.error(err);
        return CompletableFuture.completedFuture(Results.notFound(views.html.error.ClientError.render("Not found 400")));
    }


    /*Returns all clent errors inform of 4xx code
    * */
    @Override
    public CompletionStage<Result> onClientError(Http.RequestHeader requestHeader, int statusCode, String message) {
        String err = String.format("Client Error [%s]: %s client info: %s ", statusCode, message, LogService.getClientInfo(requestHeader));
        LogService.logger.error(err);
        return CompletableFuture.completedFuture(Results.status(statusCode, views.html.error.ClientError.render("4xx")));
    }
}
